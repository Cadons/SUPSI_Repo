#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include "bthread.h"
#include "tsemaphore.h"
#include "tbarrier.h"
#include "tcondition.h"

void *bthread1(void *arg);

void *bthread2(void *arg);

void *bthread3(void *arg);


int a, b, c;
bthread_t t1, t2, t3;
int cnt = 0;
bthread_sem_t *sem;
bthread_barrier_t *barrier;
bthread_cond_t *conditional_barrier;
bthread_mutex_t *mutex;
void *bthread1(void *arg) {

    for (a = 0; a < 5; a++) {
        bthread_printf("BThread1: %s %d \n", (const char *) arg, a);
        if(bthread_sem_wait(sem)) {
            cnt++;

           bthread_sem_post(sem);
        }
    }
    bthread_sleep(1000);
    bthread_barrier_wait(barrier);
    bthread_printf("BThread1 exiting\n");

    bthread_cond_wait(conditional_barrier, mutex);
    cnt+=100;
    bthread_cond_broadcast(conditional_barrier);
    bthread_printf("BThread1 out\n");

    return (void *) 13;
}

void *bthread2(void *arg) {


    for (b = 0; b < 10; b++) {
        bthread_printf("BThread2: %s %d\n", (const char *) arg, b);
        if(bthread_sem_wait(sem)) {
            cnt--;

            bthread_sem_post(sem);

        }

    }
   // bthread_cancel(t1);
    bthread_barrier_wait(barrier);
    bthread_printf("BThread2 exiting\n");

    bthread_cond_wait(conditional_barrier, mutex);
    cnt+=100;
    bthread_cond_broadcast(conditional_barrier);
    bthread_printf("BThread2 out\n");

    // bthread_sleep(2000);

    return (void *) 17;
}

void *bthread3(void *arg) {
    bthread_cancel(t2);

    for (c = 0; c < 30; c++) {
        bthread_printf("BThread3: %s %d\n", (const char *) arg, c);
        if(bthread_sem_wait(sem)) {
            cnt++;
          bthread_sem_post(sem);
        }
    }
   // bthread_sleep(500);
    bthread_barrier_wait(barrier);
    bthread_printf("BThread3 exiting\n");

    bthread_cond_wait(conditional_barrier, mutex);
    cnt+=100;
    bthread_cond_broadcast(conditional_barrier);
    bthread_printf("BThread3 out\n");

    return (void *) 42;
}

int mainB(int argc, char *argv[]) {
    int *r1, *r2, *r3;
    uintptr_t rv1, rv2, rv3;
    sem = (bthread_sem_t *) malloc(sizeof(bthread_sem_t));
    barrier = (bthread_barrier_t *) malloc(sizeof(bthread_barrier_t));
    conditional_barrier= (bthread_cond_t *) malloc(sizeof(bthread_cond_t));
    mutex = (bthread_mutex_t *) malloc(sizeof(bthread_mutex_t));
    bthread_mutex_init(mutex, NULL);
    bthread_cond_init(conditional_barrier,NULL);
    bthread_sem_init(sem, 0, 1);
    bthread_barrier_init(barrier, NULL, 3);
    bthread_printf("Creating Alpha thread...\n");
    bthread_create(&t1, NULL, &bthread1, (void *) "Alpha");

    bthread_printf("Creating Beta thread...\n");

    bthread_create(&t2, NULL, &bthread2, (void *) "Beta");
    bthread_printf("Creating Gamma thread...\n");
    bthread_create(&t3, NULL, &bthread3, (void *) "Gamma");

    bthread_printf("Joining BThread 1\n");
    int ris = bthread_join(t1, (void **) (&r1));
    if (ris)
        bthread_printf("BThread 1 Cancelled\n");

    bthread_printf("Joining BThread 2\n");
    ris = bthread_join(t2, (void **) (&r2));
    bthread_printf("Joining BThread 3\n");
    ris = bthread_join(t3, (void **) (&r3));
    bthread_printf("cnt: %d \n", cnt);
    bthread_sem_destroy(sem);
    rv1 = (uintptr_t) r1;
    rv2 = (uintptr_t) r2;
    rv3 = (uintptr_t) r3;

    bthread_printf("End of run: %ld=%d,%d  %ld=%d,%d  %ld=%d,%d\n", t1, a, (int) rv1, t2, b, (int) rv2, t3, c,
                   (int) rv3);


    return 0;
}
