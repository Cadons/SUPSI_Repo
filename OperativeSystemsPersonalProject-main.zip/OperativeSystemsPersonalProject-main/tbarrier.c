//
// Created by cadons on 08/12/22.
//
#include "bthread_private.h"
#include "tbarrier.h"

int bthread_barrier_init(bthread_barrier_t *b, const bthread_barrierattr_t *attr, unsigned count) {
    b->barrier_size = count;
    b->count = 0;
    b->waiting_list = NULL;
    return 0;
}

int bthread_barrier_destroy(bthread_barrier_t *b) {
    b->barrier_size = 0;
    b->count = 0;
    b->waiting_list = NULL;
}

int bthread_barrier_wait(bthread_barrier_t *b) {
    b->count++;
    __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    if (b->count == b->barrier_size) {

        b->count = 0;
        while (tqueue_size(b->waiting_list) > 0) {
            __bthread_private *bthread = (__bthread_private *) tqueue_pop(&b->waiting_list);
            bthread->state = __BTHREAD_READY;
            bthread_yield();
        }
        return 1;
    } else {
        bthread->state = __BTHREAD_BLOCKED;
        tqueue_enqueue(&b->waiting_list, bthread);
        while (bthread->state != __BTHREAD_READY) {
            bthread_yield();
        };
    }
    return 0;
}
