//
// Created by cadons on 08/12/22.
//
#include "tcondition.h"
#include "bthread_private.h"

int bthread_cond_init(bthread_cond_t *c, const bthread_condattr_t *attr) {
    c->waiting_list = NULL;
    return 0;
}

int bthread_cond_destroy(bthread_cond_t *c) {
    c->waiting_list = NULL;
}

int bthread_cond_wait(bthread_cond_t *c, bthread_mutex_t *m) {

}

int bthread_cond_signal(bthread_cond_t *c) {
    __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    if (tqueue_size(c->waiting_list) > 0) {
        __bthread_private *bthread = (__bthread_private *) tqueue_pop(&c->waiting_list);
        bthread->state = __BTHREAD_READY;
        bthread_yield();
    }
    return 0;
}

int bthread_cond_broadcast(bthread_cond_t *c) {
    __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    while (tqueue_size(c->waiting_list) > 0) {
        __bthread_private *bthread = (__bthread_private *) tqueue_pop(&c->waiting_list);
        bthread->state = __BTHREAD_READY;
        bthread_yield();
    }
    return 0;
}