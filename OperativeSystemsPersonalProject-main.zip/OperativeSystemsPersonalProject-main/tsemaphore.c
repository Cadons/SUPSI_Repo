#include "tsemaphore.h"

#include "bthread_private.h"
#include <assert.h>


//implement a semphore using mutex and tsemaphore.h.
int bthread_sem_init(bthread_sem_t *s, int pshared, int value) {
    assert(s != NULL);
    s->value = value;
    s->waiting_list = NULL;
    return 0;
}
int bthread_sem_destroy(bthread_sem_t *s) {
    assert(s!=NULL);
    s->value = 0;
    s->waiting_list = NULL;

    return 0;
}
int bthread_sem_wait(bthread_sem_t *s) {
    __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    if (s->value > 0) {
        s->value--;
        return 1;
    } else {
        bthread->state = __BTHREAD_BLOCKED;
        tqueue_enqueue(&s->waiting_list, bthread);
        while (bthread->state != __BTHREAD_READY) {
            bthread_yield();
        };
    }
    return 0;
}
int bthread_sem_post(bthread_sem_t *s) {
    __bthread_scheduler_private *scheduler = bthread_get_scheduler();
    __bthread_private *bthread = (__bthread_private *) tqueue_get_data(scheduler->current_item);
    if (tqueue_size(s->waiting_list) > 0) {
        __bthread_private *bthread = (__bthread_private *) tqueue_pop(&s->waiting_list);
        bthread->state = __BTHREAD_READY;
        bthread_yield();

    } else {
        s->value++;
        return 1;
    }
    return 0;
}
