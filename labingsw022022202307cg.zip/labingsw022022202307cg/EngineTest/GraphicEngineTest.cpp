#include "GraphicEngine.h"
#include "Node.h"
#include "NodeTest.h"

#include <assert.h>


void createEmptyNodeTest() {
	GraphicEngine::getInstance();
	auto node = GraphicEngine::getInstance()->createEmptyNode();
	assert(node->getChildrenNodes().size()==0);
	assert(node->getParentNode()== nullptr);
	assert(node->getName()== "Node");
}
//test getnode by name 
void getNodeByNameTest() {
	GraphicEngine::getInstance();
	auto node = GraphicEngine::getInstance()->createEmptyNode();
	auto node2 = GraphicEngine::getInstance()->createEmptyNode();
	auto node3 = GraphicEngine::getInstance()->createEmptyNode();
	node->setName("test");
	assert(GraphicEngine::getInstance()->getNodeByName("test")[0]->getID()==node->getID());
}
//test isClosed
void isClosedTest() {
		assert(GraphicEngine::getInstance()->isClosed()== true);
}
//test getwidth
void getWidthTest() {
	GraphicEngine::getInstance();
	assert(GraphicEngine::getInstance()->getWidth()==100);
}
//test getheight
void getHeightTest() {
	GraphicEngine::getInstance();
	assert(GraphicEngine::getInstance()->getHeight() == 100);
}

//test setclosed
void setClosedTest() {
	GraphicEngine::getInstance()->setClosed(true);
	assert(GraphicEngine::getInstance()->isClosed());
}
//test setwidth
void setWidthTest() {
	GraphicEngine::getInstance()->setWidth(100);
	assert(GraphicEngine::getInstance()->getWidth()==100);
}
//test setheight
void setHeightTest() {
	GraphicEngine::getInstance()->setHeight(100);
	assert(GraphicEngine::getInstance()->getHeight()== 100);
}

//remove element
void removeElementTest() {

	GraphicEngine::getInstance()->clearScene();
	auto node = GraphicEngine::getInstance()->createEmptyNode();
	GraphicEngine::getInstance()->removeElement(node);
	assert(GraphicEngine::getInstance()->getNumberOfObjectsLoaded() == 0);
}

void lightTest() {

	GraphicEngine::getInstance()->clearScene();

	std::string name = "Test Light";
	glm::mat4 transformMatrix = glm::mat4(1.0f);
	bool enable = true;
	glm::vec4 lightAmbient(1, 0, 0, 1);
	glm::vec4 lightDiffuse(0, 1, 0, 1);
	glm::vec4 lightSpecular(0, 0, 1, 1);

	
	
	auto light = GraphicEngine::getInstance()->createPointLight("Test Light", glm::mat4(1.0f), true, glm::vec4(1, 0, 0, 1), glm::vec4(0, 1, 0, 1), glm::vec4(0, 0, 1, 1));
	auto light1 = GraphicEngine::getInstance()->createPointLight("Test Light2", glm::mat4(1.0f), true, glm::vec4(1, 0, 0, 1), glm::vec4(0, 1, 0, 1), glm::vec4(0, 0, 1, 1));

	assert(light->getLightAmbient() == lightAmbient);
	assert(light->getLightDiffuse() == lightDiffuse);


	assert(GraphicEngine::getInstance()->getNumberOfObjectsLoaded() == 2);

}

void cameraTest() {

	GraphicEngine::getInstance()->clearScene();
	std::string name = "Test Camera";
	glm::mat4 transform = glm::mat4(1.0f);
	float _near = 1.0f;
	float _far = 100.0f;
	float fov = 45.0f;

	auto camera = GraphicEngine::getInstance()->createProspectiveCamera(name, transform, _near, _far, fov);

	// Check that the camera was added to the object list
	assert(GraphicEngine::getInstance()->getNumberOfObjectsLoaded() == 1);

	// Check that the properties of the camera were set correctly
	assert(camera->getName() == name);
	assert(camera->getNearPlane() == _near);
	assert(camera->getFarPlane() == _far);

}

void getMeshesTest() {

}

//test instance
void getInstanceTest() {

	GraphicEngine::getInstance()->clearScene();


	GraphicEngine* engine1 = GraphicEngine::getInstance();
	GraphicEngine* engine2 = GraphicEngine::getInstance();
	GraphicEngine* engine3 = GraphicEngine::getInstance();

	// Check that the same instance is returned each time
	assert(engine1 == engine2);
	assert(engine2 == engine3);

}

void addTextBoxTest() {
	GraphicEngine::getInstance()->clearScene();

	float x = 10.0f;
	float y = 20.0f;
	std::string text = "Test Text";
	glm::vec3 color(1, 0, 0);

	auto textbox = GraphicEngine::getInstance()->addTextBox(x, y, text, color);

	// Check that the textbox was added to the object list
	assert(GraphicEngine::getInstance()->getNumberOfObjectsLoaded() == 1);

	// Check that the properties of the textbox were set correctly
	assert(textbox->getX() == x);
	assert(textbox->getY() == y);
	assert(textbox->getText() == text);
	assert(textbox->getColor() == color);

}

void createMaterialTest() {

	GraphicEngine::getInstance()->clearScene();
	std::string name = "Test Material";
	glm::vec4 ambient(1.0f, 0.5f, 0.5f, 1.0f);
	glm::vec4 diffuse(0.5f, 0.5f, 1.0f, 1.0f);
	glm::vec4 emission(0.0f, 0.0f, 0.0f, 1.0f);
	glm::vec4 specular(1.0f, 1.0f, 1.0f, 1.0f);
	float shininess = 32.0f;



	Material* material = GraphicEngine::getInstance()->createMaterial(name, ambient, diffuse, emission, specular, shininess);

	// Assert that the returned material pointer is not null
	assert(material != nullptr);

	// Assert that the material's name is as expected
	assert(material->getName() == name);

	// Assert that the material's color values are as expected
	assert(material->getAmbient() == ambient);
	assert(material->getDiffuse() == diffuse);
	assert(material->getEmission() == emission);
	assert(material->getSpecular() == specular);

	// Assert that the material's shininess value is as expected
	assert(material->getShininess() == shininess);


}



int main(int argc, char** argv)
{

createEmptyNodeTest();
getNodeByNameTest();
isClosedTest();
getWidthTest() ;
getHeightTest() ;
setClosedTest();
setWidthTest();
setHeightTest();
removeElementTest();
nodeTests();
lightTest();
cameraTest();
getMeshesTest();
getInstanceTest();
addTextBoxTest();
createMaterialTest();


   return 0;
}
