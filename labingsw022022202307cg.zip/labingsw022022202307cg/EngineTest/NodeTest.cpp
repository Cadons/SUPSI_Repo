#include "NodeTest.h"
#include "Node.h"
#include "GraphicEngine.h"
#include "glm/glm.hpp"
#include <glm/geometric.hpp>
#include "glm/ext/matrix_relational.hpp"
#include <assert.h>


void addChildrenNodeTest() {
	auto engine = GraphicEngine::getInstance();

	auto tmp=engine->createEmptyNode();
	auto tmp2 = engine->createEmptyNode();
	tmp->addChildrenNode(tmp2);
	assert(tmp->getChildrenNodes().size()==1);
	assert(tmp2->getParentNode()->getID()== tmp->getID());
}
bool glmMatrixVerifier(glm::mat4 m1, glm::mat4 m2)
{
	auto ris= glm::equal(m1, m2);
	bool output = true;
	for (int i = 0; i < ris.length(); i++) {
		if (ris[i] == false)
			return false;
}
	return true;
}
void setMatrixTest() {
	auto engine = GraphicEngine::getInstance();

	auto tmp = engine->createEmptyNode();
	tmp->setMatrix(glm::mat4(2.0));
	// check if the matrix is correctly set
	assert(glmMatrixVerifier(tmp->getMatrix(),glm::mat4(2.0)));
}
//test getMatrix 
void getMatrixTest() {
	auto engine = GraphicEngine::getInstance();

	auto tmp = engine->createEmptyNode();
	tmp->setMatrix(glm::mat4(2.0));
	// check if the matrix is correctly set
	assert(glmMatrixVerifier(tmp->getMatrix(),glm::mat4(2.0)));
	//check transform matrix if node is child
	auto tmp2 = engine->createEmptyNode();
	tmp->addChildrenNode(tmp2);
	assert(tmp2->getParentNode()->getID()== tmp->getID());
	tmp2->setMatrix(glm::mat4(3.0));
	assert(!glmMatrixVerifier(tmp2->getMatrix(),glm::mat4(3.0)));
	assert(glmMatrixVerifier(tmp2->getMatrix(),tmp->getMatrix()*glm::mat4(3.0)));
}

//test removeChildrenNode
 void removeChildrenNodeTest() {
	auto engine = GraphicEngine::getInstance();
	//engine->free();
	//engine = GraphicEngine::getInstance();
	auto tmp = engine->createEmptyNode();
	auto tmp2 = engine->createEmptyNode();
	tmp->addChildrenNode(tmp2);
	assert(tmp->getChildrenNodes().size()==1);
	assert(tmp2->getParentNode()->getID()== tmp->getID());
	tmp->removeChildrenNode(tmp2);
	assert(tmp->getChildrenNodes().size()== 0);
	assert(tmp2->getParentNode()!=nullptr);

}


void nodeTests(){
	addChildrenNodeTest();
	setMatrixTest();
	getMatrixTest();
	removeChildrenNodeTest();
}

