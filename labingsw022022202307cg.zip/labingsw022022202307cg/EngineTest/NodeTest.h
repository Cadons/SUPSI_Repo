#ifndef NODETEST_H
#define NODETEST_H

void nodeTests();
#endif
