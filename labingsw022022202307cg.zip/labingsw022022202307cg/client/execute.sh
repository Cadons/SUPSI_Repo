#!/bin/bash
# This script is executed by the user
# It is executed in the context of the user
cp ../engine/bin/Release/libengine.so ./Debug/libengine.so
cp ../engine/bin/Release/libengine.so ./Release/libengine.so

if [ "$1" == "-d" ]; then
    #debug
  cd bin/Debug
  export LD_LIBRARY_PATH=./
  ./client
else
    #release
  cd bin/Release
  export LD_LIBRARY_PATH=./
  ./client
fi