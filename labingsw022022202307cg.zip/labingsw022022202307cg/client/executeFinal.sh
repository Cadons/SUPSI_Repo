#!/bin/bash
  export LD_LIBRARY_PATH=./
  ./client
