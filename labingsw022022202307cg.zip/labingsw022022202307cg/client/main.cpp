/**
 * @file		main.cpp
 * @brief

 */

 //////////////
 // #INCLUDE //
 //////////////
 // Library header:
 // C/C++:
#include <iostream>
#include <GraphicEngine.h>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/string_cast.hpp>


#include <iostream>
#include <stdlib.h>




//////////
// MAIN //
//////////

/**         
 * Application entry point.
 * @param argc number of command-line arguments passed
 * @param argv array containing up to argc passed arguments
 * @return error code (0 on success, error code otherwise)
 */
float x_camera = 0, y_camera = 0;
Camera* camera;
Camera* camera2;
Camera* camera3;
Camera* camera4;
bool wireframe = false;
Node* craneArm;
Node* poulie;

Node* accroche;
Node* cable0;
Node* cable1;

Node* cable2;
Node* cable3;
Node* hook;
Node* takableBox = nullptr;
Node* terrain;
TextBox* FPStxt;
TextBox* hookTxt;
TextBox* tutorial;
TextBox* cameraTxt;
SpotLight* hookLight;
PointLight* sun;
const float offset = .0f;
const float yMin = 0.;
const float yMax = -180;
const float zMin = 45;
const float zMax = -40;
float yaccroche = 0;
float zpoulie = 0;
float poulieSpeed = 2.0f;
float accrocheSpeed = 4.0f;
float craneRotation = 0.5f;
bool taken = false;
vector<Camera*> cameras;
int activeCamera = 0;
float xThrashold = 5, yThrashold = 25, zThrashold = 5, unloadTrashold = 28;

void renderCraneCable(Node* cable) {
    auto distance = glm::distance(
        glm::vec3(accroche->getMatrix()[3][0], accroche->getMatrix()[3][1],
            accroche->getMatrix()[3][2]),
        glm::vec3(poulie->getMatrix()[3][0], poulie->getMatrix()[3][1],
            poulie->getMatrix()[3][2]));
    cable->setLocalMatrix(scale(glm::mat4(1.0f),
        glm::vec3(1.0f, -distance / 2, 1.0f)));
}


bool triggerTerrain() {
    if (abs(terrain->getMatrix()[3][1] - hook->getMatrix()[3][1]) < unloadTrashold) {
        return true;
    }
    return false;

}

void changeCamera() {

    auto engine = GraphicEngine::getInstance();
    activeCamera = (activeCamera + 1) % cameras.size();
    while (!cameras[activeCamera]->getEnable()) {
        activeCamera = (activeCamera + 1) % cameras.size();

    }
    engine->setMainCamera(cameras[activeCamera]);
}

void keyboard(unsigned char key, int mousex, int mousey) {
    auto engine = GraphicEngine::getInstance();
    float speed = 3.0f;
    //move camera with mouse (mousex and mousey)

    switch (key) {
    case 'e':

        //rotate around it self
        craneArm->setLocalMatrix(
            rotate(craneArm->getLocalMatrix(), glm::radians(-craneRotation), glm::vec3(0.0f, 1.0f, 0.0f)));
        craneArm->setMatrix(craneArm->getLocalMatrix());
        break;
    case 'q':

        craneArm->setLocalMatrix(
            rotate(craneArm->getLocalMatrix(), glm::radians(craneRotation), glm::vec3(0.0f, 1.0f, 0.0f)));
        craneArm->setMatrix(craneArm->getLocalMatrix());

        break;
    case 'r':
        if (zpoulie > zMax) {
            zpoulie--;
            poulie->setMatrix(glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, zpoulie * poulieSpeed)));

        }


        break;
    case 'f':
        if (zpoulie < zMin) {
            zpoulie++;

            poulie->setMatrix(
                glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, zpoulie * poulieSpeed)));


        }
        break;
    case 'z':
        if (yaccroche > yMax) {
            yaccroche--;
            accroche->setMatrix(glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, yaccroche * accrocheSpeed, 0.0f)));
            //streach cables

            renderCraneCable(cable0);

            renderCraneCable(cable1);

            renderCraneCable(cable2);
            renderCraneCable(cable3);
        }


        break;


    case 'x':
        if (yaccroche < yMin) {
            yaccroche++;
            accroche->setMatrix(glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, yaccroche * accrocheSpeed, 0.0f)));
            //streach cables
            renderCraneCable(cable0);
            renderCraneCable(cable1);
            renderCraneCable(cable2);
            renderCraneCable(cable3);
        }
        break;
    case 'd':
        x_camera++;
        camera->setMatrix(camera->getMatrix() * glm::translate(glm::mat4(1.0), glm::vec3(speed, 0.0, 0.0)));

        break;

    case 'a':
        x_camera--;

        camera->setMatrix(camera->getMatrix() * glm::translate(glm::mat4(1.0), glm::vec3(-speed, 0.0, 0.0)));


        break;
    case 'w':
        y_camera--;
        camera->setMatrix(
            camera->getMatrix() * glm::translate(glm::mat4(1.0), glm::vec3(0.0, 0.0, -speed)));


        break;
    case 's':
        y_camera++;

        camera->setMatrix(camera->getMatrix() * glm::translate(glm::mat4(1.0), glm::vec3(0.0, 0.0, speed)));


        break;
    case ' ':


        camera->setMatrix(camera->getMatrix() * glm::translate(glm::mat4(1.0), glm::vec3(0.0, speed, 0.0)));


        break;
    case 'b':


        camera->setMatrix(camera->getMatrix() * glm::translate(glm::mat4(1.0), glm::vec3(0.0, -speed, 0.0)));


        break;
    case '1':

        camera->setMatrix(
            glm::rotate(glm::mat4(1.0), glm::radians(5.0f), glm::vec3(0.0, 1.0, 0.0)) * camera->getMatrix());
        //undo z rotation




        break;
    case '2':

        camera->setMatrix(
            glm::rotate(glm::mat4(1.0), glm::radians(-5.0f), glm::vec3(0.0, 1.0, 0.0)) * camera->getMatrix());


        break;
    case '3':

        //rotate camera aroung origin y
        camera->setMatrix(glm::rotate(camera->getMatrix(), glm::radians(5.0f), glm::vec3(1.0, 0.0, 0.0)));


        break;
    case '4':
        camera->setMatrix(glm::rotate(camera->getMatrix(), glm::radians(-5.0f), glm::vec3(1.0, 0.0, 0.0)));
        break;
    case '5':


        camera->setMatrix(glm::translate(glm::mat4(1.0f), glm::vec3(-50, 50, 90)));

        camera->setMatrix(glm::rotate(camera->getMatrix(), glm::radians(-30.0f), glm::vec3(0, 1, 0)));


        break;
    case '<':
        wireframe = !wireframe;
        engine->setWireframe(wireframe);
        break;
    case 't':
        changeCamera();
        break;
    case 'g':
        if (taken) {
            if (triggerTerrain()) {
                hook->removeChildrenNode(takableBox);
                takableBox->setMatrix(hook->getMatrix());
                //  takableBox->setMatrix(glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, .0, 0.0f)));
                cout << "box unloaded" << endl;
                hookTxt->setText("");
                takableBox = nullptr;
                taken = false;
                camera3->setEnable(true);
                hookLight->setEnable(true);
            }
        }
        else {
            if (takableBox != nullptr) {
                auto tmp = takableBox->getMatrix();
                hook->addChildrenNode(takableBox);
                takableBox->setLocalMatrix(glm::mat4(1.0f));
                takableBox->setMatrix(glm::mat4(1.0f));
                cout << "box loaded" << endl;
                taken = true;
                hookTxt->setText("");
                camera3->setEnable(false);
                hookLight->setEnable(false);
                if (engine->getMainCamera() == camera3)
                    changeCamera();
            }
            else {
                cout << "nothing to take" << endl;
            }
        }


        break;

    }

    engine->refreshWindow();
}

int main(int argc, char* argv[]) {
    // Init and use the lib:

    auto engine = GraphicEngine::getInstance();
    engine->init(0, argv, 800, 600, "The Crane Project");
    FPStxt = engine->addTextBox(10, 0, "", glm::vec3(0, 1, 0));
    TextBox* title = engine->addTextBox(10, (engine->getHeight() / 2) + 20, "The Crane Project", glm::vec3(1, 1, 0));
    tutorial = engine->addTextBox(10, engine->getHeight() / 2, "");
    tutorial->setText(
        "Tutorial\n Q-E: rotate crane's arm\n R-F: move poulie\n Z-X:move the crane's hook\n G:load or unload the boxes\n T: change camera");
    tutorial->setColor(1, 0, 0);
    cameraTxt = engine->addTextBox(engine->getWidth() - 110, 0, "", glm::vec3(0, 1, 0));
    hookTxt = engine->addTextBox(engine->getWidth() / 2, engine->getHeight() / 2, "", glm::vec3(1, 0, 0));

    camera = engine->createProspectiveCamera("Free Camera");
    camera2 = engine->createProspectiveCamera("Cabine Camera");
    camera3 = engine->createProspectiveCamera("Hook Camera", glm::translate(glm::mat4(1.0), glm::vec3(0, .0, -1)) *
        glm::rotate(glm::mat4(1.0f), glm::radians(-90.0f),
            glm::vec3(1, 0, 0)), 0.1f, 1000);
    camera4 = engine->createProspectiveCamera("Orbit Camera", glm::translate(glm::mat4(1.0f), glm::vec3(0, 200, 300)),
        0.1f, 1000);
    cameras.push_back(camera4);
    cameras.push_back(camera);
    cameras.push_back(camera2);
    cameras.push_back(camera3);

    camera->setFarPlane(2000);


    camera->setMatrix(glm::translate(glm::mat4(1.0f), glm::vec3(-50, 50, 90)));
    //rotate camera 30 degrees
    camera->setMatrix(glm::rotate(camera->getMatrix(), glm::radians(-30.0f), glm::vec3(0, 1, 0)));
    camera4->setMatrix(glm::rotate(camera4->getMatrix(), glm::radians(-20.0f), glm::vec3(1, 0, 0)));

    Camera::setMainCamera(cameras[0]);
    engine->registerKeyboardActions(keyboard);


    auto scene = engine->addModelToScene("resources/Scene.ovo");
    if (scene == nullptr) {
        cout << "scene not found" << endl;
        return 0;
    }

    terrain = engine->getNodeByName("Terrain")[0];
    craneArm = engine->getNodeByName("arm")[0];
    accroche = engine->getNodeByName("accroche")[0];
    poulie = engine->getNodeByName("poulie")[0];
    cable0 = engine->getNodeByName("cable0")[0];
    cable1 = engine->getNodeByName("cable1")[0];
    cable2 = engine->getNodeByName("cable2")[0];
    cable3 = engine->getNodeByName("cable3")[0];
    hook = engine->getNodeByName("hook")[0];
    hook->addChildrenNode(camera3);

    // scale accroche
    auto cabine = engine->getNodeByName("cabine")[0];
    poulie->setMatrix(glm::translate(glm::mat4(1.0f), glm::vec3(0, 0.0f, zpoulie)));

    cabine->addChildrenNode(camera2);
    camera2->setMatrix(glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 40.0f, -40.0f)));
    //change fov of camera2
    ((ProspectiveCamera*)camera2)->setFov(100.0f);
    camera2->setFarPlane(10000);

    hookLight = (SpotLight*)engine->getNodeByName("HookLight")[0];






    engine->lightModel(true);
    vector<Node*> boxes;
    boxes.push_back(engine->getNodeByName("BoxHook")[0]);
    boxes.push_back(engine->getNodeByName("BoxHook1")[0]);
    engine->setBackgroundColor(0.0, 0.0, 1.0);
    auto distance =
        glm::distance(engine->getNodeByName("poulie")[0]->getMatrix()[3][1] - 1.0f, terrain->getMatrix()[3][1]) - 1;

    auto shadowMaterial = engine->createMaterial("Shadows");

    ((Mesh*)cabine)->setMaterial(shadowMaterial);


    engine->setStaticShadow((Mesh*)engine->getNodeByName("corps-haut-1")[0], terrain, shadowMaterial,
        glm::vec3(1, 1, 0), offset);
    engine->setStaticShadow((Mesh*)engine->getNodeByName("corps-haut-2")[0], terrain, shadowMaterial,
        glm::vec3(1, 1, 0), offset);
    engine->setStaticShadow((Mesh*)engine->getNodeByName("corps-haut-3")[0], terrain, shadowMaterial,
        glm::vec3(1, 1, 0), offset);
    engine->setStaticShadow((Mesh*)engine->getNodeByName("Box151")[0], terrain, shadowMaterial, glm::vec3(1, 0, 1),offset);
    engine->setStaticShadow((Mesh*)engine->getNodeByName("Box152")[0], terrain, shadowMaterial, glm::vec3(1, 0, 1), offset);
    engine->setStaticShadow((Mesh*)engine->getNodeByName("Box153")[0], terrain, shadowMaterial, glm::vec3(1, 0, 1), offset);
    engine->setStaticShadow((Mesh*)engine->getNodeByName("Box154")[0], terrain, shadowMaterial, glm::vec3(1, 0, 1), offset);
    engine->setStaticShadow((Mesh*)engine->getNodeByName("Box155")[0], terrain, shadowMaterial, glm::vec3(1, 0, 1), offset);

    engine->setStaticShadow((Mesh*)engine->getNodeByName("plateforme")[0], terrain, shadowMaterial,
        glm::vec3(1, 0, 1), offset);
    engine->setStaticShadow((Mesh*)engine->getNodeByName("cabine")[0], terrain, shadowMaterial, glm::vec3(1, 0, 1), offset);
    engine->setStaticShadow((Mesh*)engine->getNodeByName("poulie")[0], terrain, shadowMaterial, glm::vec3(1, 0, 1), offset);
    //find box in BoxHook and BoxHook1 and set shadow
    for (auto box : boxes) {
        for (auto child : box->getChildrenNodes()) {
            if (child->getName().find("Box") != string::npos) {
                engine->setStaticShadow((Mesh*)child, terrain, shadowMaterial, glm::vec3(1, 1, 0), offset);
            }
        }
    }



    while (!engine->isClosed()) {




        //rotate camera4 around the cabine
        if (engine->getMainCamera() == camera4)
            camera4->setMatrix(glm::rotate(glm::mat4(1.0f), glm::radians(0.2f), glm::vec3(0, 1, 0)) * camera4->getMatrix());

        //rotate the camera view on y and bind with translation
        cameraTxt->setText(engine->getMainCamera()->getName());
        std::string fps = std::to_string((int)engine->getFPS());
        hookTxt->setX(engine->getWidth() / 2);
        hookTxt->setY(engine->getHeight() / 2);
        cameraTxt->setX(engine->getWidth() - cameraTxt->getText().size() * 9.f);

        for (auto box : boxes) {
            hookTxt->setX(engine->getWidth() / 2 - hookTxt->getText().size() * 9.f);
            if (taken) {
                if (triggerTerrain()) {
                    hookTxt->setText("Unload object with G");

                }
                else {
                    hookTxt->setText("");

                }
            }
            else {
                if (abs(box->getMatrix()[3][1] - accroche->getMatrix()[3][1]) < yThrashold &&
                    abs(box->getMatrix()[3][0] - accroche->getMatrix()[3][0]) <= xThrashold &&
                    abs(box->getMatrix()[3][2] - accroche->getMatrix()[3][2]) <= zThrashold) {
                    if (takableBox == nullptr) {
                        //set x based on text of hooktxt



                        hookTxt->setText("Get object with G");

                    }
                    takableBox = box;
                    break;
                }
                else {
                    takableBox = nullptr;
                    hookTxt->setText("");
                }
            }

        }
        FPStxt->setText("FPS: " + fps);
        engine->update();
        engine->refreshWindow();

    }
    engine->free();

    std::cout << "\n[application terminated]" << std::endl;
    return 0;
}
