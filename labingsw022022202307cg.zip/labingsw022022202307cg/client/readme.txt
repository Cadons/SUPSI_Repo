Execute build from make
make run to run the build in release mode
make run_debug to run the build in debug mode
