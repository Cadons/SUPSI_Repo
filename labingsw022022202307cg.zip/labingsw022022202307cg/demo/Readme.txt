Execute demo

Linux:
open terminal
go in the linux folder
run this command: ./execute.sh

Windows:
open the demo.exe
