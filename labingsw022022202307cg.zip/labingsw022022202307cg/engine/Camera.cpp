#include "Camera.h"
#include "glm/gtc/type_ptr.hpp"
#include "GL/freeglut.h"
#include <iostream>
#include "GraphicEngine.h"
Camera* Camera::MainCamera {nullptr};
float Camera::getNearPlane() {
	return this->nearPlane;
}

Camera* Camera::setNearPlane(int nearPlane) {
	this->nearPlane = nearPlane;
	return this;
}

float Camera::getFarPlane() {
	return this->farPlane;
}

Camera* Camera::setFarPlane(int farPlane) {
	this->farPlane = farPlane; 
	return this;
}

Camera* Camera::setMainCamera(Camera* camera) {
	Camera::MainCamera = camera;
	return Camera::getMainCamera();
}

Camera* Camera::getMainCamera() {
	 return Camera::MainCamera;
}

void Camera::render() {
	
	if (this->getID() == Camera::MainCamera->getID())
	{	
		
		//std::cout << "Main Camera" << std::endl;
		//clear buffer
	
		glMatrixMode(GL_PROJECTION);
		glLoadMatrixf(glm::value_ptr(this->getViewMatrix()));
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

	}
}


ObjectType Camera::getType() {
	return this->type;
}

