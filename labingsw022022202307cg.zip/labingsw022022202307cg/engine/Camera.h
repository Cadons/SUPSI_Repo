#ifndef CAMERA_H
#define CAMERA_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Node.h"
#include "glm/glm.hpp"
class LIB_API Camera :public  Node {

private:
	float nearPlane;
	float farPlane;
	static Camera* MainCamera;
	int matrix;
	ObjectType type = ObjectType::CAMERA;
public:
	float getNearPlane();

	Camera* setNearPlane(int nearPlane);

	float getFarPlane();

	Camera* setFarPlane(int farPlane);

	virtual glm::mat4 getViewMatrix()=0;

	static Camera* setMainCamera(Camera* camera);
	
	static Camera* getMainCamera();

	void render() override;
	Camera() {};
	Camera(std::string name, glm::mat4 position, float nearPlane, float farPlane) :Node(name,position) {
		this->nearPlane = nearPlane;
		this->farPlane = farPlane;
	}
	ObjectType getType() override;
};

#endif
