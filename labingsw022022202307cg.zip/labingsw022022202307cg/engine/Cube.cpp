#include "Cube.h"

// FreeGLUT:
#include <GL/freeglut.h>
void Cube::render() {
	if(material!=nullptr)
		material->render();
	glutSolidCube(size);
	Material::reset();
}