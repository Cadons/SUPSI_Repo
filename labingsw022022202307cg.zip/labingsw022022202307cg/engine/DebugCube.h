#include "Node.h"
#include "GL/freeglut.h"
#include "glm/glm.hpp"
#include "glm/gtc/type_ptr.hpp"

class DebugCube: Node
{
public:
	///generate constructor
	DebugCube();
	//generate constructor with parameters of all parent class
	ObjectType getType() override {
		return ObjectType::MESH;
	}
	Texture* textureId;
	DebugCube(float edge,std::string name, glm::mat4 transformMatrix, bool enable, Texture* t) :Node(name, transformMatrix, enable) {
		this->edge = edge;
		srand(time(NULL));
		this->r = (float)rand() / RAND_MAX;
		this->g = (float)rand() / RAND_MAX;
		this->b = (float)rand() / RAND_MAX;
		
		this->localTransform=transformMatrix;
		this->textureId = t;
	}
	void render() override {
	
		//draw cube
		//apply texture
	//glBindTexture(GL_TEXTURE_2D, textureId);	
		textureId->render();
		glBegin(GL_TRIANGLES);
		
		//front
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-edge, -edge, edge);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(edge, -edge, edge);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(edge, edge, edge);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-edge, -edge, edge);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(edge, edge, edge);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-edge, edge, edge);
		//back
		glEnd();


		
		
		
		
		
	





				
		
		glutSolidCube(edge);
	
			glColor3f(r, g, b);


	};
	
private:
	glm::mat4 localTransform=glm::mat4(1.0f);
	float edge = 1.0f;
	float r, g, b;
	
};

