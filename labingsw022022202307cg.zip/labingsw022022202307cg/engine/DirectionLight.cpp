#include "DirectionLight.h"

// FreeGLUT:
#include <GL/freeglut.h>

// C/C++:
#include <iostream>
#include <stdio.h>
#include <glm/gtc/type_ptr.hpp>

   // Light properties:
//glm::vec3 lightPosition(0.0f, -3.0f, -30.0f);


void LIB_API DirectionLight::render() {


	if (setUpLight()) {
		glLightfv(light, GL_POSITION, glm::value_ptr(direction));

		glEnable(light);
	}
	else
	{
		glDisable(light); 
	}

	
	

}

void LIB_API DirectionLight::setDirection(glm::vec3 direction) {

	this->direction = glm::vec4(direction.x,direction.y,direction.z,0);
}

glm::vec4 LIB_API DirectionLight::getDirection() {
	return this->direction;
}
