#ifndef DIRECTIONLIGHT_H
#define DIRECTIONLIGHT_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Light.h"
#include "glm/glm.hpp"
class LIB_API DirectionLight :public Light {

public:

	DirectionLight(glm::vec3 direction,std::string name = "DirectionalLight", glm::mat4 transformMatrix = glm::mat4(1), bool enable = true, glm::vec4 lightAmbient = glm::vec4(0.5f, 0.5f, 0.5f, 1.0f), glm::vec4 lightDiffuse = glm::vec4(0.5f, 0.5f, 0.5f, 1.0f), glm::vec4 lightSpecular = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f)) : Light(name, transformMatrix, enable, lightAmbient, lightDiffuse, lightSpecular) {
		this->direction = glm::vec4(direction.x, direction.y, direction.z, 0);
	}
	void render() override;
	void setDirection(glm::vec3 direction);
	glm::vec4 getDirection();
	
	private:
		glm::vec4 direction;
};

#endif
