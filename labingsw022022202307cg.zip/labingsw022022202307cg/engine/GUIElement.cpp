#include "GUIElement.h"

ObjectType GUIElement::getType() {
	return this->type;
}