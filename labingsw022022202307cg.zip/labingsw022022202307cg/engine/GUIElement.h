#ifndef GUIELEMENT_H
#define GUIELEMENT_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif

#include "Object.h"
#include "glm/glm.hpp"

class LIB_API GUIElement : public Object {
public:
	GUIElement(std::string name = "GUIElement") :Object(name) {}
	virtual ~GUIElement(){}
	virtual void render() = 0;

	virtual void setColor(float r, float g, float b) = 0;
	virtual glm::vec3 getColor() = 0;
	virtual void setX(int x) = 0;
	virtual int getX() = 0;
	virtual void setY(int y) = 0;
	virtual int getY() = 0;
	ObjectType getType();
protected:
	int x;
	int y;
	glm::vec3 color;
	ObjectType type = ObjectType::GUIELEMENT;
};
#endif