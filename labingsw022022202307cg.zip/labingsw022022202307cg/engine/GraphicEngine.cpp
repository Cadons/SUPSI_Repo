
#ifdef _WINDOWS
#include <Windows.h>
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * DLL entry point. Avoid to rely on it for easier code portability (Linux doesn't use this method).
 * @param instDLL handle
 * @param reason reason
 * @param _reserved reserved
 * @return true on success, false on failure
 */
int APIENTRY DllMain(HANDLE instDLL, DWORD reason, LPVOID _reserved)
{
	// Check use:
	switch (reason)
	{
		///////////////////////////
	case DLL_PROCESS_ATTACH: //
		break;
		///////////////////////////
	case DLL_PROCESS_DETACH: //
		break;
	}
	// Done:
	return true;
}
#endif
#include "FreeImage.h"
#include <vector>
#include "Node.h"
#include "ProspectiveCamera.h"
#include "OrthographicCamera.h"
#include <string>
#include <functional>
#include "GL/freeglut.h"
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <memory>
#include "FreeImage.h"
#include "Texture.h"
#include "Cube.h"
#include "OvoParser.h"
#include "Material.h"
#include "List.h"

#include "GraphicEngine.h"
struct LIB_API GraphicEngine::Impl {



	List* objectList;
	int width = 100, height = 100;
	std::string windowName;
	bool closed = true;
	bool initialized = false;
	OvoParser parser;
	bool lightModelStatus = false;
	Impl();

	List* getObjectList() {
		return objectList;
	}

	OvoParser getParser() {
		return parser;
	};
};
GraphicEngine::Impl::Impl()
{
	// constructor implementation
};
//get object list
GraphicEngine::GraphicEngine() {


	impl = std::unique_ptr<Impl>(new Impl());
	impl->objectList = List::getInstance();

};
//destructor
GraphicEngine::~GraphicEngine() {
	free();
	delete impl->objectList;
};
GraphicEngine* GraphicEngine::instance{ nullptr };
int windowId;

/*
* @brief
* @param
* @return
* @note this method is called by the graphic engine to render the scene, it is private and should not be called by the user

*/
// create fps counter method
float Gfps = 0;
float frames = 0;
float GraphicEngine::getFPS() {

	return Gfps;
}

/**
* @brief
* @note this callback count fps every second
*/
void timerCallback(int value)
{
	float fps = frames / 1.0f;
	frames = 0;
	Gfps = fps;

	// Register the next update:
	glutTimerFunc(1000, timerCallback, 0);
}

/**
*@brief
* @note this method render the GUI created by user,
*/

void renderGUI() {
	auto engine = GraphicEngine::getInstance();
	glMatrixMode(GL_PROJECTION);
	glLoadMatrixf(glm::value_ptr(glm::ortho(0.0f, (float)engine->getWidth(), 0.0f, (float)engine->getHeight(), -1.0f, 1.0f)));
	glMatrixMode(GL_MODELVIEW);
	glLoadMatrixf(glm::value_ptr(glm::mat4(1.0f)));

	// Disable lighting before rendering 2D text:
	glDisable(GL_LIGHTING);
	auto gui = List::getInstance()->getElementsByType(ObjectType::GUIELEMENT);
	for (auto it = gui.begin(); it != gui.end(); it++) {
		(*it)->render();
	}
	// Reactivate lighting:
	if (engine->getLightModel())
		glEnable(GL_LIGHTING);
}
void runRendering() {

	auto engine = GraphicEngine::getInstance();
	engine->clear();

	//For debug

	//----------
	if (Camera::getMainCamera() == nullptr)
		throw "No main camera set";
	else {
		List::getInstance()->render();
		//render gui
		renderGUI();
		engine->swap();

		frames++;
	}


}
GraphicEngine* GraphicEngine::removeElement(Object* o)
{
	impl->objectList->remove(o);
	return this;
}
/*
@brief
@param
@return
@note this method check if the window is closed, if it is the case it will set the close flag to true

*/
void onClose() {
	GraphicEngine::getInstance()->setClosed(true);
}
/*
@brief
@param int width width of the window
@param int height height of the window
@return
@note this method is called by the graphic engine when the window is resized

*/
void reshapeCallback(int width, int height)
{
	// Update viewport size:
	glViewport(0, 0, width, height);
	GraphicEngine::getInstance()->setWidth(width);
	GraphicEngine::getInstance()->setHeight(height);

	// Refresh projection matrices:

	GraphicEngine::getInstance()->refreshWindow();
}
/*
@brief
@param
@return
@note this method return if the window has been closed

*/
bool GraphicEngine::isClosed()
{
	return impl->closed;
}
/*
@brief
@param bool closed set the closed flag to true or false
@return
@note this method set the closed flag to true or false
*/
GraphicEngine* GraphicEngine::setClosed(bool v)
{
	impl->closed = v;
	return this;
}
/*
* @brief
* @param int width width of the window to create in pixel
* @param int height height of the window to create in pixel
* @param std::string title title of the window
* @return
* @note this method create a window with the given parameters and initialize the graphic engine


*/
GraphicEngine* GraphicEngine::init(int options, char* argv[], int width, int height, std::string windowName, bool show) {
	//check if the graphic engine is already initialized
	if (!impl->initialized) {
		impl->initialized = true;
		impl->height = height;
		impl->width = width;
		impl->windowName = windowName;
		glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);


		//enable depth test
		glEnable(GL_DEPTH_TEST);
		//enable alpha blending
		glEnable(GL_BLEND);


		glutInit(&options, argv);
		glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);
		if (show) {
			openWindow();
		}
		glEnable(GL_DEPTH_TEST);
		glutCloseFunc(onClose);
		glutTimerFunc(1000, timerCallback, 0);
		//put as displayFunction loop callback runRendering opengl1


		glutDisplayFunc(runRendering);
		//resize glut method
		glutReshapeFunc(reshapeCallback);
		FreeImage_Initialise();

	}
	return this;
}
GraphicEngine* GraphicEngine::openWindow() {
	glutInitWindowSize(impl->width, impl->height);
	windowId = glutCreateWindow(impl->windowName.c_str());
	impl->closed = false;
	return this;
}
/*
* @brief
* @param
* @return
* @note this method return the width of the window

*/
int GraphicEngine::getWidth() { return impl->width; }
/*
* @brief
* @param
* @return
* @note  this method return the height of the window

*/
int GraphicEngine::getHeight() { return impl->height; }
/*
* @brief
* @param int width width of the window to create in pixel
* @note this method set the width of the window


*/
GraphicEngine* GraphicEngine::setWidth(int w) { impl->width = w; return this; }
/*
* @brief
* @param int height height of the window to create in pixel
* @note this method set the height of the window


*/
GraphicEngine* GraphicEngine::setHeight(int h) { impl->height = h; return this; }
//get and set of autorefresh


/**
* @brief
* @param
* @return
* @note this method clear the opengl buffers
*/
GraphicEngine* GraphicEngine::clear() {

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	return this;
}

/**
* @brief
* @param keyboardCallback callback function to call when a key is pressed
* @return
* @note this method set the callback function to call when a key is pressed
*/
GraphicEngine* GraphicEngine::registerKeyboardActions(keyboardCallback callback) {
	//pass callback to glutkeybordfunc
	glutKeyboardFunc(callback);
	return this;
}
/**
* @brief
* @param keyboardSpecialCallback callback function to call when a special key is pressed
* @return
* @note this method set the callback function to call when a special key is pressed
*/
GraphicEngine* GraphicEngine::registerSpecialActions(keyboardSpecialCallback callback) {
	//pass callback to glutkeybordfunc
	glutSpecialFunc(callback);
	return this;
}

/**
* @brief
* @param std::string name name of the node
* @return std::vector<Node*> list of the node with the given name
* @note this method find all nodes that has the given name and return them in a vector
*/
std::vector<Node*> GraphicEngine::getNodeByName(std::string name) {
	//find nodes that has name passed as argument and return a list
	auto nodes = impl->objectList->getNodes();
	std::vector<Node*> nodesWithName;
	for (Node* node : nodes)
	{
		if (((Object*)node)->getName() == name) {
			nodesWithName.push_back(node);
		}
	}
	return nodesWithName;
}
/**
* @brief
* @param std::string name name of the node
*
*/
Node* GraphicEngine::addModelToScene(std::string string_filename) {
	//convert string
	const char* filename = string_filename.c_str();
	FILE* fp = fopen(filename, "rb");
	auto model = impl->getParser().uploadFile(fp);
	if (model != nullptr) {

		fclose(fp);
	}

	return model;

}
/**
* @brief
* @note this method swap the opengl buffers

*/
GraphicEngine* GraphicEngine::swap() {
	glutSwapBuffers();
	return this;
}


/*
* @brief
* @param
* @return Node* the pointer to the node
* @note this method create an empty node

*/
Node* GraphicEngine::createEmptyNode() {
	auto node = new Node();
	impl->objectList->push((Object*)node);
	return node;
}
/*
* @brief
* @param
* @return
* @note this method refresh the window

*/
GraphicEngine* GraphicEngine::refreshWindow() {
	glutPostWindowRedisplay(windowId);
	return this;
}
/*
* @brief
* @param
* @return
* @note this method return the instance of the graphic engine, if the instance is null it will create a new instance
*/
GraphicEngine* GraphicEngine::getInstance() {
	if (GraphicEngine::instance == NULL)
		GraphicEngine::instance = new GraphicEngine();
	return GraphicEngine::instance;
}

Node* GraphicEngine::createPrimitiveCube(float edge, std::string name, glm::mat4 transform, Texture* id) {
	Cube* cube = new Cube(edge, name, transform);

	impl->objectList->push((Object*)cube);
	return (Node*)cube;
}
/**
*@brief
* @param float x x position of the textbox
* @param float y y position of the textbox
* @param std::string text text to display
* @param glm::vec4 color color of the text
* @note this method create a text box with the given parameters

*/
TextBox* GraphicEngine::addTextBox(float x, float y, std::string text, glm::vec3 color) {
	auto tmp = new TextBox("TextBox", x, y, text, color.x, color.y, color.z);
	impl->objectList->push((Object*)tmp);
	return tmp;
}

GraphicEngine* GraphicEngine::lightModel(bool enable) {

	if (enable) {
		glEnable(GL_LIGHTING);
		glShadeModel(GL_SMOOTH);
		impl->lightModelStatus = true;
		//set global ambient light
		GLfloat ambient[] = { 0.2f, 0.2f, 0.2f, 1.0f };
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);
		//set local viewer
		glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);


	}
	else {
		glDisable(GL_LIGHTING);
		impl->lightModelStatus = false;
	}

	return this;
}
/**
* @brief
* @param
* @return
* @note this method return the engine version
*/
std::string GraphicEngine::getVersion() {
	return "0.1";
}
/*
* @brief
* @param
* @return
* @note this method update opengl rendering
*/

GraphicEngine* GraphicEngine::update() {

	glutMainLoopEvent();
	return this;
}
void GraphicEngine::free() {
	impl->initialized = false;
	//free glut window
	glutDestroyWindow(windowId);
	setClosed(true);
}
GraphicEngine* GraphicEngine::insertNode(Node* node)
{
	if (node->getChildrenNodes().size() > 0)
	{
		for (Node* child : node->getChildrenNodes())
		{
			insertNode(child);
		}
	}
	else {
		impl->objectList->push((Object*)node);
	}
	return this;

}
Camera* GraphicEngine::createProspectiveCamera(std::string name, glm::mat4 transform, float _near, float _far, float fov)
{
	auto camera = new ProspectiveCamera(name, transform, _near, _far, fov);
	impl->objectList->push((Object*)camera);
	return camera;
}


Light* GraphicEngine::createPointLight(std::string name, glm::mat4 transformMatrix, bool enable, glm::vec4 lightAmbient, glm::vec4 lightDiffuse, glm::vec4 lightSpecular) {

	auto light = new PointLight(name, transformMatrix, enable, lightAmbient, lightDiffuse, lightSpecular);
	impl->objectList->push((Object*)light);

	return light;


}



Light* GraphicEngine::createSpotLight(glm::vec3 direction, float cutoff, float exponent, std::string name, glm::mat4 transformMatrix, bool enable, glm::vec4 lightAmbient, glm::vec4 lightDiffuse, glm::vec4 lightSpecular) {

	auto light = new SpotLight(direction, cutoff, exponent, name, transformMatrix, enable, lightAmbient, lightDiffuse, lightSpecular);
	impl->objectList->push((Object*)light);

	return light;


}

Light* GraphicEngine::createDirectionalLight(glm::vec3 direction, std::string name, glm::mat4 transformMatrix, bool enable, glm::vec4 lightAmbient, glm::vec4 lightDiffuse, glm::vec4 lightSpecular) {

	auto light = new DirectionLight(direction, name, transformMatrix, enable, lightAmbient, lightDiffuse, lightSpecular);
	impl->objectList->push((Object*)light);

	return light;


}


Camera* GraphicEngine::createOrthographicCamera(std::string name, glm::mat4 transform, float _near, float _far, float left, float right, float top, float bottom)
{
	auto camera = new OrthographicCamera(name, transform, _near, _far, left, right, top, bottom);
	impl->objectList->push((Object*)camera);
	return camera;
}
GraphicEngine* GraphicEngine::setMainCamera(Camera* camera)
{
	Camera::setMainCamera(camera);

	return this;
}
Camera* GraphicEngine::getMainCamera()
{
	return Camera::getMainCamera();
}

//duplicate
ListItem* GraphicEngine::duplicate(Node* node, glm::mat4 transform, Material* material)
{
	if (material == nullptr)
		return impl->objectList->push(node, transform);
	else
		return impl->objectList->push(node, transform, material);

}

Texture* GraphicEngine::loadTexture(std::string filename)
{
	auto texture = new Texture(filename);
	impl->objectList->push((Object*)texture);
	return texture;
}
vector<Mesh*> GraphicEngine::getMeshes(Node* root)
{
	//get all meshes from the node and its children, using this function recursivly
	vector<Mesh*> meshes;
	//check if root is a mesh
	if (root->getType() == ObjectType::MESH)
	{
		meshes.push_back((Mesh*)root);
	}
	for (Node* child : root->getChildrenNodes())
	{
		auto tmp = getMeshes(child);
		meshes.insert(meshes.end(), tmp.begin(), tmp.end());
	}
	return meshes;
}
GraphicEngine* GraphicEngine::setWireframe(bool enable)
{
	if (enable)
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	}
	else {
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}
	return this;
}
vector<Material*> GraphicEngine::getMaterials() {
	vector<Material*> materials;
	for (Object* object : impl->objectList->getMaterials())
	{
		if (object->getType() == ObjectType::MATERIAL)
		{
			materials.push_back((Material*)object);
		}
	}
	return materials;
}

//get light
vector<Light*> GraphicEngine::getLights()
{
	vector<Light*> lights;
	for (Object* object : impl->objectList->getLights())
	{
		if (object->getType() == ObjectType::LIGHT)
		{
			lights.push_back((Light*)object);
		}
	}
	return lights;
}
//get cameras
vector<Camera*> GraphicEngine::getCameras()
{
	vector<Camera*> cameras;
	for (Object* object : impl->objectList->getCameras())
	{
		if (object->getType() == ObjectType::CAMERA)
		{
			cameras.push_back((Camera*)object);
		}
	}
	return cameras;
}
//get textures
vector<Texture*> GraphicEngine::getTextures()
{
	vector<Texture*> textures;
	for (Object* object : impl->objectList->getTextures())
	{
		if (object->getType() == ObjectType::TEXTURE)
		{
			textures.push_back((Texture*)object);
		}
	}
	return textures;
}


vector<Material*> GraphicEngine::getMaterialsByName(std::string name) {
	vector<Material*> materials;
	auto tmp = getMaterials();
	for (Object* obj : impl->objectList->getMaterials())
	{

		if (obj->getName() == name)
		{
			materials.push_back((Material*)obj);
		}

	}
	return materials;
}
GraphicEngine* GraphicEngine::setBackgroundColor(float r, float g, float b, float a)
{
	glClearColor(r, g, b, a);
	return this;
}
Material* GraphicEngine::createMaterial(std::string name, glm::vec4 ambient, glm::vec4 diffuse, glm::vec4 emission, glm::vec4 specular, float shininess)
{
	auto material = new Material(name, ambient, diffuse, specular, emission, shininess);
	impl->objectList->push((Object*)material);
	return material;
}

GraphicEngine* GraphicEngine::setStaticShadow(Mesh* mesh, Node* proiectionPlane, Material* material, glm::vec3 scaleVector, float offset) {


	auto shadow = impl->objectList->push(mesh, scaleVector, proiectionPlane, material, offset);


	return this;
}
bool GraphicEngine::getLightModel() {
	return impl->lightModelStatus;
}

int GraphicEngine::getNumberOfObjectsLoaded() {

	return impl->getObjectList()->size();

}


GraphicEngine* GraphicEngine::clearScene() {

	impl->getObjectList()->clear();
	return this;
}