#ifndef GRAPHICENGINE_H
#define GRAPHICENGINE_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Node.h"
#include "Camera.h"
#include "TextBox.h"
#include "Texture.h"
#include "GraphicEngine.h"
#include "ProspectiveCamera.h"
#include "OrthographicCamera.h"
#include "PointLight.h"
#include "SpotLight.h"
#include "DirectionLight.h"
#include "Material.h"
#include "Mesh.h"
#include "ListItem.h"
#include <iostream>
#include <vector>
#include <string>
#include <memory>

class LIB_API GraphicEngine {

private:



	struct Impl;
	std::unique_ptr<Impl> impl;

	static GraphicEngine* instance;

	~GraphicEngine();
	GraphicEngine();
public:
	/**
	 * Initialize openGL context
	 */

	GraphicEngine* init(int options, char* argv[], int width, int height, std::string windowName = "Window 1", bool show = true);
	GraphicEngine* openWindow();

	GraphicEngine* swap();
	/**
	 * Free the resources
	 */
	GraphicEngine* removeElement(Object* object);
	void free();


	//get and set of width and height
	//getter isClosed
	bool isClosed();
	float getFPS();
	GraphicEngine* setClosed(bool v);
	int getWidth();
	int getHeight();
	GraphicEngine* setWidth(int width);
	GraphicEngine* setHeight(int height);
	GraphicEngine* clear();
	typedef void(*keyboardCallback)(unsigned char, int, int);
	GraphicEngine* registerKeyboardActions(keyboardCallback callback);
	typedef void(*keyboardSpecialCallback)(int, int, int);
	GraphicEngine* registerSpecialActions(keyboardSpecialCallback callback);
	std::vector<Node*> getNodeByName(std::string name);
	Node* addModelToScene(std::string string_filename);
	Node* createEmptyNode();
	std::string getVersion();
	static GraphicEngine* getInstance();
	GraphicEngine* insertNode(Node* node);
	/**
	 * Method for DEBUG
	 */
	Node* createPrimitiveCube(float edge = 1, std::string name = "cube", glm::mat4 transform = glm::mat4(1.f), Texture* texture = nullptr);
	TextBox* addTextBox(float x, float y, std::string text = "New Text", glm::vec3 color = glm::vec3(1, 1, 1));
	Camera* createProspectiveCamera(std::string name = "Prospective Camera", glm::mat4 transform = glm::mat4(1.f), float near = 0.1f, float far = 100.f, float fov = 45);
	Camera* createOrthographicCamera(std::string name = "Ortographic Camera", glm::mat4 transform = glm::mat4(1.f), float near = 0.1f, float far = 100.f, float left = -1, float right = 1, float bottom = -1, float top = 1);
	GraphicEngine* setMainCamera(Camera* camera);
	Camera* getMainCamera();
	Light* createDirectionalLight(glm::vec3 direction, std::string name = "PointLight", glm::mat4 transformMatrix = glm::mat4(1), bool enable = true, glm::vec4 lightAmbient = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f), glm::vec4 lightDiffuse = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f), glm::vec4 lightSpecular = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f));
	Light* createPointLight(std::string name = "PointLight", glm::mat4 transformMatrix = glm::mat4(1), bool enable = true, glm::vec4 lightAmbient = glm::vec4(.8f, .8f, .8f, 1.0f), glm::vec4 lightDiffuse = glm::vec4(0.2f, .2f, .2f, 1.0f), glm::vec4 lightSpecular = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f));
	Light* createSpotLight(glm::vec3 direction, float cutoff, float exponent = 20.0f, std::string name = "PointLight", glm::mat4 transformMatrix = glm::mat4(1), bool enable = true, glm::vec4 lightAmbient = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f), glm::vec4 lightDiffuse = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f), glm::vec4 lightSpecular = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f));

	/**
	 * enable or disable the lightmodel
	 */
	GraphicEngine* lightModel(bool enable = true);
	GraphicEngine* refreshWindow();
	GraphicEngine* update();
	ListItem* duplicate(Node* node, glm::mat4 transform = glm::mat4(1.f), Material* newMaterial = nullptr);
	vector<Material*> getMaterialsByName(std::string name);


	Texture* loadTexture(std::string filename);
	vector<Mesh*> getMeshes(Node* root);
	GraphicEngine* setWireframe(bool enable = true);
	vector<Light*> getLights();
	vector<Material*> getMaterials();
	vector<Texture*> getTextures();
	vector<Camera*> getCameras();
	vector<Node*> getNodes();
	GraphicEngine* setBackgroundColor(float r = 0.0f, float g = 0.0f, float b = 0.0f, float a = 1.0f);
	Material* createMaterial(std::string name = "Material", glm::vec4 ambient = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f), glm::vec4 diffuse = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f), glm::vec4 emission = glm::vec4(0.f, 0.f, 0.f, 1.0f), glm::vec4 specular = glm::vec4(0.0f, 0.0f, 0.0f, 0.0f), float shininess = 0.0f);
	GraphicEngine* setStaticShadow(Mesh* mesh, Node* proiectionPlane, Material* shadowColor, glm::vec3 scaleVector = glm::vec3(1., 0, 1.), float offset = 0.);
	bool getLightModel();
	int getNumberOfObjectsLoaded();
	GraphicEngine* clearScene();
	
};

#endif
