#include "Light.h"

// GLM:      
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// FreeGLUT:
#include <GL/freeglut.h>

// C/C++:
#include <iostream>
#include <stdio.h>
#include <string>


using namespace std;




bool Light::setUpLight()  {

	
	if (getEnable())
	{
		
	
	// Draw a small emissive sphere to show light position:   
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, glm::value_ptr(glm::vec4(1.0f)));
	glutSolidSphere(0.5, 8, 8);
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, glm::value_ptr(glm::vec4(0.0f)));
	
	//attenuation
	
	
	glLightfv(light, GL_AMBIENT, glm::value_ptr(lightAmbient));
	glLightfv(light, GL_DIFFUSE, glm::value_ptr(lightDiffuse));
	glLightfv(light, GL_SPECULAR, glm::value_ptr(lightSpecular));
	return true;
	
	}else
	{
		return false;
	}





}

void Light::setLightAmbient(glm::vec4 lightAmbient) {
	this->lightAmbient = lightAmbient;
}
void Light::setLightDiffuse(glm::vec4 lightDiffuse) {
	this->lightDiffuse = lightDiffuse;
}
void Light::setLightSpecular(glm::vec4 lightSpecular) {
	this->lightSpecular = lightSpecular;
}

glm::vec4 Light::getLightAmbient() {
	return this->lightAmbient;
}
glm::vec4 Light::getLightDiffuse() {
	return this->lightDiffuse;
}




ObjectType Light::getType() {
	return this->type;
}

int Light::getLight() {
	return this->light;
}