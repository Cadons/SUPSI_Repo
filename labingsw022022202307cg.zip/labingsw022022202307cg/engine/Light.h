#ifndef LIGHT_H
#define LIGHT_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Node.h"

#include "Light.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "LightsStack.h"

class LIB_API Light : public Node {




public:

	Light(std::string name = "Light", glm::mat4 transformMatrix = glm::mat4(1), bool enable = true, glm::vec4 lightAmbient = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f), glm::vec4 lightDiffuse = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f), glm::vec4 lightSpecular = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f)) : Node(name, transformMatrix, enable) {


		this->lightAmbient = lightAmbient;
		this->lightDiffuse = lightDiffuse;
		this->lightSpecular = lightSpecular;
		

		assert(LightsStack::getInstance()->lightNum.empty() == false);


		this->light = LightsStack::getInstance()->lightNum.top();
		LightsStack::getInstance()->lightNum.pop();



	};
	virtual ~Light() {
		LightsStack::getInstance()->lightNum.push(this->light);
	};
	
	void render(){};
	int getLight();
	void setLightAmbient(glm::vec4 lightAmbient);
	void setLightDiffuse(glm::vec4 lightAmbient);
	void setLightSpecular(glm::vec4 lightAmbient);
	glm::vec4 getLightAmbient();
	glm::vec4 getLightDiffuse();
	glm::vec4 getLightSpecular();
	
	ObjectType getType() override;
private:
	ObjectType type= ObjectType::LIGHT;



	glm::vec4 lightAmbient;
	glm::vec4 lightDiffuse;
	glm::vec4 lightSpecular;

protected:

	int light;
	bool setUpLight();


};

#endif
