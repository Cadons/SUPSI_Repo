#include "LightsStack.h"
// FreeGLUT:
#include <GL/freeglut.h>

// C/C++:
#include <iostream>
#include <stdio.h>
#include <string>



LightsStack* LightsStack::instance{ nullptr };


LightsStack* LightsStack::getInstance() {

	if (instance == nullptr) {
		instance = new LightsStack();
		//init light 
		instance->lightNum.push(GL_LIGHT7);
		instance->lightNum.push(GL_LIGHT6);
		instance->lightNum.push(GL_LIGHT5);
		instance->lightNum.push(GL_LIGHT4);
		instance->lightNum.push(GL_LIGHT3);
		instance->lightNum.push(GL_LIGHT2);
		instance->lightNum.push(GL_LIGHT1);
		instance->lightNum.push(GL_LIGHT0);
		
		glDisable(GL_LIGHT0);
		glDisable(GL_LIGHT1);
		glDisable(GL_LIGHT2);
		glDisable(GL_LIGHT3);
		glDisable(GL_LIGHT4);
		glDisable(GL_LIGHT5);
		glDisable(GL_LIGHT6);
		glDisable(GL_LIGHT7);
		
	}
	
	return instance;

}