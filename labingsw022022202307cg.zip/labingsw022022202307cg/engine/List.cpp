#include "List.h"
#include "Node.h"
#include "Camera.h"
#include "GUIElement.h"
#include "GL/freeglut.h"
#include <glm/gtc/type_ptr.hpp>


List* List::instance{ nullptr };
ListItem* List::push(Object* obj) {
	//check if the object is already in the list through ID
	if (this->objects.size() > 0) {
		for (auto it = this->objects.begin(); it != this->objects.end(); it++) {
			if ((*it)->getObject()->getID() == obj->getID()) {
				//if the object is already in the list, return
				return nullptr;
			}
		}
	}
	auto node = new ListItem(obj);
	this->objects.push_back(node);
	return node;
}
ListItem* List::push(Node* obj, glm::mat4 matrix) {
	auto node = new ListItem(obj, matrix);
	this->objects.push_back(node);
	return node;
}
ListItem* List::push(Node* obj, glm::mat4 matrix, Material* material) {

	auto node = this->push(obj, matrix);
	this->objects.back()->setMaterial(material);
	return node;
}
ListItem* List::push(Mesh* obj, glm::vec3 scale, Node* plane, Material* material, float offset) {
	auto node = new StaticShadow(obj, scale, plane, material, offset);
	auto item = new ListItem(node);
	this->objects.push_back(item);
	return item;
}
void List::sort() {
	//sort objects list per type 
	objects.sort([](ListItem* a, ListItem* b) {return a->getObject()->getType() < b->getObject()->getType(); });

}

void List::clear() {
	objects.clear();
}
void List::remove(Object* obj) {

	for (auto it = this->objects.begin(); it != this->objects.end(); it++) {
		if ((*it)->getObject()->getID() == obj->getID()) {
			//if the object is already in the list, return
			objects.erase(it);
			return;
		}
	}
}
void List::render() {
	//print objects list

	sort();
	for (auto it = objects.begin(); it != objects.end(); it++) {



		if (dynamic_cast<GUIElement*>((*it)->getObject()) == nullptr) {
			if (dynamic_cast<StaticShadow*>((*it)->getObject()) != nullptr)
			{
				StaticShadow* shadow = (StaticShadow*)(*it)->getObject();
				shadow->render();

			}
			else	if (dynamic_cast<Node*>((*it)->getObject()) != nullptr) {
				//get node
				Material* originalMaterial = nullptr;
				Node* node = (Node*)(*it)->getObject();
				glm::mat4 mat = glm::mat4(1.0f);
				//if the object is a node, check if it is visible

				if (node->getEnable()) {



					if ((*it)->isDuplicated()) {
						mat = glm::inverse(Camera::getMainCamera()->getMatrix()) * (*it)->getMatrix();
						if (dynamic_cast<Mesh*>(node) != nullptr) {

							if ((*it)->getMaterial() != nullptr) {
								originalMaterial = ((Mesh*)node)->getMaterial();
								((Mesh*)node)->setMaterial((*it)->getMaterial());
							}


						}

					}
					else {
						mat = glm::inverse(Camera::getMainCamera()->getMatrix()) * node->getMatrix();
					}
					glLoadMatrixf(glm::value_ptr(mat));

					(*it)->getObject()->render();
					if (originalMaterial != nullptr) {
						((Mesh*)node)->setMaterial(originalMaterial);

					}
				}
				else {
					//update lights, disable 
					if (dynamic_cast<Light*>((*it)->getObject()) != nullptr)
						(*it)->getObject()->render();



				}
			}
		}

	}
}
List* List::getInstance()
{
	static List instance;
	return &instance;
}
std::string List::toString() {
	std::string str = "";
	//get elements from list
	std::list<ListItem*>::iterator it = this->objects.begin();
	for (int i = 0; i < this->objects.size(); i++) {
		str += (*it)->getObject()->toString() + "\n";

		advance(it, 1);
	}
	return str;
}
std::list<Node*> List::getNodes() {
	std::list<Node*> nodes;
	for (auto it = objects.begin(); it != objects.end(); it++) {
		if (dynamic_cast<Node*>((*it)->getObject()) != nullptr) {
			nodes.push_back(dynamic_cast<Node*>((*it)->getObject()));
		}
	}
	return nodes;
}

ObjectType List::getType() {
	return ObjectType::NO_RENDER;
}

std::list<Object*> List::getElementsByType(ObjectType type) {
	std::list<Object*> elements;
	for (auto it = objects.begin(); it != objects.end(); it++) {
		if ((*it)->getObject()->getType() == type) {
			elements.push_back((*it)->getObject());
		}
	}
	return elements;
}

int List::size() {
	return objects.size();
}

Object* List::get(int index) {
	if (index < objects.size()) {
		std::list<ListItem*>::iterator it = objects.begin();
		advance(it, index);
		return (*it)->getObject();
	}
	return nullptr;
}
std::list<Object*> List::getObjects() {
	std::list<Object*> objects;
	for (auto it = this->objects.begin(); it != this->objects.end(); it++) {
		objects.push_back((*it)->getObject());
	}
	return objects;
}
//implments methods
std::list<Material*> List::getMaterials() {
	std::list<Material*> materials;
	for (auto it = objects.begin(); it != objects.end(); it++) {
		if (dynamic_cast<Material*>((*it)->getObject()) != nullptr) {
			materials.push_back(dynamic_cast<Material*>((*it)->getObject()));
		}
	}
	return materials;
}
std::list<Light*> List::getLights() {
	std::list<Light*> lights;
	for (auto it = objects.begin(); it != objects.end(); it++) {
		if (dynamic_cast<Light*>((*it)->getObject()) != nullptr) {
			lights.push_back(dynamic_cast<Light*>((*it)->getObject()));
		}
	}
	return lights;
}
std::list<Camera*> List::getCameras() {
	std::list<Camera*> cameras;
	for (auto it = objects.begin(); it != objects.end(); it++) {
		if (dynamic_cast<Camera*>((*it)->getObject()) != nullptr) {
			cameras.push_back(dynamic_cast<Camera*>((*it)->getObject()));
		}
	}
	return cameras;
}

//get textures
std::list<Texture*> List::getTextures() {
	std::list<Texture*> textures;
	for (auto it = objects.begin(); it != objects.end(); it++) {
		if (dynamic_cast<Texture*>((*it)->getObject()) != nullptr) {
			textures.push_back(dynamic_cast<Texture*>((*it)->getObject()));
		}
	}
	return textures;
}
