#ifndef LIST_H
#define LIST_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Object.h"
#include "Node.h"
#include "ListItem.h"
#include <list>
#include "Material.h"
#include "Mesh.h"
#include "Texture.h"
#include "Camera.h"
#include "Light.h"
#include "StaticShadow.h"
class LIB_API List : Object {

private:
	std::list<ListItem*> objects;

	static List* instance;
	List() {

	};
public:

	void sort();
	static List* getInstance();
	ListItem* push(Object* object);
	ListItem* push(Node* object, glm::mat4 matrix);
	ListItem* push(Node* object, glm::mat4 matrix, Material* material);
	ListItem* push(Mesh* object, glm::vec3 scale, Node* plane, Material* material, float offset = 1.0f);
	std::list<Node*> getNodes();
	std::list<Material*> getMaterials();
	std::list<Texture*> getTextures();
	std::list<Light*> getLights();
	std::list<Camera*> getCameras();
	std::list<Object*> getObjects();
	std::list<Object*> getElementsByType(ObjectType t);
	Object* get(int index);
	void clear();
	//for debug
	std::string toString();
	void render() override;
	void remove(Object* object);
	virtual ~List() {
		//free memory
		objects.clear();
	}
	ObjectType getType() override;
	int size();
};

#endif
