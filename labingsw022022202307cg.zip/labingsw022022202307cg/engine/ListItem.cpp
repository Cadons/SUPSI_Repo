#include "ListItem.h"

//getter
Object* ListItem::getObject() {
	return object;
}
glm::mat4 ListItem::getMatrix() {
	return matrix;
}
ListItem* ListItem::setMatrix(glm::mat4 matrix) {
	this->matrix = matrix;
	return this;
}
bool ListItem::isDuplicated() {
	return duplicated;
}
//setter
ListItem* ListItem::setMaterial(Material* material) {
	this->material = material;
	return this;
}
//getter
Material* ListItem::getMaterial() {
	return material;
}
