#ifndef LISTITEM_H
#define LISTITEM_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif

#include "Object.h"
#include "glm/glm.hpp"
#include "Material.h"
class LIB_API ListItem
{
private:
	Object* object;
	glm::mat4 matrix;
	Material* material=nullptr;
	bool duplicated;

public:
	ListItem(Object* object, glm::mat4 matrix){
		this->object = object;
		this->matrix = matrix;
		this->duplicated = true;
	}
	ListItem(Object* object) {
		this->object = object;
		this->matrix = glm::mat4(1.0f);
		this->duplicated = false;
	}
	//destructor
	virtual ~ListItem() {
		if (!duplicated) {
			delete object;
		}
	}
	ListItem* setMaterial(Material* material);
	Material* getMaterial();
	Object* getObject();
	glm::mat4 getMatrix();	
	ListItem* setMatrix(glm::mat4 matrix);
	bool isDuplicated();

};
#endif

