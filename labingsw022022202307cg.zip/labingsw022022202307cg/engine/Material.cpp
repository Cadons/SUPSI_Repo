#include "Material.h"
#include "glm/glm.hpp"
#include "GL/freeglut.h"
#include <glm/gtc/type_ptr.hpp>
#include "GraphicEngine.h"
void Material::render() {
	
	if (GraphicEngine::getInstance()->getLightModel()) {
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, glm::value_ptr(this->ambient));
		glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, glm::value_ptr(this->diffuse));
		glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, glm::value_ptr(this->specular));
		glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, glm::value_ptr(this->emission));
		glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, this->shininess);
	}
	if (texture != nullptr)
			texture->render();
		else
			glDisable(GL_TEXTURE_2D);

	

}
void Material::reset() {
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, glm::value_ptr(glm::vec4(1.0f)));
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, glm::value_ptr(glm::vec4(1.0f)));
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, glm::value_ptr(glm::vec4(1.0f)));
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, glm::value_ptr(glm::vec4(0.0f, 0.0f, 0.0f, 1.0f)));
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 1.0f);
	glDisable(GL_TEXTURE_2D);

}

void Material::setAmbient(glm::vec4 ambient) {
	this->ambient = ambient;
}
void Material::setDiffuse(glm::vec4 diffuse) {
	this->diffuse = diffuse;
}

void Material::setSpecular(glm::vec4 specular) {
	this->specular = specular;
}

void Material::setEmission(glm::vec4 emission) {
	this->emission = emission;
}
ObjectType Material::getType() {
	return this->type;
}

void Material::setShininess(float lightIntensity) {
	this->shininess = lightIntensity;
}

glm::vec4 Material::getAmbient() {
	return this->ambient;
}

glm::vec4 Material::getDiffuse() {
	return this->diffuse;
}

glm::vec4 Material::getSpecular() {
	return this->specular;
}

glm::vec4 Material::getEmission() {
	return this->emission;
}

float Material::getShininess() {
	return this->shininess;
}
void Material::setTexture(Texture* texture) {
	this->texture = texture;
}
std::string Material::toString() {
	return Object::toString() + " Shininess: " + std::to_string(this->getShininess());
}

