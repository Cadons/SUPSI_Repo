#ifndef MATERIAL_H
#define MATERIAL_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Object.h"
#include "glm/glm.hpp"
#include "Texture.h"
class LIB_API Material : public Object {

private:
	glm::vec4 ambient;
	glm::vec4 diffuse;
	glm::vec4 specular;
	glm::vec4 emission;
	float shininess;
	Texture* texture = nullptr;
	ObjectType type = ObjectType::MATERIAL;
public:
	Material(std::string name, glm::vec4 ambient = glm::vec4(1.0f), glm::vec4 diffuse = glm::vec4(1.0f), glm::vec4 specular = glm::vec4(1.0f), glm::vec4 emission = glm::vec4(1.0f), float shininess = 1.0f) : Object(name) {
		this->ambient = ambient;
		this->diffuse = diffuse;
		this->specular = specular;
		this->emission = emission;
		this->shininess = shininess;

	}

	virtual ~Material() {
		//free memory
		delete texture;

	}
	void setTexture(Texture* texture);
	Material() : Object("Material") {}
	static void reset();
	void render() ;

	glm::vec4 getAmbient();

	void setAmbient(glm::vec4 ambient);

	glm::vec4 getDiffuse();

	void setDiffuse(glm::vec4 diffuse);

	glm::vec4 getSpecular();

	void setSpecular(glm::vec4 specular);

	glm::vec4 getEmission();

	void setEmission(glm::vec4 emission);

	float getShininess();

	void setShininess(float lightIntensity);
	
	ObjectType getType() override;
	
	std::string toString() override;
};

#endif
