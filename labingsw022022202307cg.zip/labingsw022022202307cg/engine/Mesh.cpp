#include "Mesh.h"
#include <iostream>
#include "GL/freeglut.h"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
void Mesh::render() {
	//enab
	vector<Mesh::Vertex> verteces = getVertices();
	vector<Mesh::Face> faces = getFaces();

	if (material != nullptr)
		this->material->render();

	for (int i = 0; i < faces.size(); i++)
	{
		


		
		glBegin(GL_TRIANGLES);

		
		glTexCoord2f(verteces[faces[i].v1].texCoords.x, verteces[faces[i].v1].texCoords.y);
		glNormal3f(verteces[faces[i].v1].normal.x, verteces[faces[i].v1].normal.y, verteces[faces[i].v1].normal.z);
		glVertex3f(verteces[faces[i].v1].position.x, verteces[faces[i].v1].position.y, verteces[faces[i].v1].position.z);
		glNormal3f(verteces[faces[i].v2].normal.x, verteces[faces[i].v2].normal.y, verteces[faces[i].v2].normal.z);
		glTexCoord2f(verteces[faces[i].v2].texCoords.x, verteces[faces[i].v2].texCoords.y);
		glVertex3f(verteces[faces[i].v2].position.x, verteces[faces[i].v2].position.y, verteces[faces[i].v2].position.z);
		
		glNormal3f(verteces[faces[i].v3].normal.x, verteces[faces[i].v3].normal.y, verteces[faces[i].v3].normal.z);
		glTexCoord2f(verteces[faces[i].v3].texCoords.x, verteces[faces[i].v3].texCoords.y);
		glVertex3f(verteces[faces[i].v3].position.x, verteces[faces[i].v3].position.y, verteces[faces[i].v3].position.z);

		glEnd();

	}
	//reset material

	Material::reset();

}

string Mesh::getMaterialName() {
	if (this->materialName == "")
		return "null";
	return this->materialName;
}

void Mesh::setMaterialName(string materialName) {
	this->materialName = materialName;
}

Material* Mesh::getMaterial() {
	return this->material;
}
std::string Mesh::toString() {

	return Node::toString() + " Material: " + this->getMaterialName();

}
void Mesh::setMaterial(Material* material) {

	this->material = material;
}

void Mesh::setVertices(vector<Vertex> vector) {
	this->vertices = vector;
}
ObjectType Mesh::getType() {
	return this->type;
}

vector<Mesh::Vertex> Mesh::getVertices() {
	return this->vertices;
}

void Mesh::setFaces(vector<Face> faces) {
	this->faces = faces;
}

vector<Mesh::Face> Mesh::getFaces() {
	return this->faces;
}
