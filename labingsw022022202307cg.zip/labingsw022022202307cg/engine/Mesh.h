#ifndef MESH_H
#define MESH_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Node.h"
#include "Material.h"
#include <vector>
#include "Texture.h"
using namespace std;
class LIB_API Mesh : public Node {
public:
	struct Vertex {
		glm::vec3 position;
		glm::vec4 normal;
		glm::vec2 texCoords;
		glm::vec4 texTangent;
	};
	struct Face {
		
	public:
		unsigned int v1, v2, v3;
		Face(unsigned int v1, unsigned int v2, unsigned int v3) {
			this->v1 = v1;
			this->v2 = v2;
			this->v3 = v3;
		}
		
	 };
protected:

	Material* material=nullptr;
	string materialName;
	vector<Vertex> vertices;
	vector<Face> faces;
 	ObjectType type = ObjectType::MESH;

public:

	void setMaterialName(string materialName);

	string getMaterialName();

	Material* getMaterial();

	void setMaterial(Material* material);

	void setVertices(vector<Vertex> vertices);
	
	void setFaces(vector<Face> faces);
	
	vector<Vertex> getVertices();
	
	vector<Face> getFaces();

	void render() override;

	ObjectType getType() override;
	
	std::string toString() override;
	
	Mesh(std::string name = "Mesh", glm::mat4 transformMatrix = glm::mat4(1), bool enable = true) :Node(name, transformMatrix, enable) {

	}

	virtual ~Mesh() {
	
		delete material;
	}

	
};

#endif
