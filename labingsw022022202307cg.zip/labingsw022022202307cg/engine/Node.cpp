#include "Node.h"
#include "List.h"
#include <iostream>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "GL/freeglut.h"
#include <glm/gtx/string_cast.hpp>
glm::mat4 Node::getMatrix() {
	if (this->parentNode != nullptr)
		if (transformMatrix != localMatrix)
			return this->parentNode->getMatrix() * this->transformMatrix * this->localMatrix;
		else
			return this->parentNode->getMatrix() * this->localMatrix;

	return this->transformMatrix;
}

Node* Node::setMatrix(glm::mat4 transformMatrix) {
	this->transformMatrix = transformMatrix;
	return this;
}
Node* Node::getRootNode() {
    if (this->parentNode != nullptr)
        return this->parentNode->getRootNode();
    return this;
}
Node* Node::getParentNode() {
	
	return this->parentNode;
}
Node * Node::unsetParentNode() {
    this->getParentNode()->removeChildrenNode(this);



    return this;
}
Node* Node::setParentNode(Node* parentNode) {
	
	this->parentNode = parentNode;
	
	return this;
}

std::vector<Node*> Node::getChildrenNodes() {
	return this->childrenNodes;
}

Node* Node::addChildrenNode(Node* child) {
	child->setParentNode(this);

	this->childrenNodes.push_back(child);
	return this;
}

Node* Node::removeChildrenNode(Node* child) {
	// this function delete the child from the childrenNodes vector and return it

	if (this->childrenNodes.size() > 0) {
		for (int i = 0; i < this->childrenNodes.size(); i++) {
			if (this->childrenNodes[i]->getID() == child->getID()) {
				this->childrenNodes[i]->setParentNode(getRootNode());
				this->childrenNodes.erase(this->childrenNodes.begin() + i);
				
				break;
			}
		}
	
	}
	return this;

}
void Node::render() {
	//std::cout << "Node render "<<this->getName() << std::endl;
}
Node* Node::setLocalMatrix(glm::mat4 localMatrix) {
    this->localMatrix = localMatrix;
    return this;
}
glm::mat4 Node::getLocalMatrix() {
    return this->localMatrix;
}
bool Node::getEnable() {
	//inherit from parent
	if (this->parentNode != nullptr) {
		if (this->enable) {
			return this->parentNode->getEnable();
		}
		else {
			return false;
		}
	}
	return this->enable;
}

Node* Node::setEnable(int enable) {

		
	
	
	this->enable = enable;
	return this;
}


std::string Node::toString() {
	return "Node: " + this->getName() + "Position: " + glm::to_string(this->getMatrix());

}

ObjectType Node::getType() {
	return this->type;
}

void Node::setChildrenCount(int children) {
	this->childrenCount = children;
}

int Node::getChildrenCount() {
	return this->childrenCount;
}