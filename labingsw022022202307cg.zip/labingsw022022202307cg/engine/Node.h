#ifndef NODE_H
#define NODE_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Object.h"
#include "glm/glm.hpp"
#include <vector>

class LIB_API Node : public Object {

private:
	glm::mat4 transformMatrix;//this is the matrix that will be used to transform the object related to the parent
	glm::mat4 localMatrix;//this is the matrix that will be used to transform the object related to the object
	Node* parentNode=nullptr;
	std::vector<Node*> childrenNodes;
	bool enable;
	int childrenCount = 0;
	Node* setParentNode(Node* parentNode);
	ObjectType type = ObjectType::NODE;
    Node* getRootNode();
public:
	glm::mat4 getMatrix();

	Node* setMatrix(glm::mat4 transformMatrix = glm::mat4(1));

	Node* getParentNode();
    Node* setLocalMatrix(glm::mat4 localMatrix);
    glm::mat4 getLocalMatrix();
	Node* unsetParentNode();
	std::vector<Node*> getChildrenNodes();

	Node* addChildrenNode(Node* child);
	Node* removeChildrenNode(Node* child);
	ObjectType getType() override;
	void render() override;

	bool getEnable();

	Node* setEnable(int enable);
	void setChildrenCount(int children);

	int getChildrenCount();

	//constructor and destructor
	Node(std::string name = "Node", glm::mat4 transformMatrix = glm::mat4(1), bool enable = true) :Object(name) {
		this->transformMatrix = transformMatrix;
		this->parentNode = parentNode;
		this->enable = enable;
		this->localMatrix = transformMatrix;
	}
	
	virtual ~Node() {
		delete parentNode;
		for (int i = 0; i < childrenNodes.size(); i++) {
			delete childrenNodes[i];
		}
	}
	std::string toString() override;
	
		
	
};

#endif
