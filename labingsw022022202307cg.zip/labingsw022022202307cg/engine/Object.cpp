#include "Object.h"

unsigned int Object::id = 0;
unsigned int Object::getID() {
	return this->__id;
}

std::string Object::getName() {
	return this->name;
}

void Object::setName(std::string name) {
	this->name = name;
}


std::string Object::toString() {
	std::string output = this->name;
	return output;
}
