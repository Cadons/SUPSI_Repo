#include "OvoParser.h"
#include "OvLight.h"
#include "OvObject.h"
#include "OvMesh.h"
#include "Material.h"
#include "Mesh.h"
#include "Light.h"
#include "PointLight.h"
#include "SpotLight.h"
#include "DirectionLight.h"
#include "Object.h"
#include <glm/glm.hpp>
#include <glm/gtc/packing.hpp>
#include <vector>
#include <iostream>
#include <iomanip>
#include <limits.h>
#include <cmath>
// Macro for printing an OvMatrix4 to console:
#define MAT2STR(m) cout << "   Matrix  . . . :  \t" << m[0][0] << "\t" << m[1][0] << "\t" << m[2][0] << "\t" << m[3][0] << std::endl \
                           << "                    \t" << m[0][1] << "\t" << m[1][1] << "\t" << m[2][1] << "\t" << m[3][1] << std::endl \
                           << "                    \t" << m[0][2] << "\t" << m[1][2] << "\t" << m[2][2] << "\t" << m[3][2] << std::endl \
                           << "                    \t" << m[0][3] << "\t" << m[1][3] << "\t" << m[2][3] << "\t" << m[3][3] << std::endl


using namespace std;
unsigned int chunkId, chunkSize;
bool verbose = false;
vector<Object*> nodesList;
Node* OvoParser::uploadFile(FILE* file) {
   
        
   
	nodesList.clear();
    if (file == nullptr)
    {
        cout << "ERROR: unable to open file " << endl;
        return nullptr;
    }

    while (true)
    {
        fread(&chunkId, sizeof(unsigned int), 1, file);
        if (feof(file))
            break;
        fread(&chunkSize, sizeof(unsigned int), 1, file);

        char* data = new char[chunkSize];
        if (fread(data, sizeof(char), chunkSize, file) != chunkSize)
        {
            cout << "ERROR: unable to read from file " << endl;
            fclose(file);
            delete[] data;
			return nullptr;
        }

        unsigned int position = 0;

        switch ((OvObject::Type)chunkId)
        {

        case OvObject::Type::OBJECT:
        {
            parseObjectChunk(file, data, position);
        }
        break;

        case OvObject::Type::NODE:
        {
            parseNodeChunk(file, data, position);
        }
        break;

        case OvObject::Type::MATERIAL:
        {
            parseMaterialChunk(file, data, position);
        }
        break;

        case OvObject::Type::LIGHT:
        {
            parseLightChunk(file, data, position);
        }
        break;

        case OvObject::Type::MESH:
        {
            parseMeshChunk(file, data, position);
        }
        break;

        default:
            cout << "UNKNOWN]" << endl;
            cout << "ERROR: corrupted or bad data in file" << endl;
            fclose(file);
            delete[] data;
            return nullptr;
        }
    }
    // Done:
    addMaterialToMesh();
    Node* root = buildSceneGraph();
    cout << "\nResources Loaded" << endl;
    
    return root;
    
}

void OvoParser::parseObjectChunk(FILE* file, char* data, unsigned int& position) {


    // OVO revision number:
    unsigned int versionId;
    memcpy(&versionId, data + position, sizeof(unsigned int));
    position += sizeof(unsigned int);


}

void OvoParser::parseNodeChunk(FILE* file, char* data, unsigned int& position) {
    unsigned int chunkId1, chunkSize1;
    //cout << "node]" << endl;

    // Node name:
    char nodeName[FILENAME_MAX];
    strcpy(nodeName, data + position);


    position += (unsigned int)strlen(nodeName) + 1;

    // Node matrix:
    glm::mat4 matrix;
    memcpy(&matrix, data + position, sizeof(glm::mat4));

    position += sizeof(glm::mat4);

    Node* node = new Node(nodeName, matrix, true);

    // Nr. of children nodes:
    unsigned int children;
    memcpy(&children, data + position, sizeof(unsigned int));

    position += sizeof(unsigned int);

    node->setChildrenCount(children);

    // Optional target node, [none] if not used:
    char targetName[FILENAME_MAX];
    strcpy(targetName, data + position);

    position += (unsigned int)strlen(targetName) + 1;
    nodesList.push_back((Object*)node);

}

void OvoParser::parseMaterialChunk(FILE* file, char* data, unsigned int& position) {


    //cout << "material]" << endl;

    // Material name:
    char materialName[FILENAME_MAX];
    strcpy(materialName, data + position);
    Material* material = new Material(materialName);
    position += (unsigned int)strlen(materialName) + 1;

    // Material term colors, starting with emissive:
    glm::vec3 emission, albedo;
    glm::vec4 emissionAlpha, ambient, diffuse, specular, albedoAlpha;
    memcpy(&emission, data + position, sizeof(glm::vec3));
    emissionAlpha = glm::vec4(emission, 1.0f);

    material->setEmission(emissionAlpha);
    position += sizeof(glm::vec3);

    // Albedo:
    memcpy(&albedo, data + position, sizeof(glm::vec3));

    albedoAlpha = glm::vec4(albedo, 1.0f);
    ambient = albedoAlpha * 0.2f;
    diffuse = albedoAlpha * 0.6f;
    specular = albedoAlpha * 0.4f;
    material->setAmbient(ambient);
    material->setDiffuse(diffuse);
    material->setSpecular(specular);
    position += sizeof(glm::vec3);

    // Roughness factor:
    float roughness, shininess;
    memcpy(&roughness, data + position, sizeof(float));

    shininess = (1.0f - sqrt(roughness)) * 128.0f;
    material->setShininess(shininess);
    position += sizeof(float);

    // Metalness factor:
    float metalness;
    memcpy(&metalness, data + position, sizeof(float));

    position += sizeof(float);

    // Transparency factor:
    float alpha;
    memcpy(&alpha, data + position, sizeof(float));

    position += sizeof(float);

    // Albedo texture filename, or [none] if not used:
    char textureName[FILENAME_MAX];
    strcpy(textureName, data + position);
    //convert texutreName to string
	if (strcmp(textureName, "[none]") != 0)
	{
        auto textures = List::getInstance()->getTextures();
		bool newTexture = true;
		
        //convert texturename to string
		auto textureNameString = std::string(textureName);
        
        
		for (auto texture : textures)
		{
            
			if (texture->getName()== textureNameString)
			{
				material->setTexture(texture);
				newTexture = false;
				break;
			}
		}
		if (newTexture)
		{
			Texture* texture = new Texture(textureNameString, textureNameString);
			material->setTexture(texture);
			List::getInstance()->push(texture);
		}
     

	}
    position += (unsigned int)strlen(textureName) + 1;

    // Normal map filename, or [none] if not used:
    char normalMapName[FILENAME_MAX];
    strcpy(normalMapName, data + position);

    position += (unsigned int)strlen(normalMapName) + 1;

    // Height map filename, or [none] if not used:
    char heightMapName[FILENAME_MAX];
    strcpy(heightMapName, data + position);

    position += (unsigned int)strlen(heightMapName) + 1;

    // Roughness map filename, or [none] if not used:
    char roughnessMapName[FILENAME_MAX];
    strcpy(roughnessMapName, data + position);

    position += (unsigned int)strlen(roughnessMapName) + 1;

    // Metalness map filename, or [none] if not used:
    char metalnessMapName[FILENAME_MAX];
    strcpy(metalnessMapName, data + position);

    position += (unsigned int)strlen(metalnessMapName) + 1;

    //materials.push_back(material);
    nodesList.push_back((Object*)material);
    List::getInstance()->push((Object*)material);
}

void OvoParser::parseMeshChunk(FILE* file, char* data, unsigned int& position) {

    //cout << "mesh]" << endl;

    // Mesh name:
    char meshName[FILENAME_MAX];

    strcpy(meshName, data + position);
    position += (unsigned int)strlen(meshName) + 1;
    //cout << "   Name  . . . . :  " << meshName << endl;


    // Mesh matrix:
    glm::mat4 matrix;
    memcpy(&matrix, data + position, sizeof(glm::mat4));
   // MAT2STR(matrix);
    position += sizeof(glm::mat4);

    Mesh* mesh = new Mesh(meshName, matrix, true);
    // Mesh nr. of children nodes:
    unsigned int children;
    memcpy(&children, data + position, sizeof(unsigned int));

    position += sizeof(unsigned int);

    ((Node*)mesh)->setChildrenCount(children);
    // Optional target node, or [none] if not used:
    char targetName[FILENAME_MAX];
    strcpy(targetName, data + position);

    position += (unsigned int)strlen(targetName) + 1;

    // Mesh subtype (see OvMesh SUBTYPE enum):
    unsigned char subtype;
    memcpy(&subtype, data + position, sizeof(unsigned char));
    char subtypeName[FILENAME_MAX];
    switch ((OvMesh::Subtype)subtype)
    {
    case OvMesh::Subtype::DEFAULT: strcpy(subtypeName, "standard"); break;
    case OvMesh::Subtype::NORMALMAPPED: strcpy(subtypeName, "normal-mapped"); break;
    case OvMesh::Subtype::TESSELLATED: strcpy(subtypeName, "tessellated"); break;
    default: strcpy(subtypeName, "UNDEFINED");
    }
    position += sizeof(unsigned char);

    // Material name, or [none] if not used:
    char materialName[FILENAME_MAX];
    strcpy(materialName, data + position);

    mesh->setMaterialName(materialName);
    position += (unsigned int)strlen(materialName) + 1;

    // Mesh bounding sphere radius:
    float radius;
    memcpy(&radius, data + position, sizeof(float));
    //cout << "   Radius  . . . :  " << radius << endl;
    position += sizeof(float);

    // Mesh bounding box minimum corner:
    glm::vec3 bBoxMin;
    memcpy(&bBoxMin, data + position, sizeof(glm::vec3));

    position += sizeof(glm::vec3);

    // Mesh bounding box maximum corner:
    glm::vec3 bBoxMax;
    memcpy(&bBoxMax, data + position, sizeof(glm::vec3));

    position += sizeof(glm::vec3);

    // skip physics properties:
    position += sizeof(unsigned char);

    // Nr. of LODs:
    unsigned int LODs;
    memcpy(&LODs, data + position, sizeof(unsigned int));

    position += sizeof(unsigned int);

    // For each LOD...:
    vector<unsigned int> verticesPerLOD(LODs); // Let's store this information for the skinned part, in case
	vector<Mesh::Vertex> meshVertices;
	vector<Mesh::Face> meshFaces;

    for (unsigned int l = 0; l < 1; l++)
    {
        // Nr. of vertices:
        unsigned int vertices, faces;
        memcpy(&vertices, data + position, sizeof(unsigned int));
        //cout << "   Nr. vertices  :  " << vertices << endl;
        position += sizeof(unsigned int);
        verticesPerLOD[l] = vertices;

        // ...and faces:
        memcpy(&faces, data + position, sizeof(unsigned int));
        // cout << "   Nr. faces . . :  " << faces << endl;
        position += sizeof(unsigned int);

        // Interleaved and compressed vertex/normal/UV/tangent data:
        for (unsigned int c = 0; c < vertices; c++)
        {
            Mesh::Vertex meshVertex;
            // Vertex coords:
            glm::vec3 vertex;
            memcpy(&vertex, data + position, sizeof(glm::vec3));

            meshVertex.position = vertex;
            position += sizeof(glm::vec3);

            // Vertex normal:
            unsigned int normalData;
            memcpy(&normalData, data + position, sizeof(unsigned int));

            meshVertex.normal = glm::unpackSnorm3x10_1x2(normalData);
            position += sizeof(unsigned int);

            // Texture coordinates:
            unsigned int textureData;
            memcpy(&textureData, data + position, sizeof(unsigned int));

            meshVertex.texCoords = glm::unpackHalf2x16(textureData);
            position += sizeof(unsigned int);

            // Tangent vector:
            unsigned int tangentData;
            memcpy(&tangentData, data + position, sizeof(unsigned int));

            meshVertex.texTangent = glm::unpackSnorm3x10_1x2(tangentData);
            position += sizeof(unsigned int);
            meshVertices.push_back(meshVertex);
        }

        // Faces:
        for (unsigned int c = 0; c < faces; c++)
        {
            // Face indexes:
            unsigned int face[3];
            memcpy(face, data + position, sizeof(unsigned int) * 3);
			meshFaces.push_back(Mesh::Face(face[0], face[1], face[2]));
            //cout << "   Face data . . :  f" << c << " (" << face[0] << ", " << face[1] << ", " << face[2] << ")" << endl;
            position += sizeof(unsigned int) * 3;


        }
        //meshVertices[meshVertices[meshFaces[0][0]], meshVertices[meshFaces[0][1]], meshVertices[meshFaces[0][2]]

    }
	mesh->setFaces(meshFaces);
    mesh->setVertices(meshVertices);
    nodesList.push_back((Object*)mesh);
}

void OvoParser::parseLightChunk(FILE* file, char* data, unsigned int& position) {
    //cout << "light]" << endl;

    // Light name:
    char lightName[FILENAME_MAX];
    strcpy(lightName, data + position);
    //cout << "   Name  . . . . :  " << lightName << endl;
    position += (unsigned int)strlen(lightName) + 1;

    // Light matrix:
    glm::mat4 matrix;
    memcpy(&matrix, data + position, sizeof(glm::mat4));
    //MAT2STR(matrix);
    position += sizeof(glm::mat4);

    // Nr. of children nodes:
    unsigned int children;
    memcpy(&children, data + position, sizeof(unsigned int));
    //cout << "   Nr. children  :  " << children << endl;
    position += sizeof(unsigned int);

    // Optional target node name, or [none] if not used:
    char targetName[FILENAME_MAX];
    strcpy(targetName, data + position);
    //cout << "   Target node . :  " << targetName << endl;
    position += (unsigned int)strlen(targetName) + 1;

    // Light subtype (see OvLight SUBTYPE enum):
    unsigned char subtype;
    memcpy(&subtype, data + position, sizeof(unsigned char));
    char subtypeName[FILENAME_MAX];

    glm::vec3 color;
    glm::vec3 direction;
    glm::vec4 direction4 = glm::vec4(direction, 1.0f);
    float cutoff=45.0f, spotExponent=20.0f;
    unsigned char castShadows, isVolumetric;
    DirectionLight* directionLight;
    PointLight* pointLight;
    SpotLight* spotLight;
    switch ((OvLight::Subtype)subtype)
    {

    case OvLight::Subtype::DIRECTIONAL:

        strcpy(subtypeName, "directional");
        //cout << "   Subtype . . . :  " << (int)subtype << " (" << subtypeName << ")" << endl;
        position += sizeof(unsigned char);
        directionLight = new DirectionLight(direction,lightName, matrix, true);

        // Light color:
        memcpy(&color, data + position, sizeof(glm::vec3));
        //cout << "   Color . . . . :  " << color.r << ", " << color.g << ", " << color.b << endl;
        position += sizeof(glm::vec3);
        directionLight->setLightAmbient(glm::vec4(color.x, color.y, color.z, 1.0f));
        directionLight->setLightDiffuse(glm::vec4(color.x, color.y, color.z, 1.0f));
        directionLight->setLightSpecular(glm::vec4(color.x, color.y, color.z, 1.0f));
        // Influence radius:
        float radius;
        memcpy(&radius, data + position, sizeof(float));
        //cout << "   Radius  . . . :  " << radius << endl;
        position += sizeof(float);

        // Direction:
        memcpy(&direction, data + position, sizeof(glm::vec3));
        //cout << "   Direction . . :  " << direction.r << ", " << direction.g << ", " << direction.b << endl;
        directionLight->setDirection(direction4);
        position += sizeof(glm::vec3);

        // Cutoff:
        memcpy(&cutoff, data + position, sizeof(float));
        //cout << "   Cutoff  . . . :  " << cutoff << endl;
        position += sizeof(float);

        // Exponent:
        memcpy(&spotExponent, data + position, sizeof(float));
        //cout << "   Spot exponent :  " << spotExponent << endl;
        position += sizeof(float);

        // Cast shadow flag:
        memcpy(&castShadows, data + position, sizeof(unsigned char));
        //cout << "   Cast shadows  :  " << (int)castShadows << endl;
        position += sizeof(unsigned char);

        // Volumetric lighting flag:

        memcpy(&isVolumetric, data + position, sizeof(unsigned char));
        //cout << "   Volumetric  . :  " << (int)isVolumetric << endl;
        position += sizeof(unsigned char);

        nodesList.push_back((Object*)directionLight);
        break;
    case OvLight::Subtype::OMNI:
        strcpy(subtypeName, "omni");
        //cout << "   Subtype . . . :  " << (int)subtype << " (" << subtypeName << ")" << endl;
        position += sizeof(unsigned char);
        pointLight = new PointLight(lightName, matrix, true);
        // Light color:
        memcpy(&color, data + position, sizeof(glm::vec3));
        //cout << "   Color . . . . :  " << color.r << ", " << color.g << ", " << color.b << endl;
        position += sizeof(glm::vec3);
        pointLight->setLightAmbient(glm::vec4(color.x, color.y, color.z, 1.0f));
        pointLight->setLightDiffuse(glm::vec4(color.x, color.y, color.z, 1.0f));
        pointLight->setLightSpecular(glm::vec4(color.x, color.y, color.z, 1.0f));
        // Influence radius:
        memcpy(&radius, data + position, sizeof(float));
        //cout << "   Radius  . . . :  " << radius << endl;
        position += sizeof(float);

        // Direction:
        memcpy(&direction, data + position, sizeof(glm::vec3));
        //cout << "   Direction . . :  " << direction.r << ", " << direction.g << ", " << direction.b << endl;
        position += sizeof(glm::vec3);
		
        // Cutoff:
        memcpy(&cutoff, data + position, sizeof(float));
        //cout << "   Cutoff  . . . :  " << cutoff << endl;
       // pointLight->setCutoff(cutoff);
        position += sizeof(float);

        // Exponent:
        memcpy(&spotExponent, data + position, sizeof(float));
        //cout << "   Spot exponent :  " << spotExponent << endl;
        position += sizeof(float);

        // Cast shadow flag:
        memcpy(&castShadows, data + position, sizeof(unsigned char));
        //cout << "   Cast shadows  :  " << (int)castShadows << endl;
        position += sizeof(unsigned char);

        // Volumetric lighting flag:
        memcpy(&isVolumetric, data + position, sizeof(unsigned char));
        //cout << "   Volumetric  . :  " << (int)isVolumetric << endl;
        position += sizeof(unsigned char);

        nodesList.push_back((Object*)pointLight);

        break;
    case OvLight::Subtype::SPOT:
        strcpy(subtypeName, "spot");
        //cout << "   Subtype . . . :  " << (int)subtype << " (" << subtypeName << ")" << endl;
        position += sizeof(unsigned char);
        // Light color:
        memcpy(&color, data + position, sizeof(glm::vec3));
        //cout << "   Color . . . . :  " << color.r << ", " << color.g << ", " << color.b << endl;
        position += sizeof(glm::vec3);

        // Influence radius:
        memcpy(&radius, data + position, sizeof(float));
        // cout << "   Radius  . . . :  " << radius << endl;
        position += sizeof(float);

        // Direction:
        memcpy(&direction, data + position, sizeof(glm::vec3));
        //cout << "   Direction . . :  " << direction.r << ", " << direction.g << ", " << direction.b << endl;

        position += sizeof(glm::vec3);

        // Cutoff:
        memcpy(&cutoff, data + position, sizeof(float));
        //cout << "   Cutoff  . . . :  " << cutoff << endl;
        
        position += sizeof(float);

        // Exponent:
        memcpy(&spotExponent, data + position, sizeof(float));
        //cout << "   Spot exponent :  " << spotExponent << endl;
        position += sizeof(float);

        // Cast shadow flag:
        memcpy(&castShadows, data + position, sizeof(unsigned char));
        //cout << "   Cast shadows  :  " << (int)castShadows << endl;
        position += sizeof(unsigned char);

        // Volumetric lighting flag:
        memcpy(&isVolumetric, data + position, sizeof(unsigned char));
        //cout << "   Volumetric  . :  " << (int)isVolumetric << endl;
        position += sizeof(unsigned char);
        spotLight = new SpotLight(direction, cutoff, spotExponent, lightName, matrix, true);
		spotLight->setLightAmbient(glm::vec4(color.x, color.y, color.z, 1.0f));
		spotLight->setLightDiffuse(glm::vec4(color.x, color.y, color.z, 1.0f));
		spotLight->setLightSpecular(glm::vec4(color.x, color.y, color.z, 1.0f));
        
        

        nodesList.push_back((Object*)spotLight);
        break;
    default: strcpy(subtypeName, "UNDEFINED");
    }


}

List* OvoParser::getList() {
    return list;
}


void OvoParser::addMaterialToMesh() {
    vector<Mesh*> meshes;
    vector<Material*> materials;

    for (int i = 0; i < nodesList.size(); i++) {
        Object* obj = nodesList.at(i);
		if (dynamic_cast<Material*>(obj)!=nullptr) {
            materials.push_back((Material*)obj);
        }
    }

    for (int i = 0; i < nodesList.size(); i++)
    {
        Object* obj = nodesList.at(i);
		if (dynamic_cast<Mesh*>(obj)!=nullptr) {
            for (int j = 0; j < materials.size(); j++)
            {
				if (((Mesh*)obj)->getMaterialName() == ((Node*)materials[j])->getName())
				{
					((Mesh*)obj)->setMaterial(materials[j]);
				}
            }
        }
    }


}

// Recursive loading function:
Node* OvoParser::recursiveLoad( unsigned int& position)
{
    // Extract node information:
    Object* obj = nodesList.at(position);
    List::getInstance()->push(obj);
    unsigned int nrOfChildren = ((Node*)obj)->getChildrenCount();
    Node* thisNode = ((Node*)obj);
    // Update position for next chunk:
    position += 1;
    int i = 0;
    // Go recursive when child nodes are avaialble:
    if (nrOfChildren)
        while (i < nrOfChildren)
        {
            Node* childNode = recursiveLoad(position);
            thisNode->addChildrenNode(childNode);
            i++;
        }
    // Done:
    return thisNode;
}

Node* OvoParser::buildSceneGraph() {

    unsigned int rootIndex = 0;
    int rootChildrens = 0;
    for (int i = 0; i < nodesList.size(); i++)
    {
        Object* obj = nodesList.at(i);
        if (dynamic_cast<Material*>(obj)==nullptr)
        {
            rootIndex = i;
            break;
        }
    }

    Node* root = recursiveLoad(rootIndex);
    return root;
}
