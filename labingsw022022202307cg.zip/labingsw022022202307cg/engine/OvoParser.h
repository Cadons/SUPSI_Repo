#include <iostream>
#include <vector>
#include "Node.h"
#include "SpotLight.h"
#include "PointLight.h"
#include "DirectionLight.h"
#ifndef OVOPARSER_H
#define OVOPARSER_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "List.h"
#include "Mesh.h"
using namespace std;

class LIB_API OvoParser {
private:
	List* list = List::getInstance();
public:
	Node* uploadFile(FILE* file);
	void parseObjectChunk(FILE* file, char* data, unsigned int& position);
	void parseNodeChunk(FILE* file, char* data, unsigned int& position);
	void parseMaterialChunk(FILE* file, char* dataa, unsigned int& position);
	void parseMeshChunk(FILE* file, char* data, unsigned int& position);
	void parseLightChunk(FILE* file, char* data, unsigned int& position);
	void addMaterialToMesh();
	Node* buildSceneGraph();
	Node* recursiveLoad(unsigned int& position);
	List* getList();
};
#endif // OVOPARSER_H