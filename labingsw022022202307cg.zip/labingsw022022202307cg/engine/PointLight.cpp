#include "PointLight.h"

// FreeGLUT:
#include <GL/freeglut.h>

// C/C++:
#include <iostream>
#include <stdio.h>
#include <glm/gtc/type_ptr.hpp>
#include "Camera.h"
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "GraphicEngine.h"
using namespace std;


void PointLight::render() {

	

	if (setUpLight()) {
		
	

		
		
		glLightfv(light, GL_POSITION, glm::value_ptr(glm::vec4(0.0f, 0.0f, 0.0f, 1.0f)));
	

		glLightf(light, GL_SPOT_CUTOFF, cutoff);

		
		//attenuation 
		

		glEnable(light);
		
	}
	else
	{
		glDisable(light);
	}

	

	

}






float PointLight::getCutoff() {
	return this->cutoff;
}




