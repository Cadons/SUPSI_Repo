#ifndef POINTLIGHT_H
#define POINTLIGHT_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Light.h"
class LIB_API PointLight : public Light {

public:

	PointLight(std::string name = "PointLight", glm::mat4 transformMatrix = glm::mat4(1), bool enable = true, glm::vec4 lightAmbient = glm::vec4(0.5f, 0.5f, 0.5f, 1.0f), glm::vec4 lightDiffuse = glm::vec4(0.5f, 0.5f, 0.5f, 1.0f), glm::vec4 lightSpecular = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f)) :  Light(name, transformMatrix, enable,lightAmbient,lightDiffuse,lightSpecular) {

	}
	
	void render();

	float getCutoff();

private:
	float cutoff=180.0f;

};

#endif
