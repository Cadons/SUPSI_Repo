#include "ProspectiveCamera.h"
#include "GraphicEngine.h"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/glm.hpp"


void ProspectiveCamera::setFov(float fov) {
	this->fov = fov;
}

float ProspectiveCamera::getFov() {
	return this->fov;
}

glm::mat4 ProspectiveCamera::getViewMatrix() {
	float ratio = GraphicEngine::getInstance()->getWidth() / (float)GraphicEngine::getInstance()->getHeight();
	return glm::perspective(glm::radians(this->fov),ratio, this->getNearPlane(), this->getFarPlane()) ;
}



