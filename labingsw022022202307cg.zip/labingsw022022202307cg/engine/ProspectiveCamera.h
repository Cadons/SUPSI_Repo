#ifndef PROSPECTIVECAMERA_H
#define PROSPECTIVECAMERA_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Camera.h"
class LIB_API ProspectiveCamera :public Camera {

public:
	float fov;

	void setFov(float fov);

	float getFov();

	glm::mat4 getViewMatrix() override;
	//constructor
	ProspectiveCamera(std::string name, glm::mat4 position, float nearPlane, float farPlane, float fov) :Camera(name, position, nearPlane, farPlane) {
		this->fov = fov;
	}
};

#endif
