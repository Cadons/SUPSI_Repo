#include "SpotLight.h"

// FreeGLUT:
#include <GL/freeglut.h>

// C/C++:
#include <iostream>
#include <stdio.h>
#include <glm/gtc/type_ptr.hpp>



float SpotLight::getCutoff() {
	return this->cutoff;

}


void SpotLight::setDirection(float dx, float dy, float dz) {
	
	direction = glm::vec3(dx, dy, dz);
}



void SpotLight::setCutoff(float cutoff) {

	//float cutoff = 15.0f; // Any angle between 0� and 90�
	if (cutoff > 90.0f) {
		cutoff = 90.0f;
	}
	else if (cutoff < 0.0f) {
		cutoff = 0.0f;
	}
	else {
			this->cutoff = cutoff;
	}

}
void SpotLight::setExponent(float exponent) {
	this->exponent = exponent;
}
float SpotLight::getExponent() {
	return this->exponent;
}
void SpotLight::render() {



	if (setUpLight()) {
		
		glLightfv(light, GL_POSITION, glm::value_ptr(glm::vec4(0.0f, 0.0f, 0.0f, 1.0f)));
		glLightf(light, GL_SPOT_CUTOFF, cutoff);
		glLightfv(light, GL_SPOT_DIRECTION, glm::value_ptr(direction));
		glLightf(light, GL_SPOT_EXPONENT, exponent);
		//constant attenuation


		glEnable(light);
	}
	else {
		
		glDisable(light);
	}
	

	


	
	
	
	


}






