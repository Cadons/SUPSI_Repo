#ifndef SPOTLIGHT_H
#define SPOTLIGHT_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Light.h"
class LIB_API SpotLight : public Light {



public:
	SpotLight(glm::vec3 direction,float cutoff,float exponent=20.0f,std::string name = "SpotLight", glm::mat4 transformMatrix = glm::mat4(1), bool enable = true, glm::vec4 lightAmbient = glm::vec4(0.5f, 0.5f, 0.5f, 1.0f), glm::vec4 lightDiffuse = glm::vec4(0.5f, 0.5f, 0.5f, 1.0f), glm::vec4 lightSpecular = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f)) : Light(name, transformMatrix, enable, lightAmbient, lightDiffuse, lightSpecular) {
		this->direction = direction;
		this->cutoff = cutoff;
		this->exponent = exponent;
	}
	

	float getCutoff();
	void setExponent(float exponent);
	float getExponent();
	void setDirection(float x, float y, float z);

	void setCutoff(float cutoff);
	
	void render() ;
	private:
		float cutoff;
		glm::vec3 direction;
		float exponent = 20.0f;
};

#endif
