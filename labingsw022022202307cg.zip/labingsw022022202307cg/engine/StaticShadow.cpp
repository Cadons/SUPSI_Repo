#include "StaticShadow.h"
#include "glm/glm.hpp"
#include "GL/freeglut.h"
#include <glm/gtc/type_ptr.hpp>
#include "glm/gtc/matrix_transform.hpp"
#include "Camera.h"
float StaticShadow::getDistance() {

	return glm::distance(object->getMatrix()[3][1], plane->getMatrix()[3][1]) - 1;

}
void StaticShadow::render() {
	auto tmpMaterial = object->getMaterial();
	object->setMaterial(material);
	auto matrix = glm::translate(glm::mat4(1.0f), glm::vec3(0, -getDistance() + offset, 0)) * glm::scale(object->getMatrix(), scale);
	auto mat = glm::inverse(Camera::getMainCamera()->getMatrix()) * matrix;
	glLoadMatrixf(glm::value_ptr(mat));
	object->render();
	object->setMaterial(tmpMaterial);

}