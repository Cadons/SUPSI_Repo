#ifndef STATICSHADOW_H
#define STATICSHADOW_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Object.h"
#include "Node.h"
#include "Mesh.h"
class LIB_API StaticShadow :
	public Object
{
public:
	StaticShadow(Mesh* object, glm::vec3 scale, Node* plane, Material* material, float offset = 0.f) :Object("StaticShadow") {
		this->plane = plane;
		this->object = object;
		this->scale = scale;
		this->material = material;
		this->offset = offset;
	};
	float getDistance();
	virtual ~StaticShadow() {
		delete material;
	};
	void render();
	ObjectType getType() { return ObjectType::STATIC_SHADOW; };
private:
	Node* plane;
	Mesh* object;
	glm::vec3 scale;
	Material* material;
	float offset;

};
#endif