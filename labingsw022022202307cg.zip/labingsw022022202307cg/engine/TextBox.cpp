#include "TextBox.h"
#include "GraphicEngine.h"
#include "GL/freeglut.h"
#include "glm/glm.hpp"
#include <glm/gtc/type_ptr.hpp>
//implments methods
void TextBox::render() {

	// Write some text:
	glColor3f(color.x, color.y, color.z);
	glRasterPos2f(x, y);
	//cast text to unsigned char*
	unsigned char* textToDisplay = (unsigned char*)text.c_str();
	glutBitmapString(GLUT_BITMAP_8_BY_13, textToDisplay);
	//reset color
	glColor3f(1.0f, 1.0f, 1.0f);

}

void TextBox::setText(std::string text) {
	this->text = text;
}
std::string TextBox::getText() {
	return this->text;
}
void TextBox::setColor(float r, float g, float b) {
	this->color = glm::vec3(r, g, b);
}
glm::vec3 TextBox::getColor() {
	return this->color;
}
void TextBox::setX(int x) {
	this->x = x;
}
int TextBox::getX() {
	return this->x;
}
void TextBox::setY(int y) {
	this->y = y;
}
int TextBox::getY() {
	return this->y;
}