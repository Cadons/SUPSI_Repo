#ifndef TEXTBOX_H
#define TEXTBOX_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "GUIElement.h"
#include "glm/glm.hpp"


class LIB_API TextBox:public GUIElement
{
private:
	std::string text;
	
	
public :

	TextBox(std::string name, int x, int y, std::string text="New Text", float r=1,float g=1,float b=1):GUIElement(name = "TextBox") {
		this->text = text;
		this->x = x;
		this->y = y;
		this->color = glm::vec3(r, g, b);
	}
	
	void render();

	void setText(std::string text);
	std::string getText();
	void setX(int x);
	int getX();
	void setY(int y);
	int getY();
	void setColor(float r, float g, float b);
	glm::vec3 getColor();
};

#endif