#include "Texture.h"
#include "GL/freeglut.h"
#include "FreeImage.h"
#include "glm/glm.hpp"

Texture::Texture(std::string filename, std::string name) : Object(name) {
		textureId = this->__id;
		//init opengl texture

		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);
		// set the texture wrapping/filtering options (on the currently bound texture object)
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		//convert string as char*
		filename = "resources/" + filename;
		auto filenameChar = filename.c_str();
		
		//check if file exists
			
			FIBITMAP* bitmap = FreeImage_Load(FreeImage_GetFileType(filenameChar, 0), filenameChar);

			bitmap = FreeImage_ConvertTo32Bits(bitmap);//Converts a bitmap to 32 bits. A clone of the input bitmap is returned for 32-bit bitmaps.

			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, FreeImage_GetWidth(bitmap), FreeImage_GetHeight(bitmap), 0, GL_BGRA_EXT, GL_UNSIGNED_BYTE, (void*)FreeImage_GetBits(bitmap));
			FreeImage_Unload(bitmap);		
	
}
//destructor
Texture::~Texture() {
	glDeleteTextures(1, &textureId);

}
void Texture::render() {
	glBindTexture(GL_TEXTURE_2D, textureId);
	glEnable(GL_TEXTURE_2D);
	
}
ObjectType Texture::getType() {
	return this->type;
}
unsigned int Texture::getTextureId() {
	return textureId;
}