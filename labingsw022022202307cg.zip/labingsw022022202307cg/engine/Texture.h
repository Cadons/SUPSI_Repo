#ifndef TEXTURE_H
#define TEXTURE_H
// Generic info:
#define LIB_NAME      "Graphic Engine Library v0.1a"  ///< Library credits
#define LIB_VERSION   10                              ///< Library version (divide by 10)
#ifdef _WINDOWS         
   // Export API:
   // Specifies i/o linkage (VC++ spec):
#ifdef GRAPHICENGINELIB_EXPORTS
#define LIB_API __declspec(dllexport)
#else
#define LIB_API __declspec(dllimport)
#endif              
#else // Under Linux
#define LIB_API  // Dummy declaration
#endif
#include "Object.h"

class LIB_API Texture : public Object {
private:
	ObjectType type = ObjectType::TEXTURE;
	unsigned int textureId;

public:
	//File& file;

	void render() override;
	ObjectType getType() override;
	//constructor
	Texture(std::string filename,std::string name = "Texture");
	//destructor
	virtual ~Texture();
	unsigned int getTextureId();
};

#endif
