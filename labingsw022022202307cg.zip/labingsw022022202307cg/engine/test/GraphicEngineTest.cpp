//generate graphic engine test
#include "../GraphicEngine.h"

void initTest() {
	GraphicEngine::getInstance()->init(0,nullptr, 800, 600, "test");
	assert(GraphicEngine::getInstance()->isClosed() == false);
	assert(GraphicEngine::getInstance()->getWidth() == 800);
	assert(GraphicEngine::getInstance()->getHeight() == 600);
}

int main() {
	initTest();
	return 0;
}