MAKE commands

make compile:  build all software
make run: run the software
make clean: clean build
