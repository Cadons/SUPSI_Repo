package ch.supsi.ed2d.backend.controller;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.GenericImage;
import ch.supsi.ed2d.backend.service.IImageController;
import ch.supsi.ed2d.backend.service.ImageService;

import java.io.File;


public class ImageController {

    //reference to service layer
    private final IImageController serviceLayer = ImageService.getInstance();
    private static ImageController instance;

    public ImageController() {

    }

    public static ImageController getInstance(){
        if(instance==null)
            instance=new ImageController();
        return instance;
    }

    //method used to load the generic image file
    public boolean loadImageFile(String filename){
        try {
            File file = new File(filename);
            serviceLayer.loadImageFile(file);
            return true;
        } catch (Exception e) {
            return  false;
        }
    }

    //method to get the bitMap of the uploaded image
    public float[][] getImageMatrix(){
        try {
            return serviceLayer.getImageMatrix();
        } catch (Exception e) {
        return null;
        }
    }

    public boolean updateImage(float[][] image) {
       return serviceLayer.update(image);
    }

    public float[][] getStartImage(){
        return CellRGB.convertToFloatMatrix(serviceLayer.getStartImage());
    }

    public int getImageColumns(){
        return serviceLayer.getImageColumns();
    }

    public int getImageRows(){return serviceLayer.getImageRows(); }

    public boolean isImageLoaded(){
        return serviceLayer.isImageLoaded();
    }

    public boolean saveImageFile(String absolutePath){
        return serviceLayer.saveImageFile(absolutePath);
    }
}
