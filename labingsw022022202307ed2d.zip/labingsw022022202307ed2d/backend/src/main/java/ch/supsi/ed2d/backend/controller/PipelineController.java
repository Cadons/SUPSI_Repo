package ch.supsi.ed2d.backend.controller;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.service.IPipeliner;
import ch.supsi.ed2d.backend.service.Pipeliner;

import java.util.*;

public class PipelineController {
    private static final IPipeliner pipeline = Pipeliner.getInstance();

    //Not sure

    /**
     * @apiNote these methods call the pipeline and return the matrix of the image, updated with the updated image
     */
    public float[][] apply(float[][] image) {
        CellRGB[][] rgbMatrix = CellRGB.createMatrix(image);
        var pipeline = PipelineController.pipeline.apply(rgbMatrix);
        if (pipeline.isCompleted()) {

            return pipeline.getValueAsFloat();
        } else
            return null;
    }

    /**
     * @param filter name of the filter
     * @apiNote this method adds a filter to the pipeline, through the given name; the name of the filter is returned by backend to the frontend
     */
    public String add(int filter) {
        var output = pipeline.add(filter);
        if (output != null)
            return output.toString();
        else
            return null;
    }

    /**
     * @param id id of the filter returned by add method
     * @apiNote this method removes the selected filter from the pipeline
     */
    public boolean remove(String id) {

        return pipeline.remove(UUID.fromString(id));
    }

    /***
     * @apiNote this method return available filters of the software, it returns the name and the related index, it needs to add filter in the pipeline
     *
     */
    public List<Map.Entry<String, Integer>> getFilters() {
        return pipeline.getFilters();
    }

    public int pipelineSize() {
        return pipeline.size();
    }

    public boolean cleanPipeline() {
        return pipeline.removeAll();
    }
    public ArrayList<Map.Entry<String,String>> undo(){
        return pipeline.undo();
    }
    public ArrayList<Map.Entry<String,String>> redo(){
        return pipeline.redo();
    }
    public boolean canIDoUndo() {
        return pipeline.isUndoEmpty();
    }
    public boolean canIDoRedo() {
        return pipeline.isRedoEmpty();
    }
}
