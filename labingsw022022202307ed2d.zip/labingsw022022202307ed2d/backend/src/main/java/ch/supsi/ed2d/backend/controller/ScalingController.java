package ch.supsi.ed2d.backend.controller;

import ch.supsi.ed2d.backend.model.filters.Rescaling;

public class ScalingController {

    public  void setValue(float value){

        value=value/100;
        Rescaling.value=value;

    }

    public static float getValue(){

        return  Rescaling.value;
    }

}
