package ch.supsi.ed2d.backend.exception;

public class FileNotInitializedException extends Exception{
    public FileNotInitializedException() {
        super("File not initialized");
    }

}
