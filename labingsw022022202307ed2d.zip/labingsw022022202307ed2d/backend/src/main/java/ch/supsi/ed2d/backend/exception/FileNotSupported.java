package ch.supsi.ed2d.backend.exception;

public class FileNotSupported extends Exception{
    public FileNotSupported() {
        super("File not supported");
    }

}
