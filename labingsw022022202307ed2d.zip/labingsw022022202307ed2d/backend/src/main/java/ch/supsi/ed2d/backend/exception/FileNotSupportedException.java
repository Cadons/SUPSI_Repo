package ch.supsi.ed2d.backend.exception;

public class FileNotSupportedException extends Exception{
    public FileNotSupportedException() {
        super("File not supported");
    }

}
