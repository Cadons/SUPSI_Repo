package ch.supsi.ed2d.backend.model;

import java.util.Objects;

public class CellRGB {

    private float r;
    private float g;
    private float b;

    public CellRGB(float r, float g, float b) {

        this.r = r;
        this.g = g;
        this.b = b;
    }

    public CellRGB() {

    }

    public void setR(float r) {
        this.r = r;
    }

    public void setG(float g) {
        this.g = g;
    }

    public void setB(float b) {
        this.b = b;
    }

    public float getR() {
        return r;
    }

    public float getG() {
        return g;
    }

    public float getB() {
        return b;
    }

    public static float[][] convertToFloatMatrix(CellRGB[][] value) {
        float[][] output = new float[value.length * 3][value[0].length * 3];

        for (int i = 0; i < value.length; i++)
            for (int k = 0,j=0; j < value[0].length; j++) {
                if ((k+2)<output[0].length) {
                    output[i][k] = value[i][j].getR();
                    output[i][k + 1] = value[i][j].getG();
                    output[i][k + 2] = value[i][j].getB();
                    k+=3;
                } else {
                    break;
                }

            }
        return output;
    }

    public void normalize(float range) {

        r = r / range;
        g = g / range;
        b = b / range;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CellRGB cellRGB = (CellRGB) o;
        return Float.compare(cellRGB.r, r) == 0 && Float.compare(cellRGB.g, g) == 0 && Float.compare(cellRGB.b, b) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(r, g, b);
    }

    public static CellRGB[][] createMatrix(float[][] value) {
        CellRGB[][] output = new CellRGB[value.length / 3][value[0].length / 3];

        for (int i = 0; i < value.length / 3; i++)
            for (int k = 0, j = 0; j < value[0].length / 3; j++) {
                if (k + 2 < value[0].length) {
                    output[i][j] = new CellRGB(value[i][k], value[i][k + 1], value[i][k + 2]);
                    k += 3;
                } else
                    break;
            }
        return output;
    }
}
