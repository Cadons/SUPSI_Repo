package ch.supsi.ed2d.backend.model;

public interface IUpdateBitmap {
    boolean update(CellRGB[][] bitMap);
}
