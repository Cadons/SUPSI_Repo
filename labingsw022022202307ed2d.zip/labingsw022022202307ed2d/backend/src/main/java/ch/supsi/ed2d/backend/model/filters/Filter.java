package ch.supsi.ed2d.backend.model.filters;

import ch.supsi.ed2d.backend.model.pipeline.PipelineItem;

import java.util.Objects;
import java.util.UUID;

public abstract class Filter implements PipelineItem {
    private final String name;
    public final UUID id;

    public Filter(String name) {
        this.name = name;
        id=UUID.randomUUID();
    }
    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Filter filter = (Filter) o;

        return Objects.equals(name, filter.name);
    }

    @Override
    public int hashCode() {
        return name != null ? name.hashCode() : 0;
    }
}
