package ch.supsi.ed2d.backend.model.filters;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.pipeline.PipelineItem;
import ch.supsi.ed2d.backend.model.pipeline.PipelineResult;

public class GrayScale extends Filter {

    private final float R=0.21f;
    private final float G=0.72f;
    private final float B=0.07f;
    public GrayScale() {
        super("Gray Scale");
    }

    @Override
    public PipelineResult apply(CellRGB[][] input) {
        CellRGB [][] output=new CellRGB[input.length][input[0].length];

        for (int y=0;y<input.length;y++)
        {
            for (int x=0;x<input[0].length;x++){

                float gray=input[y][x].getR()*R+input[y][x].getG()*G+input[y][x].getB()*B;
                output[y][x]=new CellRGB(gray,gray,gray);

            }
        }
        return new PipelineResult(true,output);
    }

    @Override
    public PipelineItem create() {
        return new GrayScale();
    }


}
