package ch.supsi.ed2d.backend.model.filters;

import ch.supsi.ed2d.backend.controller.ScalingController;
import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.GenericImage;
import ch.supsi.ed2d.backend.model.pipeline.PipelineItem;
import ch.supsi.ed2d.backend.model.pipeline.PipelineResult;


/**
 *
 *
 * @author Marsildo Byketa
 */

public class Rescaling extends Filter{

    //public ScalingController scalingController=new ScalingController();

    public Rescaling(){
        super("Rescaling");
    }

    public static float value=1;

    @Override
    public PipelineResult apply(CellRGB[][] input) {


        int newHt= (int) ((float)input.length*ScalingController.getValue());
        int newWid= (int) ((float)input[0].length*ScalingController.getValue());


        CellRGB [][] out = new CellRGB[newHt][newWid];
        int height = input.length;
        int width = input[0].length;

        GenericImage.getInstance().setColumns(newWid);
        GenericImage.getInstance().setRows(newHt);

        for (int i=0;i<newHt;i++){

            for (int j=0;j<newWid;j++){

                int srcX = (int) Math.floor((float)i /(float) newWid * (float) width);
                int srcY = (int) Math.floor((float)j /(float) newHt * (float) height);

                srcX=Math.min(srcX,width-1);
                srcY=Math.min(srcY,height-1);


                out[i][j]=new CellRGB();
                out[i][j].setR(input[srcX][srcY].getR());
                out[i][j].setG(input[srcX][srcY].getG());
                out[i][j].setB(input[srcX][srcY].getB());


            }


        }


        return new PipelineResult(true,out);

    }

    @Override
    public PipelineItem create() {
        return new Rescaling();
    }

}
