package ch.supsi.ed2d.backend.model.filters;
import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.pipeline.PipelineItem;
import ch.supsi.ed2d.backend.model.pipeline.PipelineResult;
import com.sun.tools.javac.Main;

public class Sepia extends Filter{


    public Sepia() {
        super("Sepia");
    }

    @Override
    public PipelineResult apply(CellRGB[][] input) {
        CellRGB [][] output=new CellRGB[input.length][input[0].length];

        final float  red1 = .393f, red2 = .349f, red3 = .272f;
        final float  green1 = .769f, green2 = .686f, green3 = .534f;
        final float  blue1 = .189f, blue2 = .168f, blue3 = .131f;


        for(int y=0; y<input.length; y++){
            for(int x=0; x<input[0].length; x++){

                float tr = input[y][x].getR()*red1+input[y][x].getG()*green1+input[y][x].getB()*blue1;
                float tg = input[y][x].getR()*red2+input[y][x].getG()*green2+input[y][x].getB()*blue2;
                float tb = input[y][x].getR()*red3+input[y][x].getG()*green3+input[y][x].getB()*blue3;

                float red = tr > 1 ?  1 : tr;
                float green = tg > 1 ?  1 : tg;
                float blue = tb > 1 ? 1 : tb;

                output[y][x]=new CellRGB(red,green,blue);

            }
        }

        return new PipelineResult(true,output);
    }

    @Override
    public PipelineItem create() {
        return new Sepia();
    }



}
