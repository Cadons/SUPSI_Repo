package ch.supsi.ed2d.backend.model.filters;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.GenericImage;
import ch.supsi.ed2d.backend.model.pipeline.Pipeline;
import ch.supsi.ed2d.backend.model.pipeline.PipelineItem;
import ch.supsi.ed2d.backend.model.pipeline.PipelineResult;

public class Sharpness extends Filter {
    private float[][] kernel = new float[][]{
            {0, -1, 0},
            {-1, 5.5f, -1},
            {0, -1, 0}
    };

    public Sharpness() {
        super("Sharpness");
    }

    @Override
    public PipelineResult apply(CellRGB[][] image) {
        //implement easy sharpness filter with kernel
        CellRGB[][] output = new CellRGB[image.length][image[0].length];
        for (int y = 0; y < image.length; y++) {
            for (int x = 0; x < image[0].length; x++) {
                float red = 0;
                float green = 0;
                float blue = 0;
                for (int i = 0; i < kernel.length; i++) {
                    for (int j = 0; j < kernel[0].length; j++) {
                        int x1 = x + i - 1;
                        int y1 = y + j - 1;
                        if (x1 < 0 || x1 >= image[0].length || y1 < 0 || y1 >= image.length) {
                            continue;
                        }
                        red += image[y1][x1].getR() * kernel[i][j];
                        green += image[y1][x1].getG() * kernel[i][j];
                        blue += image[y1][x1].getB() * kernel[i][j];
                    }
                }
                red = red > 1 ? 1 : red;
                green = green > 1 ? 1 : green;
                blue = blue > 1 ? 1 : blue;
                red = red < 0 ? 0 : red;
                green = green < 0 ? 0 : green;
                blue = blue < 0 ? 0 : blue;
                output[y][x] = new CellRGB(red, green, blue);
            }
        }
        return new PipelineResult(true, output);
    }


    @Override
    public PipelineItem create() {
        return new Sharpness();
    }
}
