package ch.supsi.ed2d.backend.model.formats;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.IUpdateBitmap;

import java.io.BufferedReader;
import java.io.IOException;

public class GenericImage implements IUpdateBitmap {


    private CellRGB[][] bits;
    private CellRGB[][] startData;
    private int rows;
    private int columns;
    private float colorRange = 1;



    private PortableBitmapImage ftype;
    private static GenericImage instance;

    public GenericImage() {

    }

    public static GenericImage getInstance(){
        if(instance==null)
            instance=new GenericImage();
        return instance;
    }

    public static void reset(){
        instance=null;
    }

    public void setFtype(PortableBitmapImage ftype) {
        this.ftype = ftype;
    }
    public void setColorRange(float colorRange) {
        this.colorRange = colorRange;
    }

    public float getColorRange() {
        return colorRange;
    }

    public CellRGB[][] getBits() {
        return bits;
    }

    public void setBits(CellRGB[][] bits) {
       if (startData == null){
           //Start map
            startData=new CellRGB[bits.length][bits[0].length];
            for(int i=0;i< bits.length;i++)
            {
                for(int j=0;j< bits[0].length;j++) {
                    startData[i][j] =new CellRGB(bits[i][j].getR(),bits[i][j].getG(),bits[i][j].getB());
                }
            }
        }
        this.bits = bits;
    }

    public CellRGB[][] getStartData() {
        return startData;
    }

    public int getRows() {
        return rows;
    }

    public void setRows(int rows) {
        this.rows = rows;
    }

    public int getColumns() {
        return columns;
    }

    public void setColumns(int columns) {
        this.columns = columns;
    }

    public String[] getAllValuesOfMatrix(BufferedReader br, int val) throws IOException {

        int s = 0;
        String[] values = new String[val];
        String line;
        while ((line = br.readLine()) != null && s < val) {
            String[] strings = line.split("\\s+");
            for (int w = 0; w < strings.length && s< val; w++) {

                if (!strings[w].equals("")){
                    values[s] = strings[w];
                    s++;
                }
            }
        }
        return values;
    }

    @Override
    public boolean update(CellRGB[][] bitMap) {
        if (bitMap != null) {
            bits = bitMap;
            return true;
        } else {
            return false;
        }
    }

    public void setRowsColumns(String line) {

        int z = 0;
        int[] dimension = new int[2];
        String[] str = line.split("\\s+");
        for (int i = 0; i < str.length; i++) {
            if (!str[i].equals("")) {
                dimension[z] = Integer.parseInt(str[i]);
                z++;
            }
        }
        setRows(dimension[1]);
        setColumns(dimension[0]);
    }
    public PortableBitmapImage getFtype() {
        return ftype;
    }
}
