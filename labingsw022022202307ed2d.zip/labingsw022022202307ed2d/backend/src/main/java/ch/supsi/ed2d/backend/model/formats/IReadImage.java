package ch.supsi.ed2d.backend.model.formats;

import ch.supsi.ed2d.backend.model.formats.chain.ChainRequest;
import ch.supsi.ed2d.backend.model.formats.chain.ReadChainRequest;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;

public interface IReadImage {
    public GenericImage readData(ReadChainRequest request) throws IOException;
}

