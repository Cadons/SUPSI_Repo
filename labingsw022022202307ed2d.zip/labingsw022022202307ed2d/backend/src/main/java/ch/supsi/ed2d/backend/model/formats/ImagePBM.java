package ch.supsi.ed2d.backend.model.formats;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.chain.ChainElement;
import ch.supsi.ed2d.backend.model.formats.chain.ReadChainRequest;
import ch.supsi.ed2d.backend.model.formats.chain.WriteChainRequest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

public class ImagePBM implements ChainElement, IReadImage {


    private ChainElement nextElement;
    private GenericImage image;

    public ImagePBM() {
    }

    @Override
    public GenericImage executeRead(ReadChainRequest r) throws IOException {
        if (r.getType() == PortableBitmapImage.P1) {
            return readData(r);
        } else {
            if (nextElement != null)
                return nextElement.executeRead(r);
            else
                return null;
        }
    }

    @Override
    public boolean executeWrite(WriteChainRequest r, GenericImage image) throws IOException {
        if (r.getType() == PortableBitmapImage.pbm) {
            return saveData(r, image);
        } else {
            if (nextElement != null)
                return nextElement.executeWrite(r, image);
            else
                return false;
        }
    }

    @Override
    public GenericImage readData(ReadChainRequest request) throws IOException {

        GenericImage.reset();
        this.image = GenericImage.getInstance();
        BufferedReader br = request.getReader();
        String line = br.readLine();
        image.setFtype(request.getType());
        if ((line.charAt(0) == '#'))
            line = br.readLine();

        image.setRowsColumns(line);

        String[] allValues = image.getAllValuesOfMatrix(br, image.getColumns() * image.getRows());
        CellRGB[][] bits = initCellRGB(allValues);

        image.setBits(bits);

        return image;

    }

    public CellRGB[][] initCellRGB(String[] allValues) {

        CellRGB[][] cellRGBS = new CellRGB[image.getRows()][image.getColumns()];

        int s = 0;
        for (int i = 0; i < image.getRows(); i++) {
            for (int j = 0; j < image.getColumns(); j++) {

                if (allValues[s].equals("1"))
                    cellRGBS[i][j] = new CellRGB(0, 0, 0);
                else
                    cellRGBS[i][j] = new CellRGB(1, 1, 1);
                s++;

            }
        }
        return cellRGBS;
    }


    @Override
    public void setNextElement(ChainElement next) {
        this.nextElement = next;
    }


    public boolean saveData(WriteChainRequest r, GenericImage image) throws IOException {
        BufferedWriter writer = r.getBufferedWriter();
        StringBuilder stringBuilder = new StringBuilder();
        int rows = image.getRows();
        int columns = image.getColumns();
        CellRGB[][] bits = image.getBits();
        float colorRange = image.getColorRange();
        stringBuilder.append("P1").append("\n").append(columns).append(" ").append(rows).append("\n");
        for(int i =0; i<rows; i++)
        {
            for(int j =0; j<columns; j++)
            {
                if(bits[i][j].getR() * colorRange> colorRange/2)
                    bits[i][j].setR(1);
                else
                    bits[i][j].setR(0);

                if(bits[i][j].getG()* colorRange>colorRange/2)
                    bits[i][j].setG(1);
                else
                    bits[i][j].setG(0);

                if(bits[i][j].getB()* colorRange>colorRange/2)
                    bits[i][j].setB(1);
                else
                    bits[i][j].setB(0);

                stringBuilder.append((int) (bits[i][j].getR())).append(" ")
                        .append((int) (bits[i][j].getG())).append(" ")
                        .append((int) (bits[i][j].getB())).append(" ");

            }
            stringBuilder.append("\n");
        }
        writer.write(stringBuilder.toString());
        writer.close();
        return true;
    }

    public void setImage(GenericImage image) {
        this.image = image;
    }

    public GenericImage getImage() {
        return image;
    }

    public ChainElement getNextElement() {
        return nextElement;
    }
}