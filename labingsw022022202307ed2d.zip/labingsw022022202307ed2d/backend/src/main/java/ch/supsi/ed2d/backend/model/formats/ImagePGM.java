package ch.supsi.ed2d.backend.model.formats;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.chain.ChainElement;
import ch.supsi.ed2d.backend.model.formats.chain.ReadChainRequest;
import ch.supsi.ed2d.backend.model.formats.chain.WriteChainRequest;

import java.io.*;

public class ImagePGM  implements ChainElement, IReadImage {

    private ChainElement nextElement;
    private GenericImage image;
    private float colorRange;

    public ImagePGM() {
    }

    float setColorRange(String line) {

        String[] str1 = line.split("\\s+");
        for (int i = 0; i < str1.length; i++) {

            if (!str1[i].equals(""))
                this.colorRange = Float.parseFloat(str1[i]);
        }
        return colorRange;
    }


    @Override
    public GenericImage readData(ReadChainRequest request) throws IOException {

        GenericImage.reset();
        this.image = GenericImage.getInstance();
        BufferedReader br =  request.getReader();
        String line = br.readLine();
        image.setFtype(request.getType());
        while ((line.charAt(0) == '#') || (line.equals("P2")))
            line = br.readLine();

        image.setRowsColumns(line);
        line = br.readLine();
        image.setColorRange(setColorRange(line));

        String[] allValues = image.getAllValuesOfMatrix(br, image.getColumns() * image.getRows());
        CellRGB[][] bits = initCellRGB(allValues);

        image.setBits(bits);

        return image;
    }


    CellRGB[][] initCellRGB(String[] allValues) {

        CellRGB[][] cellRGBS = new CellRGB[image.getRows()][image.getColumns()];

        int s = 0;
        for (int i = 0; i < image.getRows(); i++) {
            for (int j = 0; j < image.getColumns(); j++) {

                cellRGBS[i][j] = new CellRGB(Float.parseFloat(allValues[s]), Float.parseFloat(allValues[s]), Float.parseFloat(allValues[s]));
                cellRGBS[i][j].normalize(image.getColorRange());
                s++;

            }
        }

        return cellRGBS;
    }

    @Override
    public void setNextElement(ChainElement next) {
        this.nextElement = next;
    }

    @Override
    public GenericImage executeRead(ReadChainRequest r) throws IOException {

        if (r.getType()== PortableBitmapImage.P2)
        {
            return readData(r);
        }else{
            if (nextElement != null)
                return nextElement.executeRead(r);
            else
                return null;
        }
    }

    @Override
    public boolean executeWrite(WriteChainRequest r, GenericImage image) throws IOException {
        if (r.getType() == PortableBitmapImage.pgm) {
            return saveData(r,image);
        } else {
            if (nextElement != null)
                return nextElement.executeWrite(r, image);
            else
                return false;
        }
    }

    boolean saveData(WriteChainRequest r, GenericImage image) throws IOException {
        BufferedWriter writer = r.getBufferedWriter();
        StringBuilder stringBuilder = new StringBuilder();
        int rows = image.getRows();
        int columns = image.getColumns();
        float colorRange = image.getColorRange();
        CellRGB[][] bits = image.getBits();
        stringBuilder.append("P2").append("\n").append(columns).append(" ").append(rows).append("\n")
                .append((int) colorRange).append("\n");
        for(int i =0; i<rows; i++)
        {
            for(int j =0; j<columns; j++)
            {
                bits[i][j].setR(bits[i][j].getR());
                bits[i][j].setG(bits[i][j].getR());
                bits[i][j].setB(bits[i][j].getR());
                stringBuilder.append((int) (bits[i][j].getR())).append(" ")
                        .append((int) (bits[i][j].getG())).append(" ")
                        .append((int) (bits[i][j].getB())).append(" ");

            }
            stringBuilder.append("\n");
        }
        writer.write(stringBuilder.toString());
        writer.close();
        return true;
    }

    public float getColorRange() {
        return colorRange;
    }
    public void setImage(GenericImage image) {
        this.image = image;
    }

    public GenericImage getImage() {
        return image;
    }

    public ChainElement getNextElement() {
        return nextElement;
    }
}