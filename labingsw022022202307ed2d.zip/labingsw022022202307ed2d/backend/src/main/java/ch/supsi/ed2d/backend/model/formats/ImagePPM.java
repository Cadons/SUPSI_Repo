package ch.supsi.ed2d.backend.model.formats;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.chain.ChainElement;
import ch.supsi.ed2d.backend.model.formats.chain.ReadChainRequest;
import ch.supsi.ed2d.backend.model.formats.chain.WriteChainRequest;

import java.io.*;

public class ImagePPM implements IReadImage, ChainElement {
    private ChainElement nextElement;
    private GenericImage image;
    private float colorRange;


    public ImagePPM() {


    }

    public float getColorRange() {
        return colorRange;
    }

    float setColorRange(String line) {

        String[] str1 = line.split("\\s+");

        for (int i = 0; i < str1.length; i++) {

            if (!str1[i].equals(""))
                this.colorRange = Float.parseFloat(str1[i]);
        }
        return colorRange;
    }

    @Override
    public GenericImage readData(ReadChainRequest request) throws IOException {

        GenericImage.reset();
        this.image = GenericImage.getInstance();
        BufferedReader br = request.getReader();
        String line;
        line = br.readLine();
        image.setFtype(request.getType());
        while ((line.charAt(0) == '#') || (line.equals("P3")))
            line = br.readLine();

        image.setRowsColumns(line);
        line = br.readLine();
        image.setColorRange(setColorRange(line));

        String[] allValues = image.getAllValuesOfMatrix(br, image.getColumns() * image.getRows() * 3);
        CellRGB[][] bits = initCellRGB(allValues);

        image.setBits(bits);

        return image;
    }

    CellRGB[][] initCellRGB(String[] allValues) {

        CellRGB[][] cellRGBS = new CellRGB[image.getRows()][image.getColumns()];

        int s = 0;
        for (int i = 0; i < image.getRows(); i++) {
            for (int j = 0; j < image.getColumns(); j++) {

                cellRGBS[i][j] = new CellRGB();
                cellRGBS[i][j].setR(Integer.parseInt(allValues[s]));
                ++s;
                cellRGBS[i][j].setG(Integer.parseInt(allValues[s]));
                ++s;
                cellRGBS[i][j].setB(Integer.parseInt(allValues[s]));
                ++s;
                cellRGBS[i][j].normalize(getColorRange());
            }
        }
        return cellRGBS;
    }


    @Override
    public void setNextElement(ChainElement next) {
        this.nextElement = next;
    }

    @Override
    public GenericImage executeRead(ReadChainRequest r) throws IOException {
        if (r.getType() == PortableBitmapImage.P3) {
            return readData(r);
        } else {
            if (nextElement != null)
                return nextElement.executeRead(r);
            else
                return null;
        }
    }

    @Override
    public boolean executeWrite(WriteChainRequest r, GenericImage image) throws IOException {
        if (r.getType() == PortableBitmapImage.ppm) {
            return saveData(r, image);
        } else {
            if (nextElement != null)
                return nextElement.executeWrite(r, image);
            else
                return false;
        }
    }

    boolean saveData(WriteChainRequest r, GenericImage image) throws IOException {
        BufferedWriter writer = r.getBufferedWriter();
        StringBuilder stringBuilder = new StringBuilder();
        int rows = image.getRows();
        int columns = image.getColumns();
        float colorRange = image.getColorRange();
        CellRGB[][] bits = image.getBits();
        stringBuilder.append("P3").append("\n").append(columns).append(" ").append(rows).append("\n")
                .append((int) colorRange).append("\n");
        for(int i =0; i<rows; i++)
        {
            for(int j =0; j<columns; j++)
            {
                stringBuilder.append((int) (bits[i][j].getR()*colorRange)).append(" ")
                        .append((int) (bits[i][j].getG()*colorRange)).append(" ")
                        .append((int) (bits[i][j].getB()*colorRange)).append(" ");

            }
            stringBuilder.append("\n");
        }
        writer.write(stringBuilder.toString());
        writer.close();
        return true;
    }

    public void setImage(GenericImage genericImage) {
        this.image = genericImage;
    }

    public GenericImage getImage() {
        return image;
    }

    public ChainElement getNextElement() {
        return nextElement;
    }

}