package ch.supsi.ed2d.backend.model.formats;

public enum PortableBitmapImage {
    P1,P2,P3,pbm,pgm,ppm
}
