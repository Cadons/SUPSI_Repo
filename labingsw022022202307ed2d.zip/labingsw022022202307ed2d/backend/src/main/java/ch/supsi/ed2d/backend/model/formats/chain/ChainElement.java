package ch.supsi.ed2d.backend.model.formats.chain;

import ch.supsi.ed2d.backend.model.formats.GenericImage;

import java.io.IOException;

public interface ChainElement {
    void setNextElement(ChainElement next);
    GenericImage executeRead(ReadChainRequest r) throws IOException;
    boolean executeWrite(WriteChainRequest r, GenericImage image) throws IOException;

}
