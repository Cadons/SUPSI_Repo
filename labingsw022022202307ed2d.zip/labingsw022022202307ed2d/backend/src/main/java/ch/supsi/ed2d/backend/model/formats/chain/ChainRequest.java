package ch.supsi.ed2d.backend.model.formats.chain;

import ch.supsi.ed2d.backend.model.formats.PortableBitmapImage;

public abstract class ChainRequest {

    private final PortableBitmapImage type;

    public ChainRequest(PortableBitmapImage type) {
        this.type = type;
    }

    public PortableBitmapImage getType() {
        return type;
    }
}
