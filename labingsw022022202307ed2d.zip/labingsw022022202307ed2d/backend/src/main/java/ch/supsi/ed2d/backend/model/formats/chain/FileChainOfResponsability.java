package ch.supsi.ed2d.backend.model.formats.chain;

import ch.supsi.ed2d.backend.model.formats.*;

import java.io.*;

public class FileChainOfResponsability {
    private ChainElement head;

    public FileChainOfResponsability() {
        head = new ImagePBM();
        ChainElement pgm = new ImagePGM();
        ChainElement ppm = new ImagePPM();

        head.setNextElement(pgm);
        pgm.setNextElement(ppm);
    }

    public GenericImage getImage(File file) throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader(file));
        try {
            var type = PortableBitmapImage.valueOf(reader.readLine());
            ReadChainRequest req = new ReadChainRequest(type, reader);

            return head.executeRead(req);
        } catch (IllegalArgumentException e) {
            return null;
        }

    }

    public boolean saveImage(String absolutePath, GenericImage image) throws IOException {

        int i = absolutePath.lastIndexOf('.');
        String ext = "";
        if (i > 0) {
            ext = absolutePath.substring(i + 1);
        }
        BufferedWriter writer = new BufferedWriter(new FileWriter(absolutePath));
        try {
            var type = PortableBitmapImage.valueOf(ext);
            WriteChainRequest req = new WriteChainRequest(type, writer);
            return head.executeWrite(req, image);

        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
