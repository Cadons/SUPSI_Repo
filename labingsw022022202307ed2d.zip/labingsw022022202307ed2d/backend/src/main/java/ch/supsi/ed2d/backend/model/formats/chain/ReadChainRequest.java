package ch.supsi.ed2d.backend.model.formats.chain;

import ch.supsi.ed2d.backend.model.formats.PortableBitmapImage;

import java.io.BufferedReader;

public class ReadChainRequest extends ChainRequest{

    private final BufferedReader reader;

    public ReadChainRequest(PortableBitmapImage type, BufferedReader reader) {
        super(type);
        this.reader = reader;
    }

    public BufferedReader getReader() {
        return reader;
    }
}
