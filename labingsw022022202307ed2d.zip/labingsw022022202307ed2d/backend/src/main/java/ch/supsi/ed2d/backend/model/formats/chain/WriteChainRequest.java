package ch.supsi.ed2d.backend.model.formats.chain;

import ch.supsi.ed2d.backend.model.formats.PortableBitmapImage;

import java.io.BufferedWriter;

public class WriteChainRequest extends ChainRequest{

    private final BufferedWriter bufferedWriter;

    public WriteChainRequest(PortableBitmapImage type, BufferedWriter bufferedWriter) {
        super(type);
        this.bufferedWriter = bufferedWriter;
    }

    public BufferedWriter getBufferedWriter() {
        return bufferedWriter;
    }
}
