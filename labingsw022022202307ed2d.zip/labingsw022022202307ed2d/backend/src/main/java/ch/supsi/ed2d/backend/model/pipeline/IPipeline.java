package ch.supsi.ed2d.backend.model.pipeline;

import java.util.ArrayList;

public interface IPipeline {
    public ArrayList<PipelineItem> getPipeline();
    public PipelineItem get(int index);
    public boolean remove(int index);
    public int size();

    public void clear();
}
