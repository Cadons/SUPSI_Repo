package ch.supsi.ed2d.backend.model.pipeline;

import ch.supsi.ed2d.backend.service.IPipeliner;

import java.util.ArrayList;
import java.util.Collections;

public class Pipeline implements IPipeline {
    private ArrayList<PipelineItem> pipeline=new ArrayList<>();

    public Memento takeSnapshot(){
        return new Memento(this.pipeline);
    }
    public void add(PipelineItem filter)
    {
        pipeline.add(filter);
    }
    public int size()
    {
        return pipeline.size();
    }
    public ArrayList<PipelineItem> getPipeline()
    {
        return (ArrayList<PipelineItem>) pipeline.clone();
    }
    public PipelineItem get(int index)
    {
        return pipeline.get(index);
    }
    public boolean remove(int index)
    {
        if(index>=0&&index< pipeline.size()){
            pipeline.remove(index);
            return true;
        }

        return false;
    }
    public void clear()
    {
        pipeline=new ArrayList<>();
    }
    public void restore(Memento memento){
        pipeline=memento.getPipeline();
    }


    public static class Memento{
        private final ArrayList<PipelineItem> pipeline;
        private Memento(ArrayList<PipelineItem> pipeline){
            this.pipeline= (ArrayList<PipelineItem>) pipeline.clone();
        }
        private ArrayList<PipelineItem> getPipeline(){
            return pipeline;
        }
        public int size(){
            return pipeline.size();
        }
        @Override
        public String toString() {
            String output="{";
            for (PipelineItem e : pipeline){
                output+=e.getName()+","+e.getId()+",";
            }
            output+="}";
            return output;
        }

    }
}
