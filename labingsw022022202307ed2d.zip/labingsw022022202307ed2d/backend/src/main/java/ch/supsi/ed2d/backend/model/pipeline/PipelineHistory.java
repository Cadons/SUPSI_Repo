package ch.supsi.ed2d.backend.model.pipeline;

import java.util.ArrayList;
import java.util.Stack;

public class PipelineHistory implements IPipeline{
    private Stack<Pipeline.Memento> historyUndo =new Stack<>();
    private Stack<Pipeline.Memento> historyRedo =new Stack<>();
    private Pipeline pipeline=new Pipeline();
    public void add(PipelineItem p){
        pipeline.add(p);
        historyUndo.push(pipeline.takeSnapshot());
    }
    public boolean remove(int index){

            var out=pipeline.remove(index);
            if(out)
                 historyUndo.push(pipeline.takeSnapshot());
            return out;


    }

    @Override
    public ArrayList<PipelineItem> getPipeline() {
        return pipeline.getPipeline();
    }

    @Override
    public PipelineItem get(int index) {
        return pipeline.get(index);
    }

    @Override
    public int size() {
        return pipeline.size();
    }


    public void clear(){
        pipeline.clear();
        historyUndo.push(pipeline.takeSnapshot());
    }
    public boolean undo(){
        if(historyUndo.isEmpty())
            return false;
       historyRedo.push(historyUndo.pop());

        if(!historyUndo.isEmpty())
        pipeline.restore(historyUndo.peek());
        else
            pipeline.restore(new Pipeline().takeSnapshot());
        return true;
    }
    public boolean redo(){
        if(historyRedo.isEmpty())
            return false;
        historyUndo.push(historyRedo.pop());
        if(!historyRedo.isEmpty())
            pipeline.restore(historyRedo.peek());

        return true;
    }
    public boolean isUndoEmpty(){return historyUndo.isEmpty();}
    public boolean isRedoEmpty(){return historyRedo.isEmpty();}
    public Pipeline.Memento getCurrent(){
        return historyUndo.peek();
    }
}
