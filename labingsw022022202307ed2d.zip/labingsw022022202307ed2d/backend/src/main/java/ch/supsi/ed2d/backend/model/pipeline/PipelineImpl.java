package ch.supsi.ed2d.backend.model.pipeline;

import java.util.ArrayList;
import java.util.Stack;

public class PipelineImpl implements IPipeline {
    private Stack<Pipeline.Memento> historyUndo = new Stack<>();
    private Stack<Pipeline.Memento> historyRedo = new Stack<>();
    private Pipeline pipeline = new Pipeline();
    private static PipelineImpl instance;

    PipelineImpl() {

    }

    public static PipelineImpl getInstance() {
        if (instance == null)
            instance = new PipelineImpl();
        return instance;
    }

    public void add(PipelineItem p) {
        pipeline.add(p);
        historyUndo.push(pipeline.takeSnapshot());
        historyRedo.clear();
    }

    public boolean remove(int index) {


        var out = pipeline.remove(index);
        if (out) {
            historyUndo.push(pipeline.takeSnapshot());
            historyRedo.clear();
        }
        return out;


    }

    public void clearAll() {
        historyRedo.clear();
        historyUndo.clear();
    }

    @Override
    public ArrayList<PipelineItem> getPipeline() {
        return pipeline.getPipeline();
    }

    @Override
    public PipelineItem get(int index) {
        return pipeline.get(index);
    }

    @Override
    public int size() {
        return pipeline.size();
    }


    public void clear() {
        pipeline.clear();
        historyUndo.push(pipeline.takeSnapshot());
    }

    public boolean undo() {
        if (historyUndo.isEmpty())
            return false;
        historyRedo.push(historyUndo.pop());

        if (!historyUndo.isEmpty())
            pipeline.restore(historyUndo.peek());
        else
            pipeline.restore(new Pipeline().takeSnapshot());
        return true;
    }

    public boolean redo() {
        if (historyRedo.isEmpty())
            return false;


        if (!historyRedo.isEmpty()) {
            var tmp = historyRedo.pop();
            if (tmp != null) {
                historyUndo.push(tmp);

                pipeline.restore(tmp);
            }

        }


        return true;
    }

    public boolean isUndoEmpty() {
        return historyUndo.isEmpty();
    }

    public boolean isRedoEmpty() {
        return historyRedo.isEmpty();
    }

    public Pipeline.Memento getCurrent() {
        return historyUndo.peek();
    }
}
