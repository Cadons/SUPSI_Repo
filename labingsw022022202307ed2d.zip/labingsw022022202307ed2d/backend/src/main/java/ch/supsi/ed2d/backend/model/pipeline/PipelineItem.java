package ch.supsi.ed2d.backend.model.pipeline;

import ch.supsi.ed2d.backend.model.CellRGB;

import java.util.UUID;

public interface PipelineItem {
    PipelineResult apply(CellRGB[][] input);

    String getName();
    UUID getId();
    PipelineItem create();
}
