package ch.supsi.ed2d.backend.model.pipeline;

import ch.supsi.ed2d.backend.model.CellRGB;

/**
 * @apiNote this class represent the pipeline result, if it pass it will have completed field sets on true and in the value it will have the result of the matrix
 * */
public class PipelineResult {

    private final CellRGB[][] value;
    private final boolean completed;

    /**
     * @param status
     * @param value
     */
    public PipelineResult(boolean status,CellRGB[][] value ) {
        this.value = value;
        this.completed = status;
    }

    /**
     * @return the status of the operation
     */
    public boolean isCompleted() {
        return completed;
    }

    /**
     * @return the value of the matrix
     */

    public float[][] getValueAsFloat() {
        return CellRGB.convertToFloatMatrix(value);
    }
    public CellRGB[][] getValue() {
        return value;
    }
}
