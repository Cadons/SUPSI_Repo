package ch.supsi.ed2d.backend.repository;

import ch.supsi.ed2d.backend.model.filters.Rescaling;
import ch.supsi.ed2d.backend.model.filters.Sepia;

import ch.supsi.ed2d.backend.model.filters.Sharpness;
import ch.supsi.ed2d.backend.model.pipeline.PipelineItem;
import ch.supsi.ed2d.backend.model.filters.GrayScale;

import java.util.ArrayList;

public class FiltersRepository implements IFilterService {

    private static FiltersRepository instance;
    private FiltersRepository(){

    }
    public static FiltersRepository getInstance(){
        if(instance==null)
            instance=new FiltersRepository();
        return instance;
    }
    @Override
    public ArrayList<PipelineItem> getFilters() {
        ArrayList<PipelineItem> filters=new ArrayList<>();

       filters.add(new GrayScale());
       filters.add(new Sepia());
filters.add(new Rescaling());
filters.add(new Sharpness());
        return filters;
    }
}
