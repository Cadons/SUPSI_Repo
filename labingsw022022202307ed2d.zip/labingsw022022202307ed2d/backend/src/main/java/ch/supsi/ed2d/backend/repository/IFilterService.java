package ch.supsi.ed2d.backend.repository;

import ch.supsi.ed2d.backend.model.pipeline.PipelineItem;

import java.util.ArrayList;

public interface IFilterService {
    ArrayList<PipelineItem> getFilters();
}
