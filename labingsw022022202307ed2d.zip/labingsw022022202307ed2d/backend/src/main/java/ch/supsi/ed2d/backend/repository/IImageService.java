package ch.supsi.ed2d.backend.repository;

import ch.supsi.ed2d.backend.exception.FileNotInitializedException;
import ch.supsi.ed2d.backend.exception.FileNotSupportedException;
import ch.supsi.ed2d.backend.model.formats.GenericImage;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public interface IImageService {
    void loadImageFile(File file) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, FileNotSupportedException, FileNotSupportedException, FileNotInitializedException;
    File getFile();
    GenericImage getImage();
    int getImageColumns();
    int getImageRows();
    float[][] getImageMatrix() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException;
    boolean isImageLoaded();
    boolean saveImageFile(String absolutePath);
}

