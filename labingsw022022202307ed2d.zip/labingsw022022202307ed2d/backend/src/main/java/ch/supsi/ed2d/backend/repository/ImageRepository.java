package ch.supsi.ed2d.backend.repository;
import ch.supsi.ed2d.backend.exception.FileNotInitializedException;
import ch.supsi.ed2d.backend.exception.FileNotSupportedException;
import ch.supsi.ed2d.backend.model.*;
import ch.supsi.ed2d.backend.model.formats.GenericImage;
import ch.supsi.ed2d.backend.model.formats.chain.FileChainOfResponsability;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class ImageRepository implements IImageService {

    //instance of the uploaded file
    private File file;
    //instance of the uploaded image
    private GenericImage image;

    private static ImageRepository instance;

    private ImageRepository(){

    }

    public static ImageRepository getInstance(){
        if(instance==null)
            instance=new ImageRepository();
        return instance;
    }

    //method used to load the generic image file
    public void loadImageFile(File file) throws FileNotSupportedException, FileNotInitializedException, IOException {
        if (file == null)
            throw new FileNotInitializedException();
        this.file = file;
        image=new FileChainOfResponsability().getImage(file);
        if(image==null)
        {
            throw new FileNotSupportedException();
        }
    }

    @Override
    public float[][] getImageMatrix(){
        return CellRGB.convertToFloatMatrix(image.getBits());
    }

    //method to get the instance of the uploaded file
    public File getFile() {
        return file;
    }

    @Override
    public boolean isImageLoaded() {
        return image!=null;
    }

    /**
     * method used to create different instances of the Image* classes
     * @return
     */

    public GenericImage getImage() {
        return image;
    }

    public int getImageColumns() {
        return getImage().getColumns();
    }

    public int getImageRows() {
        return getImage().getRows();
    }

    public boolean saveImageFile(String absolutePath) {
        try{
            new FileChainOfResponsability().saveImage(absolutePath, image);
            return true;
        }catch (IOException e){
            return false;
        }
    }
}