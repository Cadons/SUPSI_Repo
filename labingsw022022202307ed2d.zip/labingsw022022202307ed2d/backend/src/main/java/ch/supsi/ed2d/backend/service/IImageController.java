package ch.supsi.ed2d.backend.service;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.GenericImage;

import java.io.File;
import java.io.IOException;

public interface IImageController {
    float[][] getImageMatrix() ;
    GenericImage getImage();
    CellRGB[][] getStartImage();
    boolean loadImageFile(File file) ;
    boolean update(float[][] image);
    int getImageColumns();
    int getImageRows();
    boolean isImageLoaded();
    boolean saveImageFile(String absolutePath);
}
