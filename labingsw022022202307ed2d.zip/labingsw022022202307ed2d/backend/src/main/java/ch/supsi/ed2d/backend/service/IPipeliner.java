package ch.supsi.ed2d.backend.service;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.pipeline.PipelineResult;

import java.util.*;

public interface IPipeliner {

    /**
     * @param image
     * @return the result of the pipeline
     */
    PipelineResult apply(CellRGB[][] image);

    /**
     * @param id
     * @return if pipeline element has been added
     */
    UUID add(int id);

    /**
     * @param id
     * @return if pipeline element has been removed
     */
    boolean remove(UUID id);

    /**
     * @return a map of the filters provided by software
     */
    List<Map.Entry<String, Integer>> getFilters();
    int size();
    boolean removeAll();

    ArrayList<Map.Entry<String,String>> undo();
    ArrayList<Map.Entry<String,String>> redo();
    public boolean isUndoEmpty();
    public boolean isRedoEmpty();
}
