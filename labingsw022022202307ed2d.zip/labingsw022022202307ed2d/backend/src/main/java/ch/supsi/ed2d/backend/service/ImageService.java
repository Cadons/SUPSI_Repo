package ch.supsi.ed2d.backend.service;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.GenericImage;
import ch.supsi.ed2d.backend.model.pipeline.PipelineImpl;
import ch.supsi.ed2d.backend.repository.IImageService;
import ch.supsi.ed2d.backend.repository.ImageRepository;

import java.io.File;


public class ImageService implements IImageController {

    //reference to repository layer
    private final IImageService repositoryLayer=ImageRepository.getInstance();
    private static ImageService instance;

    public ImageService()  {
    }

    public static ImageService getInstance(){
        if(instance==null)
            instance=new ImageService();
        return instance;
    }

    //method to get the bitMap of the uploaded image
    @Override
    public float[][] getImageMatrix(){
        try {
            return repositoryLayer.getImageMatrix();
        } catch (Exception e) {
          return null;
        }
    }

    //method used to load the generic image file
    @Override
    public boolean loadImageFile(File file){
        try {
            repositoryLayer.loadImageFile(file);
            PipelineImpl.getInstance().clearAll();
            return true;
        }catch (Exception e)
        {
            return false;
        }
    }

    @Override
    public boolean update(float[][] image) {
        return getImage().update(CellRGB.createMatrix(image));
    }

    @Override
    public int getImageColumns() {
        return repositoryLayer.getImageColumns();
    }
    @Override
    public int getImageRows() {
        return repositoryLayer.getImageRows();
    }

    //method to get the instance of the uploaded image
    @Override
    public GenericImage getImage() {
        return repositoryLayer.getImage();
    }

    @Override
    public CellRGB[][] getStartImage() {
        return getImage().getStartData();
    }


    @Override
    public boolean isImageLoaded() {
        return repositoryLayer.isImageLoaded();
    }

    @Override
    public boolean saveImageFile(String absolutePath) {
        return repositoryLayer.saveImageFile(absolutePath);
    }
}