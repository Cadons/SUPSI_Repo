package ch.supsi.ed2d.backend.service;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.GenericImage;
import ch.supsi.ed2d.backend.model.pipeline.Pipeline;
import ch.supsi.ed2d.backend.model.pipeline.PipelineHistory;
import ch.supsi.ed2d.backend.model.pipeline.PipelineItem;
import ch.supsi.ed2d.backend.model.pipeline.PipelineResult;
import ch.supsi.ed2d.backend.repository.FiltersRepository;
import ch.supsi.ed2d.backend.repository.IFilterService;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class Pipeliner implements IPipeliner {

    private static Pipeliner instance;

    private IFilterService filtersRepo = FiltersRepository.getInstance();
    private final PipelineHistory pipeline = new PipelineHistory();

    private List<PipelineItem> filters;

    private Pipeliner() {
        this.filters = filtersRepo.getFilters();

    }

    public static Pipeliner getInstance() {
        if (instance == null)
            instance = new Pipeliner();
        return instance;
    }

    @Override
    public PipelineResult apply(CellRGB[][] image) {

        GenericImage.getInstance().setRows(image.length);
        GenericImage.getInstance().setColumns(image[0].length);

        CellRGB[][] output = image;
        if (output != null) {
            if (pipeline.size() > 0)
                for (PipelineItem e : pipeline.getPipeline()) {
                    var result = e.apply(output);
                    var partial = result.getValue();


                    if (result.isCompleted())
                        output = result.getValue();
                    else
                        return new PipelineResult(false, null);
                }

            return new PipelineResult(true, output);
        } else {
            return new PipelineResult(false, null);
        }
    }

    @Override
    public UUID add(int filter) {
        if (filter < filters.size() && filter >= 0) {
            pipeline.add(filters.get(filter).create());

            return pipeline.get(pipeline.size() - 1).getId();
        } else {
            return null;
        }
    }

    @Override
    public boolean remove(UUID id) {
        AtomicBoolean result = new AtomicBoolean(false);
        AtomicInteger i = new AtomicInteger();

        for (PipelineItem p : pipeline.getPipeline())
        {
            if (p.getId().equals(id)) {

                result.set(pipeline.remove(i.get()));
                break;
            }
            i.addAndGet(1);
        }

        return result.get();
    }

    @Override
    public List<Map.Entry<String, Integer>> getFilters() {
        if (filters.size() == 0)//the filters are static, hardcoded
            filters = filtersRepo.getFilters();
        TreeMap<String, Integer> filtersName = new TreeMap<>();
        filters.forEach(e -> filtersName.put(e.getName(), filters.indexOf(e)));
        List<Map.Entry<String, Integer>> list = new ArrayList<>(filtersName.entrySet());
        list.sort(Map.Entry.comparingByValue());

        return list;
    }

    @Override
    public int size() {
        return pipeline.size();
    }

    @Override
    public boolean removeAll() {
        if (pipeline != null) {
            pipeline.clear();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public  ArrayList<Map.Entry<String,String>> undo() {
        pipeline.undo();

        return updatedPipeline();
    }

    @Override
    public  ArrayList<Map.Entry<String,String>> redo() {
        pipeline.redo();
        return updatedPipeline();
    }

    @Override
    public boolean isUndoEmpty() {
        return pipeline.isUndoEmpty();
    }

    @Override
    public boolean isRedoEmpty() {
        return pipeline.isRedoEmpty();
    }

    private ArrayList<Map.Entry<String,String>> updatedPipeline(){
        var newPipeline=pipeline.getPipeline();
        ArrayList<Map.Entry<String,String>> output=new ArrayList<>();
        newPipeline.forEach(e->{
            output.add(Map.entry(e.getId().toString(),e.getName()));
        });
        return output;
    }
}
