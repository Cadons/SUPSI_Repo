package ch.supsi.ed2d.backend.controller;

import ch.supsi.ed2d.backend.controller.PipelineController;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;


import static org.junit.jupiter.api.Assertions.*;

public class TestPipelineController {
    @Test
    public void testRemove(){
        var controller=new PipelineController();
        ArrayList<String> uuid=new ArrayList<>();

        assertEquals(true,controller.remove(controller.add(0)));
        assertEquals(false,controller.remove(UUID.randomUUID().toString()));

    }
    @Test
    public void testAdd(){
        var controller=new PipelineController();
        assertNull(controller.add(-1));
        assertNull(controller.add(100));
        var filters=controller.getFilters();
        assertNotNull(controller.add(filters.get(0).getValue()));
        assertNull(controller.add(10));


    }
    @Test
    public void testGetFilters(){
        var controller=new PipelineController();
        ArrayList<String> t=new ArrayList<>();

        controller.getFilters().forEach(e->{
           t.add(e.getKey());
        });
        assertArrayEquals(new String[]{"Gray Scale","Sepia","Rescaling","Sharpness"},t.toArray());
    }
}
