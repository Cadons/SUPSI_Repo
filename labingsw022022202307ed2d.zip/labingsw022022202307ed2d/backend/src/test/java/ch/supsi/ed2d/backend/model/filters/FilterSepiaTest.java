package ch.supsi.ed2d.backend.model.filters;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.GenericImage;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

public class FilterSepiaTest {

    Sepia sepia = new Sepia();


    @Test
    public void apply(){

        CellRGB[][] bitMap = new CellRGB[][] {
                { new CellRGB(1, 2, 3), new CellRGB(4, 5, 6) },
                { new CellRGB(7, 8, 9), new CellRGB(10, 11, 12) }
        };
        CellRGB[][] expected = new CellRGB[][] {
                { new CellRGB(1, 1, 1), new CellRGB(1, 1, 1) },
                { new CellRGB(1, 1, 1), new CellRGB(1, 1, 1) }
        };

        assertArrayEquals(expected,sepia.apply(bitMap).getValue());
    }


}
