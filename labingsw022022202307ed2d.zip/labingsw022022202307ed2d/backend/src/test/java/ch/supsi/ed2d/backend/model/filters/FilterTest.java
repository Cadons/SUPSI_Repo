package ch.supsi.ed2d.backend.model.filters;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class FilterTest {



    @Test
    void getName(){

        Filter filter = new GrayScale();

        assertEquals("Gray Scale",filter.getName());

    }
}
