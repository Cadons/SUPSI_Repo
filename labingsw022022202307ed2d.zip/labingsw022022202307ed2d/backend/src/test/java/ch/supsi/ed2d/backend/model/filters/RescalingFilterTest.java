package ch.supsi.ed2d.backend.model.filters;

import ch.supsi.ed2d.backend.controller.ScalingController;
import ch.supsi.ed2d.backend.model.CellRGB;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

public class RescalingFilterTest {

    Rescaling rescaling = new Rescaling();
    ScalingController scalingController= new ScalingController();


    @Test
    public void apply(){

        scalingController.setValue(200);

        CellRGB[][] expected = new CellRGB[][] {
                { new CellRGB(1, 1, 1), new CellRGB(1, 1, 1) },
                { new CellRGB(1, 1, 1), new CellRGB(1, 1, 1) }
        };

        CellRGB[][] expected1 = new CellRGB[][] {
                { new CellRGB(1, 1, 1), new CellRGB(1, 1, 1), new CellRGB(1, 1, 1), new CellRGB(1, 1, 1) },
                { new CellRGB(1, 1, 1), new CellRGB(1, 1, 1), new CellRGB(1, 1, 1), new CellRGB(1, 1, 1) },
                { new CellRGB(1, 1, 1), new CellRGB(1, 1, 1), new CellRGB(1, 1, 1), new CellRGB(1, 1, 1) },
                { new CellRGB(1, 1, 1), new CellRGB(1, 1, 1), new CellRGB(1, 1, 1), new CellRGB(1, 1, 1) }
        };

        assertArrayEquals(expected1,rescaling.apply(expected).getValue());
    }

}
