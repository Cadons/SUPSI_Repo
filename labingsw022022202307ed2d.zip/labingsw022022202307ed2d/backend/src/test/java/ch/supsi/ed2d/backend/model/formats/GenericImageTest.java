package ch.supsi.ed2d.backend.model.formats;

import ch.supsi.ed2d.backend.model.CellRGB;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;

import static org.junit.jupiter.api.Assertions.*;

class GenericImageTest {
    GenericImage genericImage = GenericImage.getInstance();
    CellRGB[][] bitMap = new CellRGB[][] {
            { new CellRGB(1, 2, 3), new CellRGB(4, 5, 6) },
            { new CellRGB(7, 8, 9), new CellRGB(10, 11, 12) }
    };
    @Test
    public void testGetInstance(){
        assertNotNull(genericImage);
    }

    @Test
    public void testGetColorRange(){
        genericImage.setColorRange(100);
        assertEquals(100, genericImage.getColorRange());
    }

    @Test
    public void testSetColorRange(){
        genericImage.setColorRange(100);
        assertEquals(100, genericImage.getColorRange());
    }

    @Test
    public void testGetBits(){

        genericImage.setBits(bitMap);
        assertArrayEquals(bitMap, genericImage.getBits());
    }

    @Test
    public void testSetBits(){

        genericImage.setBits(bitMap);
        assertArrayEquals(bitMap, genericImage.getBits());
    }

    @Test
    public void testGetStartData(){

        genericImage.setBits(bitMap);
        //assertArrayEquals(bitMap, genericImage.getStartData());
    }

    @Test
    public void testSetRows(){
        genericImage.setRows(100);
        assertEquals(100, genericImage.getRows());
    }

    @Test
    public void testGetRows(){
        genericImage.setRows(100);
        assertEquals(100, genericImage.getRows());
    }

    @Test
    public void testSetColumns(){
        genericImage.setColumns(100);
        assertEquals(100, genericImage.getColumns());
    }

    @Test
    public void testGetColumns(){
        genericImage.setColumns(100);
        assertEquals(100, genericImage.getColumns());
    }

    @Test
    public void testGetAllValuesOfMatrix() throws IOException {
        String input = "1 2 3\n4 5 6\n7 8 9\n10 11 12";

        BufferedReader br = new BufferedReader(new StringReader(input));

        String[] values = genericImage.getAllValuesOfMatrix( br, 12);

        String[] expected = new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" };
        assertArrayEquals(expected, values);
    }

    @Test
    public void testUpdate(){

        boolean result = genericImage.update(bitMap);

        assertTrue(result);

        assertArrayEquals(bitMap, genericImage.getBits());

        result = genericImage.update(null);

        assertFalse(result);
    }

    @Test
    public void testGetRowsColumns(){
        genericImage.setRowsColumns("3 4");
        assertEquals(4, genericImage.getRows());
        assertEquals(3, genericImage.getColumns());
    }



}
