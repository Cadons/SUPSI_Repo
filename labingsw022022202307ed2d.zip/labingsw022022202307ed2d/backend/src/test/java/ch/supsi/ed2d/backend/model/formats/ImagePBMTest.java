package ch.supsi.ed2d.backend.model.formats;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.chain.ChainElement;
import ch.supsi.ed2d.backend.model.formats.chain.ReadChainRequest;
import ch.supsi.ed2d.backend.model.formats.chain.WriteChainRequest;
import org.junit.jupiter.api.Test;

import java.io.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ImagePBMTest {

    @Test
    public void testExecuteRead() throws IOException {
        // Create a mock ReadChainRequest object with a FormatType other than P1
        ReadChainRequest mockRequest = mock(ReadChainRequest.class);
        when(mockRequest.getType()).thenReturn(PortableBitmapImage.P2);

        // Create a mock ImagePBM object to use as the next element in the chain
        ImagePBM mockNextElement = mock(ImagePBM.class);

        // Create an instance of ImagePBM and set its nextElement field to the mock object
        ImagePBM obj = new ImagePBM();
        obj.setNextElement(mockNextElement);

        // Set up the mock executeRead method to return null
        when(mockNextElement.executeRead(mockRequest)).thenReturn(null);

        // Call the executeRead method with the mock request object
        GenericImage result = obj.executeRead(mockRequest);

        // Assert that the executeRead method returned null
        assertNull(result);
    }

    @Test
    public void testExecuteWrite() throws IOException {
        // Create an instance of the Image class
        ImagePBM image = new ImagePBM();

        // Set the rows, columns, color range, and bits for the image
        image.setImage(new GenericImage());
        image.getImage().setRows(2);
        image.getImage().setColumns(2);
        image.getImage().setBits(new CellRGB[][] {
                {new CellRGB(0.0f, 0.0f, 0.0f), new CellRGB(0.0f, 0.0f, 0.0f)},
                {new CellRGB(0.0f, 0.0f, 0.0f), new CellRGB(0.0f, 0.0f, 0.0f)}
        });

        // Create a StringWriter to capture the output of the executeWrite method
        StringWriter output = new StringWriter();

        // Create a BufferedWriter from the output StringWriter
        BufferedWriter writer = new BufferedWriter(output);

        // Create a WriteChainRequest with the writer and PortableBitmapImage.pbm
        WriteChainRequest request = new WriteChainRequest(PortableBitmapImage.pbm, writer);

        // Invoke the executeWrite method
        boolean result = image.executeWrite(request, image.getImage());

        // Verify that the executeWrite method returned true
        assertTrue(result);

        // Verify that the output written to the BufferedWriter is what you expect
        assertEquals("P1\n2 2\n0 0 0 0 0 0 \n0 0 0 0 0 0 \n", output.toString());
    }

    @Test
    public void testReadData() throws IOException {
        // Set up a test string to be used as the input
        String input = "3 4\n1 2 3 4\n5 6 7 8\n9 10 11 12";

        // Create a mock ReadChainRequest object with a FormatType of P1
        ReadChainRequest mockRequest = mock(ReadChainRequest.class);
        when(mockRequest.getType()).thenReturn(PortableBitmapImage.P1);

        // Create a BufferedReader from the input string and set it as the reader in the mock request object
        when(mockRequest.getReader()).thenReturn(new BufferedReader(new StringReader(input)));

        // Create an instance of ImagePBM
        ImagePBM obj = new ImagePBM();

        // Call the readData method with the mock request object
        GenericImage result = obj.readData(mockRequest);

        // Assert that the rows field of the result is equal to 4
        assertEquals(4, result.getRows());

        // Assert that the columns field of the result is equal to 3
        assertEquals(3, result.getColumns());
    }

    @Test
    public void testInitCellRGB(){
        // Create an instance of ImagePBM
        ImagePBM obj = new ImagePBM();

        // Set the rows and columns fields of the object to 2 and 3, respectively
        obj.setImage(new GenericImage());
        obj.getImage().setRows(2);
        obj.getImage().setColumns(3);

        // Call the initCellRGB method with an array of values
        String[] allValues = new String[] { "1", "0", "1", "1", "0", "0" };
        CellRGB[][] result = obj.initCellRGB(allValues);

        // Assert that the returned array is equal to the expected array
        CellRGB[][] expected = new CellRGB[][] {
                { new CellRGB(0, 0, 0), new CellRGB(1, 1, 1), new CellRGB(0, 0, 0) },
                { new CellRGB(0, 0, 0), new CellRGB(1, 1, 1), new CellRGB(1, 1, 1) }
        };
        assertArrayEquals(expected, result);

    }

    @Test
    public void testSetNextElement(){
        // Create an instance of YourClassName
        ImagePBM obj = new ImagePBM();

        // Create a mock ChainElement object
        ChainElement mockElement = mock(ChainElement.class);

        // Call the setNextElement method with the mock element
        obj.setNextElement(mockElement);

        // Assert that the nextElement field of the object is set to the mock element
        assertSame(mockElement, obj.getNextElement());
    }

    @Test
    public void testSaveData() throws IOException {
    // Set up a test image object with a color range of 2 and some bits
        GenericImage mockImage = mock(GenericImage.class);
        when(mockImage.getColorRange()).thenReturn(2f);
        CellRGB[][] bits = new CellRGB[][] {
                { new CellRGB(0.5f, 0.5f, 0.5f), new CellRGB(0.75f, 0.75f, 0.75f) },
                { new CellRGB(1f, 1f, 1f), new CellRGB(0f, 0f, 0f) }
        };
        when(mockImage.getBits()).thenReturn(bits);
        when(mockImage.getRows()).thenReturn(2);
        when(mockImage.getColumns()).thenReturn(2);
        // Set up a mock BufferedWriter object
        BufferedWriter mockWriter = mock(BufferedWriter.class);

        // Set up a mock WriteChainRequest object with the mock BufferedWriter
        WriteChainRequest mockRequest = mock(WriteChainRequest.class);
        when(mockRequest.getBufferedWriter()).thenReturn(mockWriter);

        // Create an instance of ImagePBM
        ImagePBM obj = new ImagePBM();

        // Call the saveData method with the mock request and image objects
        assertTrue(obj.saveData(mockRequest, mockImage));

        // Verify that the write method of the mock BufferedWriter was called with the expected string
        verify(mockWriter).write("P1\n2 2\n0 0 0 1 1 1 \n1 1 1 0 0 0 \n");

        // Verify that the close method of the mock BufferedWriter was called
        verify(mockWriter).close();

    }

    @Test
    public void testSetImage(){
        // Create an instance of ImagePBM
        ImagePBM obj = new ImagePBM();

        // Create a mock GenericImage object
        GenericImage mockImage = mock(GenericImage.class);

        // Call the setImage method with the mock image
        obj.setImage(mockImage);

        // Assert that the image field of the object is set to the mock image
        assertSame(mockImage, obj.getImage());
    }

    @Test
    public void testGetImage(){
        // Create an instance of ImagePBM
        ImagePBM obj = new ImagePBM();

        // Create a mock GenericImage object
        GenericImage mockImage = mock(GenericImage.class);

        // Set the image field of the object to the mock image
        obj.setImage(mockImage);

        // Call the getImage method
        GenericImage result = obj.getImage();

        // Assert that the getImage method returned the mock image
        assertSame(mockImage, result);
    }

    @Test
    public void testGetNextElement(){
        // Create an instance of ImagePBM
        ImagePBM obj = new ImagePBM();

        // Create a mock ChainElement object
        ChainElement mockElement = mock(ChainElement.class);

        // Set the nextElement field of the object to the mock element
        obj.setNextElement(mockElement);

        // Call the getNextElement method
        ChainElement result = obj.getNextElement();

        // Assert that the getNextElement method returned the mock element
        assertSame(mockElement, result);
    }

}
