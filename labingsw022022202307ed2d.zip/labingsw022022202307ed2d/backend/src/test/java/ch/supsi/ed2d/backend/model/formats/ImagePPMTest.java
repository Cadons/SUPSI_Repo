package ch.supsi.ed2d.backend.model.formats;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.chain.ChainElement;
import ch.supsi.ed2d.backend.model.formats.chain.ReadChainRequest;
import ch.supsi.ed2d.backend.model.formats.chain.WriteChainRequest;
import org.junit.jupiter.api.Test;

import java.io.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ImagePPMTest {
    @Test
    public void testSetColorRange(){
        // Create an instance of ImagePPM
        ImagePPM obj = new ImagePPM();

        // Invoke the setColorRange method
        obj.setColorRange(String.valueOf(255));

        // Verify that the colorRange field was set to 255
        assertEquals(255, obj.getColorRange());
    }

    @Test
    public void testReadData() throws IOException {
        // Set up a mock BufferedReader that returns the appropriate lines when readLine is called
        BufferedReader mockReader = mock(BufferedReader.class);
        when(mockReader.readLine()).thenReturn("# This is a comment", "2 3", "255", "255 255 255 0 0 0", "0 0 0 255 255 255");

        // Set up a mock ReadChainRequest object with the mock BufferedReader
        ReadChainRequest mockRequest = mock(ReadChainRequest.class);
        when(mockRequest.getReader()).thenReturn(mockReader);

        // Create an instance of ImagePPM
        ImagePPM obj = new ImagePPM();

        // Call the readData method with the mock request
        GenericImage result = obj.readData(mockRequest);

        // Assert that the returned image has the correct properties
        assertEquals(2, result.getColumns());
        assertEquals(3, result.getRows());
        assertEquals(255f, result.getColorRange(), 0.001f);

    }

    @Test
    public void testSetNextElement(){
        // Create an instance of ImagePPM
        ImagePPM obj = new ImagePPM();

        // Create a mock ChainElement object
        ChainElement mockElement = mock(ChainElement.class);

        // Call the setNextElement method with the mock element
        obj.setNextElement(mockElement);

        // Assert that the nextElement field of the object is set to the mock element
        assertSame(mockElement, obj.getNextElement());
    }

    @Test
    public void testExecuteRead() throws IOException {

        ImagePPM image = new ImagePPM();
        // Set the rows, columns, color range, and bits for the image
        image.setImage(new GenericImage());
        image.getImage().setRows(2);
        image.getImage().setColumns(2);
        image.getImage().setColorRange(255.0f);
        image.getImage().setBits(new CellRGB[][] {
                {new CellRGB(0.0f, 0.0f, 0.0f), new CellRGB(0.0f, 0.0f, 0.0f)},
                {new CellRGB(0.0f, 0.0f, 0.0f), new CellRGB(0.0f, 0.0f, 0.0f)}
        });

        // Create a StringWriter to capture the output of the executeWrite method
        StringWriter output = new StringWriter();

        // Create a BufferedWriter from the output StringWriter
        BufferedWriter writer = new BufferedWriter(output);

        // Create a WriteChainRequest with the writer and FormatType.pgm
        WriteChainRequest request = new WriteChainRequest(PortableBitmapImage.ppm, writer);

        // Invoke the executeWrite method
        boolean result = image.executeWrite(request, image.getImage());

        // Verify that the executeWrite method returned true
        assertTrue(result);

        // Verify that the output written to the BufferedWriter is what you expect
        assertEquals("P3\n2 2\n255\n0 0 0 0 0 0 \n0 0 0 0 0 0 \n", output.toString());
    }

    @Test
    public void testExecuteWrite() throws IOException {
// Create an instance of the ImagePPM class
        ImagePPM image = new ImagePPM();

        // Set the rows, columns, color range, and bits for the image
        image.setImage(new GenericImage());
        image.getImage().setRows(2);
        image.getImage().setColumns(2);
        image.getImage().setColorRange(255.0f);
        image.getImage().setBits(new CellRGB[][] {
                {new CellRGB(0.0f, 0.0f, 0.0f), new CellRGB(0.0f, 0.0f, 0.0f)},
                {new CellRGB(0.0f, 0.0f, 0.0f), new CellRGB(0.0f, 0.0f, 0.0f)}
        });

        // Create a StringWriter to capture the output of the executeWrite method
        StringWriter output = new StringWriter();

        // Create a BufferedWriter from the output StringWriter
        BufferedWriter writer = new BufferedWriter(output);

        // Create a WriteChainRequest with the writer and FormatType.pgm
        WriteChainRequest request = new WriteChainRequest(PortableBitmapImage.ppm, writer);

        // Invoke the executeWrite method
        boolean result = image.executeWrite(request, image.getImage());

        // Verify that the executeWrite method returned true
        assertTrue(result);

        // Verify that the output written to the BufferedWriter is what you expect
        assertEquals("P3\n2 2\n255\n0 0 0 0 0 0 \n0 0 0 0 0 0 \n", output.toString());
    }

    @Test
    public void testSaveData() throws IOException {
        // Create an instance of the ImagePPM class
        ImagePPM image = new ImagePPM();

        // Set the rows, columns, color range, and bits for the image
        image.setImage(new GenericImage());
        image.getImage().setRows(2);
        image.getImage().setColumns(2);
        image.getImage().setColorRange(255.0f);
        image.getImage().setBits(new CellRGB[][] {
                {new CellRGB(0.0f, 0.0f, 0.0f), new CellRGB(0.0f, 0.0f, 0.0f)},
                {new CellRGB(0.0f, 0.0f, 0.0f), new CellRGB(0.0f, 0.0f, 0.0f)}
        });

        // Create a StringWriter to capture the output of the saveData method
        StringWriter output = new StringWriter();

        // Create a BufferedWriter from the output StringWriter
        BufferedWriter writer = new BufferedWriter(output);

        // Create a WriteChainRequest with the writer and FormatType.pgm
        WriteChainRequest request = new WriteChainRequest(PortableBitmapImage.pgm, writer);

        // Invoke the saveData method
        boolean result = image.saveData(request, image.getImage());

        // Verify that the saveData method returned true
        assertTrue(result);

        // Verify that the output written to the BufferedWriter is what you expect
        assertEquals("P3\n2 2\n255\n0 0 0 0 0 0 \n0 0 0 0 0 0 \n", output.toString());
    }

    @Test
    public void testSetImage(){
        // Create an instance of ImagePPM
        ImagePPM obj = new ImagePPM();

        // Create a mock GenericImage object
        GenericImage mockImage = mock(GenericImage.class);

        // Call the setImage method with the mock image
        obj.setImage(mockImage);

        // Assert that the image field of the object is set to the mock image
        assertSame(mockImage, obj.getImage());
    }

    @Test
    public void testGetImage(){
        // Create an instance of ImagePPM
        ImagePPM obj = new ImagePPM();

        // Create a mock GenericImage object
        GenericImage mockImage = mock(GenericImage.class);

        // Set the image field of the object to the mock image
        obj.setImage(mockImage);

        // Call the getImage method
        GenericImage result = obj.getImage();

        // Assert that the getImage method returned the mock image
        assertSame(mockImage, result);
    }

    @Test
    public void testGetNextElement(){
        // Create an instance of ImagePPM
        ImagePPM obj = new ImagePPM();

        // Create a mock ChainElement object
        ChainElement mockElement = mock(ChainElement.class);

        // Set the nextElement field of the object to the mock element
        obj.setNextElement(mockElement);

        // Call the getNextElement method
        ChainElement result = obj.getNextElement();

        // Assert that the getNextElement method returned the mock element
        assertSame(mockElement, result);
    }

    @Test
    public void testGetColorRange(){
        // Create an instance of the ImagePPM class
        ImagePPM image = new ImagePPM();

        // Set the color range for the image
        image.setColorRange(String.valueOf(255.0f));

        // Invoke the getColorRange method
        float result = image.getColorRange();

        // Verify that the getColorRange method returns the expected value
        assertEquals(255.0f, result);
    }
}
