package ch.supsi.ed2d.backend.model.formats.chain;

import ch.supsi.ed2d.backend.model.CellRGB;
import ch.supsi.ed2d.backend.model.formats.PortableBitmapImage;
import ch.supsi.ed2d.backend.model.formats.GenericImage;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.*;

public class FileChainOfResponsabilityTest {

    FileChainOfResponsability chain = new FileChainOfResponsability();
    @Test
    public void testGetImage() throws IOException {

        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        // Set up a file object for the test file
        File file = new File(absolutePath + System.getProperty("file.separator") + "test.ppm");

        // Call the getImage() method
        GenericImage image = chain.getImage(file);

        // Verify that the image was read correctly
        assertNotNull(image);
        assertEquals(PortableBitmapImage.P3, image.getFtype());
        assertEquals(2, image.getRows());
        assertEquals(2, image.getColumns());
        assertEquals(255, image.getColorRange());
        assertNotNull(image.getBits());
    }

    @Test
    public void testSaveImage() throws IOException {
        // create a dummy GenericImage object
        GenericImage image = new GenericImage();
        image.setFtype(PortableBitmapImage.P3);
        image.setRows(2);
        image.setColumns(2);
        image.setColorRange(255);
        CellRGB[][] bits = new CellRGB[2][2];
        bits[0][0] = new CellRGB(0, 0, 0);
        bits[0][1] = new CellRGB(0, 0, 0);
        bits[1][0] = new CellRGB(0, 0, 0);
        bits[1][1] = new CellRGB(0, 0, 0);
        image.setBits(bits);


        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        String filePath = absolutePath + System.getProperty("file.separator") + "test.ppm";

        // call the saveImage method
        boolean result = chain.saveImage(filePath, image);

        // assert that the image was saved successfully
        assertTrue(result);
    }


}
