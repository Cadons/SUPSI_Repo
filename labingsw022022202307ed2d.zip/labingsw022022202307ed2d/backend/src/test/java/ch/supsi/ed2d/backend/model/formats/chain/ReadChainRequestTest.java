package ch.supsi.ed2d.backend.model.formats.chain;

import ch.supsi.ed2d.backend.model.formats.PortableBitmapImage;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

public class ReadChainRequestTest {

    @Test
    public void testGetReader() {
        // Create a mock BufferedReader object
        BufferedReader mockReader = mock(BufferedReader.class);

        // Create a new ReadChainRequest object with a FormatType and the mock BufferedReader
        ReadChainRequest request = new ReadChainRequest(PortableBitmapImage.P1, mockReader);

        // Call the getReader() method on the request object
        BufferedReader result = request.getReader();

        // Assert that the result is equal to the mock BufferedReader object
        assertEquals(mockReader, result);
    }

}
