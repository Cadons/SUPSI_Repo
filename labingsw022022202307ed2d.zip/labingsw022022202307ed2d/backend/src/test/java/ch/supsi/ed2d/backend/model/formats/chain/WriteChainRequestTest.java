package ch.supsi.ed2d.backend.model.formats.chain;

import ch.supsi.ed2d.backend.model.formats.PortableBitmapImage;
import org.junit.jupiter.api.Test;

import java.io.BufferedWriter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

public class WriteChainRequestTest {
    @Test
    void testGetBufferedWriter() {
        // Create a mock BufferedWriter object
        BufferedWriter mockWriter = mock(BufferedWriter.class);

        // Create a WriteChainRequest object and set its bufferedWriter field to the mock BufferedWriter
        WriteChainRequest request = new WriteChainRequest(PortableBitmapImage.pgm, mockWriter);

        // Call getBufferedWriter() and assert that it returns the mock BufferedWriter
        assertEquals(mockWriter, request.getBufferedWriter());
    }
}
