package ch.supsi.ed2d.backend.model.pipeline;

import ch.supsi.ed2d.backend.model.filters.GrayScale;
import ch.supsi.ed2d.backend.model.filters.Sepia;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PipelineHistoryTest {

    @Test
    void addItem() {
        PipelineHistory history=new PipelineHistory();
       history.add(new Sepia());
        history.add(new GrayScale());
       assertEquals(2,history.getCurrent().size());
    }

    @Test
    void removeItem() {
        PipelineHistory history=new PipelineHistory();
        history.add(new Sepia());
        history.add(new GrayScale());
        assertEquals(2,history.getCurrent().size());
        assertFalse(history.remove(-5));
        assertTrue(history.remove(1));


    }

    @Test
    void clear() {
        PipelineHistory history=new PipelineHistory();
        history.add(new Sepia());
        history.add(new GrayScale());
        history.clear();
        assertEquals(0,history.getCurrent().size());
    }

    @Test
    void undo() {
        PipelineHistory history=new PipelineHistory();
        history.add(new Sepia());
        history.add(new GrayScale());
        history.undo();
        assertEquals(1,history.getCurrent().size());
        history.clear();
        history.undo();
        assertEquals(1,history.getCurrent().size());
        history.add(new GrayScale());
        history.add(new GrayScale());

        assertEquals(3,history.getCurrent().size());
        assertTrue(history.remove(1));
        history.undo();
        assertEquals(3,history.getCurrent().size());
    }


    @Test
    void redo() {
        PipelineHistory history=new PipelineHistory();
        history.add(new Sepia());
        history.add(new GrayScale());

        history.undo();
        history.redo();
        assertEquals(2,history.getCurrent().size());
    }
}