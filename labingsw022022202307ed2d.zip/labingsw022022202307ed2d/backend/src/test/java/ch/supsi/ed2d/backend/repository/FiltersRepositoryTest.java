package ch.supsi.ed2d.backend.repository;


import ch.supsi.ed2d.backend.model.filters.Rescaling;
import ch.supsi.ed2d.backend.model.filters.Sepia;
import ch.supsi.ed2d.backend.model.filters.Sharpness;
import ch.supsi.ed2d.backend.model.pipeline.PipelineItem;
import ch.supsi.ed2d.backend.model.filters.GrayScale;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class FiltersRepositoryTest {
    @Test
    public void testGetInstance() {
        assertNotNull(FiltersRepository.getInstance());
    }

    @Test
    public void testGetFilters() {
        ArrayList<PipelineItem> filters = new ArrayList<>();

        filters.add(new GrayScale());
        filters.add(new Sepia());
        filters.add(new Rescaling());
        filters.add(new Sharpness());
        assertEquals(filters, FiltersRepository.getInstance().getFilters());
    }
}