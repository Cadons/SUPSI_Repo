package ch.supsi.ed2d.backend.repository;


import ch.supsi.ed2d.backend.exception.FileNotInitializedException;
import ch.supsi.ed2d.backend.exception.FileNotSupportedException;
import ch.supsi.ed2d.backend.model.CellRGB;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

public class ImageRepositoryTest {

    ImageRepository imageRepository = ImageRepository.getInstance();

    @Test
    public void testLoadImageFile() {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        assertDoesNotThrow(()->imageRepository.loadImageFile(new File(absolutePath + System.getProperty("file.separator")+"test.ppm")));
        assertThrows(FileNotSupportedException.class, ()->imageRepository.loadImageFile(new File(absolutePath  + System.getProperty("file.separator")+ "palla.png")));
    }

    @Test
    public void testGetInstance() {
        assertEquals(imageRepository, ImageRepository.getInstance());
    }

    @Test
    public void testGetImageMatrix() throws FileNotSupportedException, FileNotInitializedException, IOException {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        imageRepository.loadImageFile(new File(absolutePath+ System.getProperty("file.separator")+ "feep.ppm"));
        assertEquals(Arrays.deepToString(getTestImageMatrix()), Arrays.deepToString(imageRepository.getImageMatrix()));
    }

    @Test
    public void testGetImage() throws FileNotSupportedException, IOException, FileNotInitializedException, ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        imageRepository.loadImageFile(new File(absolutePath + System.getProperty("file.separator")+"test.ppm"));
        assertNotNull(imageRepository.getImage());
    }

    @Test
    public void testIsImageLoaded() throws FileNotSupportedException, FileNotInitializedException, IOException {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        imageRepository.loadImageFile(new File(absolutePath + System.getProperty("file.separator") + "test.ppm"));
        assertTrue(imageRepository.isImageLoaded());
    }

    @Test
    public void testGetFile() throws IOException, FileNotSupportedException, FileNotInitializedException, ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        imageRepository.loadImageFile(new File(absolutePath + System.getProperty("file.separator")+"test.ppm"));
        assertEquals(absolutePath+System.getProperty("file.separator")+"test.ppm", imageRepository.getFile().getAbsolutePath());
    }

    @Test
    public void testGetImageColumns() throws IOException, FileNotSupportedException, FileNotInitializedException, ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        imageRepository.loadImageFile(new File(absolutePath + System.getProperty("file.separator")+ "test.ppm"));
        assertEquals(2,imageRepository.getImageColumns());
    }

    @Test
    public void testGetImageRows() throws IOException, FileNotSupportedException, FileNotInitializedException, ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        imageRepository.loadImageFile(new File(absolutePath + System.getProperty("file.separator") + "test.ppm"));
        assertEquals(2,imageRepository.getImageRows());
    }

    @Test
    public void testSaveImageFile() throws FileNotSupportedException, FileNotInitializedException, IOException {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        imageRepository.loadImageFile(new File(absolutePath + System.getProperty("file.separator") + "test.ppm"));
        assertTrue(imageRepository.saveImageFile(absolutePath + System.getProperty("file.separator")+ "savetest.ppm"));
    }

    private float[][] getTestImageMatrix()
    {
        float[][] testImageMatrix = new float[6][9];
        testImageMatrix[0][0] = 1.0F;
        testImageMatrix[0][1] = 0.0F;
        testImageMatrix[0][2] = 0.0F;
        testImageMatrix[0][3] = 0.0F;
        testImageMatrix[0][4] = 1.0F;
        testImageMatrix[0][5] = 0.0F;
        testImageMatrix[0][6] = 0.0F;
        testImageMatrix[0][7] = 0.0F;
        testImageMatrix[0][8] = 1.0F;
        testImageMatrix[1][0] = 1.0F;
        testImageMatrix[1][1] = 1.0F;
        testImageMatrix[1][2] = 0.0F;
        testImageMatrix[1][3] = 1.0F;
        testImageMatrix[1][4] = 1.0F;
        testImageMatrix[1][5] = 1.0F;
        testImageMatrix[1][6] = 0.0F;
        testImageMatrix[1][7] = 0.0F;
        testImageMatrix[1][8] = 0.0F;
        testImageMatrix[2][0] = 0.0F;
        testImageMatrix[2][1] = 0.0F;
        testImageMatrix[2][2] = 0.0F;
        testImageMatrix[2][3] = 0.0F;
        testImageMatrix[2][4] = 0.0F;
        testImageMatrix[2][5] = 0.0F;
        testImageMatrix[2][6] = 0.0F;
        testImageMatrix[2][7] = 0.0F;
        testImageMatrix[2][8] = 0.0F;
        testImageMatrix[3][0] = 0.0F;
        testImageMatrix[3][1] = 0.0F;
        testImageMatrix[3][2] = 0.0F;
        testImageMatrix[3][3] = 0.0F;
        testImageMatrix[3][4] = 0.0F;
        testImageMatrix[3][5] = 0.0F;
        testImageMatrix[3][6] = 0.0F;
        testImageMatrix[3][7] = 0.0F;
        testImageMatrix[3][8] = 0.0F;
        testImageMatrix[4][0] = 0.0F;
        testImageMatrix[4][1] = 0.0F;
        testImageMatrix[4][2] = 0.0F;
        testImageMatrix[4][3] = 0.0F;
        testImageMatrix[4][4] = 0.0F;
        testImageMatrix[4][5] = 0.0F;
        testImageMatrix[4][6] = 0.0F;
        testImageMatrix[4][7] = 0.0F;
        testImageMatrix[4][8] = 0.0F;
        testImageMatrix[5][0] = 0.0F;
        testImageMatrix[5][1] = 0.0F;
        testImageMatrix[5][2] = 0.0F;
        testImageMatrix[5][3] = 0.0F;
        testImageMatrix[5][4] = 0.0F;
        testImageMatrix[5][5] = 0.0F;
        testImageMatrix[5][6] = 0.0F;
        testImageMatrix[5][7] = 0.0F;
        testImageMatrix[5][8] = 0.0F;
        return testImageMatrix;
    }

}