package ch.supsi.ed2d.backend.service;


import ch.supsi.ed2d.backend.controller.ImageController;
import ch.supsi.ed2d.backend.controller.PipelineController;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

public class ImageServiceTest {

    ImageService service = ImageService.getInstance();

    @Test
    public void testGetImageMatrix() {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        service.loadImageFile(new File(absolutePath+ System.getProperty("file.separator")+ "feep.ppm"));
        assertEquals(Arrays.deepToString(getTestImageMatrix()), Arrays.deepToString(service.getImageMatrix()));
    }


    @Test
    public void testLoadImageFile() {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        assertFalse(service.loadImageFile(null));
        assertTrue(service.loadImageFile(new File(absolutePath + System.getProperty("file.separator")+ "test.ppm")));
        assertFalse(service.loadImageFile(new File(absolutePath + System.getProperty("file.separator")+ "palla.png")));
    }

    @Test
    public void testGetInstance(){
        assertEquals(service, ImageService.getInstance());
    }

    @Test
    public void testGetImage() {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        service.loadImageFile(new File(absolutePath + System.getProperty("file.separator")+"test.ppm"));
        assertNotNull(service.getImage());
    }

    @Test
    public void testGetImageColumns() {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        service.loadImageFile(new File(absolutePath + System.getProperty("file.separator")+"test.ppm"));
        assertEquals(2,service.getImageColumns());
    }

    @Test
    public void testGetImageRows() {
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        service.loadImageFile(new File(absolutePath + System.getProperty("file.separator")+ "test.ppm"));
        assertEquals(2,service.getImageRows());
    }

    @Test
    void update()  {
        ImageController myFile= new ImageController();
        Path resourceDirectory = Paths.get("src","test","resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        myFile.loadImageFile(absolutePath+ System.getProperty("file.separator")+ "test.ppm");
        ImageController myFile2= new ImageController();
        myFile2.loadImageFile(absolutePath+ System.getProperty("file.separator")+ "testGray.ppm");
        var pipeline=new  PipelineController();
        pipeline.add(0);
        var result=pipeline.apply(myFile.getImageMatrix());
        assertNotNull(result);
        assertTrue(myFile.updateImage(result));
    }


    @Test
    public void testSaveImageFile(){
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        service.loadImageFile(new File(absolutePath + System.getProperty("file.separator") + "test.ppm"));
        assertTrue(service.saveImageFile(absolutePath + System.getProperty("file.separator")+ "savetest.ppm"));
    }

    @Test
    public void testIsImageLoaded(){
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        service.loadImageFile(new File(absolutePath + System.getProperty("file.separator") + "test.ppm"));
        assertTrue(service.isImageLoaded());
    }

    @Test
    public void testGetStartImage(){
        Path resourceDirectory = Paths.get("src","test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        service.loadImageFile(new File(absolutePath + System.getProperty("file.separator") + "test.ppm"));
        assertEquals(service.getImage().getStartData(), service.getStartImage());
    }

    private float[][] getTestImageMatrix()
    {
        float[][] testImageMatrix = new float[6][9];
        testImageMatrix[0][0] = 1.0F;
        testImageMatrix[0][1] = 0.0F;
        testImageMatrix[0][2] = 0.0F;
        testImageMatrix[0][3] = 0.0F;
        testImageMatrix[0][4] = 1.0F;
        testImageMatrix[0][5] = 0.0F;
        testImageMatrix[0][6] = 0.0F;
        testImageMatrix[0][7] = 0.0F;
        testImageMatrix[0][8] = 1.0F;
        testImageMatrix[1][0] = 1.0F;
        testImageMatrix[1][1] = 1.0F;
        testImageMatrix[1][2] = 0.0F;
        testImageMatrix[1][3] = 1.0F;
        testImageMatrix[1][4] = 1.0F;
        testImageMatrix[1][5] = 1.0F;
        testImageMatrix[1][6] = 0.0F;
        testImageMatrix[1][7] = 0.0F;
        testImageMatrix[1][8] = 0.0F;
        testImageMatrix[2][0] = 0.0F;
        testImageMatrix[2][1] = 0.0F;
        testImageMatrix[2][2] = 0.0F;
        testImageMatrix[2][3] = 0.0F;
        testImageMatrix[2][4] = 0.0F;
        testImageMatrix[2][5] = 0.0F;
        testImageMatrix[2][6] = 0.0F;
        testImageMatrix[2][7] = 0.0F;
        testImageMatrix[2][8] = 0.0F;
        testImageMatrix[3][0] = 0.0F;
        testImageMatrix[3][1] = 0.0F;
        testImageMatrix[3][2] = 0.0F;
        testImageMatrix[3][3] = 0.0F;
        testImageMatrix[3][4] = 0.0F;
        testImageMatrix[3][5] = 0.0F;
        testImageMatrix[3][6] = 0.0F;
        testImageMatrix[3][7] = 0.0F;
        testImageMatrix[3][8] = 0.0F;
        testImageMatrix[4][0] = 0.0F;
        testImageMatrix[4][1] = 0.0F;
        testImageMatrix[4][2] = 0.0F;
        testImageMatrix[4][3] = 0.0F;
        testImageMatrix[4][4] = 0.0F;
        testImageMatrix[4][5] = 0.0F;
        testImageMatrix[4][6] = 0.0F;
        testImageMatrix[4][7] = 0.0F;
        testImageMatrix[4][8] = 0.0F;
        testImageMatrix[5][0] = 0.0F;
        testImageMatrix[5][1] = 0.0F;
        testImageMatrix[5][2] = 0.0F;
        testImageMatrix[5][3] = 0.0F;
        testImageMatrix[5][4] = 0.0F;
        testImageMatrix[5][5] = 0.0F;
        testImageMatrix[5][6] = 0.0F;
        testImageMatrix[5][7] = 0.0F;
        testImageMatrix[5][8] = 0.0F;
        return testImageMatrix;
    }

}