package ch.supsi.ed2d.backend.service;

import ch.supsi.ed2d.backend.controller.ImageController;
import ch.supsi.ed2d.backend.exception.FileNotInitializedException;
import ch.supsi.ed2d.backend.exception.FileNotSupportedException;
import ch.supsi.ed2d.backend.model.CellRGB;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class PipelinerTest  {
    @Test
    public void testGetInstance() {
    }
    @Test
    public void testApply() throws ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException, IOException, NoSuchMethodException, FileNotInitializedException, FileNotSupportedException {

        Assertions.assertNotNull(Pipeliner.getInstance().add(0));
        ImageController myFile= new ImageController();
        Path resourceDirectory = Paths.get("src","test","resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();

        myFile.loadImageFile(absolutePath+ "/test.ppm");
        ImageController myFile2= new ImageController();
        myFile2.loadImageFile(absolutePath+"/testGray.ppm");

        var imgTest=myFile.getImageMatrix();
        var imgPipeline=Pipeliner.getInstance().apply(CellRGB.createMatrix(myFile.getImageMatrix())).getValueAsFloat();


        Assertions.assertNotEquals(myFile2.getImageMatrix(),myFile.getImageMatrix());
        imgTest=myFile2.getImageMatrix();
        imgPipeline=Pipeliner.getInstance().apply(CellRGB.createMatrix(myFile.getImageMatrix())).getValueAsFloat();

        Assertions.assertEquals(imgTest.length,imgPipeline.length);
        for (int i=0;i<imgPipeline.length;i++)
            for (int j=0;j<imgPipeline[0].length;j++)
            {

                Assertions.assertEquals(imgTest[i][j],imgPipeline[i][j],.1);
            }


    }

    @Test
    public void testAdd() {
        Assertions.assertNotNull(Pipeliner.getInstance().add(0));
        Assertions.assertNull(Pipeliner.getInstance().add(100));
    }
    @Test
    public void testRemove() {
        Pipeliner.getInstance().removeAll();
      UUID id=Pipeliner.getInstance().add(0);
        Assertions.assertTrue(Pipeliner.getInstance().remove(id));
        Assertions.assertFalse(Pipeliner.getInstance().remove(id));
    }
    @Test
    public void testGetFilters() {
        List<Map.Entry<String, Integer>> ref=new ArrayList<>();
        ref.add(Map.entry("Gray Scale",0));
        ref.add(Map.entry("Sepia",1));
        ref.add(Map.entry("Rescaling",2));
        ref.add(Map.entry("Sharpness",3));
        Assertions.assertEquals(ref,Pipeliner.getInstance().getFilters());
    }
}