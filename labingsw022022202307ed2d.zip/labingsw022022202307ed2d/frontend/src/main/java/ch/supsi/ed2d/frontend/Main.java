package ch.supsi.ed2d.frontend;

public class Main {
    public static void main(String[] args) {
        MainFX.main(args);
    }

}
