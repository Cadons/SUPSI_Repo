package ch.supsi.ed2d.frontend.controller;


import ch.supsi.ed2d.backend.controller.ImageController;
import ch.supsi.ed2d.backend.controller.ScalingController;
import ch.supsi.ed2d.frontend.model.*;
import ch.supsi.ed2d.frontend.model.gui.Filter;
import javafx.fxml.FXML;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import ch.supsi.ed2d.frontend.model.DataModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

import java.util.ArrayList;
import java.util.Comparator;

public class MainViewController {


    public Button buttonRescaling;
    public Slider sliderRescaling;
    public Button addBtn;
    private ObservableList<Filter> filters;
    private ObservableList<Filter> pipeline = FXCollections.observableList(new ArrayList<>());
    @FXML
    ListView filterList;
    @FXML
    ListView pipelineList;
    @FXML
    private ImageView imageView;
    @FXML
    private MenuItem undoBtn;
    @FXML
    private MenuItem redoBtn;
    @FXML
    Pane paneRescaling;
    @FXML
    ButtonBar buttonBar;

    private boolean count=true;




    private DataModel dataModel = new DataModel();
    private IPipeline pipelineModel = new Pipeline();

    public MainViewController() throws ClassNotFoundException, InstantiationException, IllegalAccessException, InvocationTargetException {
    }


    @FXML
    public void initialize() {
        redoBtn.setDisable(true);
        undoBtn.setDisable(true);
        //paneRescaling.setDisable(true);
        paneRescaling.setVisible(false);

        var tmpfilters = pipelineModel.getFilters();
        filters = FXCollections.observableList(new ArrayList<>(tmpfilters.size()));


        pipelineList.setItems(pipeline);

        tmpfilters.forEach(k -> {
            filters.add(new Filter(k.getKey(), k.getValue().toString()));
        });
        filterList.setItems(filters);

    }

    @FXML
    private void handleUploadImage() throws IOException, ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {
        if (dataModel.selectImageFile()) {
            pipeline.clear();
            pipelineModel.clearPipeline();
            imageView.setImage(dataModel.drawImage());
            imageView.setFitHeight(dataModel.getImage()[0].length / 3);
            imageView.setFitWidth(dataModel.getImage().length / 3);
        } else {
            errorAlert("File error", "This file is not supported");
        }
    }

    @FXML
    public void aboutAlert(){
        Alert about = new Alert(Alert.AlertType.INFORMATION);
        about.setHeaderText("Members of project: ");
        about.setContentText("Marsildo Byketa, Matteo Cadoni, Giorgio Visconti");
        about.setTitle("info");

        about.show();
    }




    public boolean handleRescaling(){



        addBtn.setDisable(true);
        paneRescaling.setVisible(true);
        buttonBar.setDisable(true);

        return true;

    }

    @FXML
    private void addFilterToPipeline(ActionEvent event) {

        ImageController imageController=dataModel.getImageController();

        if(dataModel.isImageLoaded()){

        if (filterList.getSelectionModel().getSelectedIndex() >= 0) {

            var selected = filters.get(filterList.getSelectionModel().getSelectedIndex());

            if (imageController.getImageColumns() != imageController.getImageRows())
                count=false;

            if (selected.getName().equals("Rescaling")&&count&&(imageController.getImageColumns()== imageController.getImageRows())) {

                System.out.println(imageController.getImageColumns());
                System.out.println(imageController.getImageRows());
                count=false;
                handleRescaling();

                Filter data = new Filter(selected.getName(), pipelineModel.add(filterList.getSelectionModel().getSelectedIndex()));


                if (data != null) {
                    pipeline.add(data);
                    setUndoRedo();
                }
            }else if (selected.getName().equals("Rescaling")&&!count){
                errorAlert("Rescaling","impossible add new filter rescaling");
            }

            if (!selected.getName().equals("Rescaling")) {

                Filter data = new Filter(selected.getName(), pipelineModel.add(filterList.getSelectionModel().getSelectedIndex()));

                if (data != null) {
                    pipeline.add(data);
                    setUndoRedo();
                }
            }

        }
        }else
        {
            errorAlert("UpLoad Image","missing image, Upload!!");
        }


    }
    private void setUndoRedo(){
        if(pipelineModel.canIDoUndo()){
            undoBtn.setDisable(true);
        }else{
            undoBtn.setDisable(false);
        }
        if(pipelineModel.canIDoRedo()){
            redoBtn.setDisable(true);
        }else{
            redoBtn.setDisable(false);
        }
    }
    @FXML
    private void removeFilterToPipeline(ActionEvent event) {
        if (!pipelineList.getSelectionModel().isEmpty()) {

            if(pipelineList.getSelectionModel().getSelectedItem().toString().equals("Rescaling"))
                count=true;

            var selected = pipeline.get(pipelineList.getSelectionModel().getSelectedIndex()).getIdFilter();

            if (pipelineModel.remove(selected)) {
                pipeline.remove(pipelineList.getSelectionModel().getSelectedIndex());
                setUndoRedo();
            }


        }

    }

    @FXML
    private void applyPipeline(ActionEvent event) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException {
        if (dataModel.isImageLoaded()) {
            float[][] newImage;
            if (filters.size() > 0) {
                if (pipeline.size() >= 0) {
                    newImage = pipelineModel.apply(dataModel.getStartImage());


                    if (newImage != null) {
                        dataModel.updateImage(newImage);

                        imageView.setImage(dataModel.drawImage());
                        imageView.setFitHeight(dataModel.getImage()[0].length / 3);
                        imageView.setFitWidth(dataModel.getImage().length / 3);

                    }
                }
            } else {
                Alert error = new Alert(Alert.AlertType.ERROR);
                error.setContentText("No Filters");
                error.setTitle("There aren't filters loaded");
                error.show();
            }
        } else {

            errorAlert("No image loaded", "Image not loaded");
        }

    }

    @FXML
    public void undo(ActionEvent event) {
        var newPipeline=pipelineModel.undo();
        ArrayList<Filter> pipelineList=new ArrayList<>();
        newPipeline.forEach(e->{
            pipelineList.add(new Filter(e.getValue(),e.getKey()));
        });
        pipeline.clear();
        pipeline.addAll(pipelineList);
        setUndoRedo();
    }
    @FXML
    public void redo(ActionEvent event){
        var newPipeline=pipelineModel.redo();
        ArrayList<Filter> pipelineList=new ArrayList<>();
        newPipeline.forEach(e->{
            pipelineList.add(new Filter(e.getValue(),e.getKey()));
        });
        pipeline.clear();
        pipeline.addAll(pipelineList);
        setUndoRedo();
    }
    private void errorAlert(String title, String content) {
        Alert error = new Alert(Alert.AlertType.ERROR);
        error.setContentText(content);
        error.setTitle(title);
        error.show();
    }
    @FXML
    public void handleSaveImage() throws IOException {
        dataModel.saveImage();

    }

    public void actionButtonRescaling(ActionEvent actionEvent) {

        pipelineModel.setValueScaling((float)sliderRescaling.getValue());
        paneRescaling.setVisible(false);
        buttonBar.setDisable(false);
        addBtn.setDisable(false);

    }


}
