package ch.supsi.ed2d.frontend.model;

import ch.supsi.ed2d.backend.controller.ImageController;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import java.io.*;


public class DataModel {
    private final ImageController imageController;

    public DataModel() {
        this.imageController = new ImageController();
    }

    public ImageController getImageController() {
        return imageController;
    }

    //method to open the window dialog to select and load the image file
    public boolean selectImageFile(){
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showOpenDialog(null);
        return imageController.loadImageFile(file.getPath());

    }

    //method to instantiate a WritableImage object
    private WritableImage getWritableImage() {

        return new WritableImage(imageController.getImageColumns(),
                imageController.getImageRows());
    }

    public float[][] getImage() {
        return imageController.getImageMatrix();
    }
    public float[][] getStartImage() {
        return imageController.getStartImage();
    }
    public void updateImage(float[][] img) {
         imageController.updateImage(img);
    }

    public WritableImage drawImage(){

        WritableImage writableImage = getWritableImage();
        PixelWriter pw = writableImage.getPixelWriter();
        float[][] bits = imageController.getImageMatrix();

        for (int x = 0; x < imageController.getImageRows(); x++) {
            for (int y = 0,k=0; y < imageController.getImageColumns(); y++) {
                if ((k+2)<bits[0].length) {
                    pw.setColor(y, x, Color.color(bits[x][k], bits[x][k + 1], bits[x][k + 2]));
                    k += 3;
                }else
                    break;
            }
        }
        return writableImage;
    }
    public boolean isImageLoaded(){
        return imageController.isImageLoaded();
    }

    public boolean saveImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("PPM files (*.ppm)", "*.ppm"),
                new FileChooser.ExtensionFilter("PGM files (*.pgm)","*.pgm"),
                new FileChooser.ExtensionFilter("PBM files (*.pbm)", "*.pbm"));
        File file = fileChooser.showSaveDialog(null);
        if(file==null)
            return false;
        //get filename+extension from filechooser
        //get extension from filename
        String extension = fileChooser.getSelectedExtensionFilter().getExtensions().get(0).substring(1);
        //get path from filechooser
        String path = file.getPath();
        //remove extension from path
        path = path+extension;
        //get filename without extension

        return imageController.saveImageFile(path);
    }
}
