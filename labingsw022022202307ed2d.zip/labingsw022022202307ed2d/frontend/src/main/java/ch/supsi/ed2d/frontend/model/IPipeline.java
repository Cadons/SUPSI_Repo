package ch.supsi.ed2d.frontend.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public interface IPipeline {
    List<Map.Entry<String, Integer>> getFilters();
    String add(int id);
    boolean remove(String id);
    float[][] apply(float[][] image);
    boolean isPipelineEmpty();
    boolean canIDoUndo();
    boolean canIDoRedo();
    ArrayList<Map.Entry<String,String>> undo();
    ArrayList<Map.Entry<String,String>> redo();
    void setValueScaling(float valueScaling);
    void clearPipeline();

}
