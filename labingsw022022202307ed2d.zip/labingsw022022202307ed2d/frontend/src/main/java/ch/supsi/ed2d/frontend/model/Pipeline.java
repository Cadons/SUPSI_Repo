package ch.supsi.ed2d.frontend.model;

import ch.supsi.ed2d.backend.controller.PipelineController;
import ch.supsi.ed2d.backend.controller.ScalingController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Pipeline implements IPipeline {
    private final PipelineController pipelineController = new PipelineController();
    private ScalingController scalingController =new ScalingController();

    @Override
    public List<Map.Entry<String, Integer>> getFilters() {
        return  pipelineController.getFilters();
    }

    @Override
    public String add(int id) {
        return pipelineController.add(id);
    }

    @Override
    public boolean remove(String id) {

        return pipelineController.remove(id);
    }

    @Override
    public float[][] apply(float[][] image) {


        return pipelineController.apply(image);
    }

    @Override
    public boolean isPipelineEmpty() {
        return  pipelineController.pipelineSize()<=0;
    }

    @Override
    public boolean canIDoUndo() {
        return pipelineController.canIDoUndo();
    }

    @Override
    public boolean canIDoRedo() {
        return pipelineController.canIDoRedo();
    }

    @Override
    public ArrayList<Map.Entry<String, String>> undo() {
        return pipelineController.undo();
    }

    @Override
    public ArrayList<Map.Entry<String, String>> redo() {
        return pipelineController.redo();
    }
    @Override

    public void setValueScaling(float valueScaling){

        scalingController.setValue(valueScaling);

    }
    @Override
    public void clearPipeline(){
        pipelineController.cleanPipeline();
    }
}
