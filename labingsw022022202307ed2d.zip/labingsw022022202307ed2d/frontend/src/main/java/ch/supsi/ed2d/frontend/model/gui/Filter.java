package ch.supsi.ed2d.frontend.model.gui;

import javafx.scene.control.Label;

public class Filter extends Label{
    private final String name;

    private final String idFilter;

    public Filter(String name, String id) {
        this.name = name;
        this.idFilter = id;
        this.setText(name);
    }

    public String getName() {
        return name;
    }

    public String getIdFilter() {
        return idFilter;
    }

    @Override
    public String toString() {
        return name;
    }


}
