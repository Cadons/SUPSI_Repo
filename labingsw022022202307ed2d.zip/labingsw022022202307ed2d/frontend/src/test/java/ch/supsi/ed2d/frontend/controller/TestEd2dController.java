package ch.supsi.ed2d.frontend.controller;

import static org.testfx.assertions.api.Assertions.assertThat;

/*
public class TestEd2dController extends ApplicationTest {
    @BeforeEach
    public void setUpClass() throws Exception {
        ApplicationTest.launch(Main.class);
    }

    @Override
    public void start(Stage stage) throws IOException {
        Parent mainNode = FXMLLoader.load(ViewLoader.class.getResource("main-view.fxml"));
        stage.setScene(new Scene(mainNode));
        stage.show();
        stage.toFront();
    }

    @AfterEach
    public void afterEachTest() throws Exception {
        FxToolkit.hideStage();
        release(new KeyCode[]{});
        release(new MouseButton[]{});
    }

    @Test
    public void testInitialize() {
        ListView<Filter> filters = lookup("#filterList").queryAs(ListView.class);
        assertNotNull(filters);
        PipelineController p = new PipelineController();

        var tmpfiltersName = new ArrayList<String>();
        p.getFilters().forEach(e->{
            tmpfiltersName.add(e.getKey());
        });
        for (int i = 0; i < tmpfiltersName.size(); i++)
            assertEquals(tmpfiltersName.get(i), filters.getItems().get(i).getName());

    }

    @Test
    public void testAddPipeline() {
        ListView<Filter> filters = lookup("#filterList").queryAs(ListView.class);
        ListView<Filter> pipeline = lookup("#pipelineList").queryAs(ListView.class);
        Button add = lookup("#addBtn").queryAs(Button.class);
        assertNotNull(filters);
        assertNotNull(add);
        filters.getSelectionModel().selectFirst();
        clickOn(add);
        assertEquals(pipeline.getItems().get(0).getName(), filters.getSelectionModel().getSelectedItem().getName());


    }

    @Test
    public void testRemovePipeline() {

        ListView<Filter> filters = lookup("#filterList").queryAs(ListView.class);
        ListView<Filter> pipeline = lookup("#pipelineList").queryAs(ListView.class);
        Button add = lookup("#addBtn").queryAs(Button.class);
        Button rm = lookup("#removeBtn").queryAs(Button.class);
        assertNotNull(filters);
        assertNotNull(add);
        assertNotNull(rm);
        filters.getSelectionModel().selectFirst();
        clickOn(add);
        assertEquals(pipeline.getItems().get(0).getName(), filters.getSelectionModel().getSelectedItem().getName());
        pipeline.getSelectionModel().selectFirst();
        clickOn(rm);

        assertNull(pipeline.getSelectionModel().getSelectedItem());

    }

    @Test
    public void testApplyPipeline() throws ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException, IOException, NoSuchMethodException {

        ListView<Filter> filters = lookup("#filterList").queryAs(ListView.class);
        ListView<Filter> pipeline = lookup("#pipelineList").queryAs(ListView.class);
        filters.getSelectionModel().selectFirst();

        Button add = lookup("#addBtn").queryAs(Button.class);
        Button apply = lookup("#applyBtn").queryAs(Button.class);



        clickOn(apply);
        Node dialogPane = lookup(".dialog-pane").query();
        assertThat(from(dialogPane).lookup((Predicate<Node>) t -> ((Text)t).getTextContent().startsWith("No image loaded")));
        closeCurrentWindow();
        Path resourceDirectory = Paths.get("src", "test", "resources");
        String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        var controller=new ImageController();
        controller.loadImageFile(absolutePath+"/test.ppm");
        clickOn(add);
        clickOn(apply);
    }



}


 */